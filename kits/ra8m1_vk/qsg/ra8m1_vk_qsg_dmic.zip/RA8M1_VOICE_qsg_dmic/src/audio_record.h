#ifndef __AUDIO_RECORD_H
#define __AUDIO_RECORD_H

//#include "DbgTrace.h"
//#include "ringbuffer.h"
//#include "da7218.h"

#define I2S_BUFFER_SIZE                 256  
#define RING_BUFFER_SIZE                I2S_BUFFER_SIZE*16     //I2S_BUFFER_SIZE * 16 slots 

fsp_err_t audio_record_init(void);
fsp_err_t audio_record_start(void);
fsp_err_t audio_record_stop(void);
size_t uac_frame_buf_get(uint16_t *buf, uint32_t size);

#endif  //__AUDIO_RECORD_H
