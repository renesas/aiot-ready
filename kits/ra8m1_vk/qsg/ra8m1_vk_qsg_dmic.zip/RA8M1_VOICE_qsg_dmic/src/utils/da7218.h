/*
 * da7218.h
 *
 *  Created on: Oct 16, 2023
 *      Author: slash
 */

#ifndef DA7218_H_
#define DA7218_H_

#include "hal_data.h"

#define RESET_VALUE (0x00)
#define DA7218_EN_PIN                           BSP_IO_PORT_06_PIN_00

fsp_err_t init_da7218(void);
uint8_t enable_da7218();
uint8_t get_da7218_reg(uint8_t dev_reg);
void deinit_da7218(void);

#endif /* DA7218_H_ */
