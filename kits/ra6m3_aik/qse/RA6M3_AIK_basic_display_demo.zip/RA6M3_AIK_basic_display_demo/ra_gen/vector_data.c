/* generated vector source file - do not edit */
#include "bsp_api.h"
/* Do not build these data structures if no interrupts are currently allocated because IAR will have build errors. */
#if VECTOR_DATA_IRQ_COUNT > 0
        #if __has_include("r_ioport.h")
        BSP_DONT_REMOVE const fsp_vector_t g_vector_table[BSP_ICU_VECTOR_MAX_ENTRIES] BSP_PLACE_IN_SECTION(BSP_SECTION_APPLICATION_VECTORS) =
        {
                        [0] = r_icu_isr, /* ICU IRQ6 (External pin interrupt 6) */
            [1] = spi_rxi_isr, /* SPI1 RXI (Receive buffer full) */
            [2] = spi_txi_isr, /* SPI1 TXI (Transmit buffer empty) */
            [3] = spi_tei_isr, /* SPI1 TEI (Transmission complete event) */
            [4] = spi_eri_isr, /* SPI1 ERI (Error) */
            [5] = sci_spi_rxi_isr, /* SCI8 RXI (Received data full) */
            [6] = sci_spi_txi_isr, /* SCI8 TXI (Transmit data empty) */
            [7] = sci_spi_tei_isr, /* SCI8 TEI (Transmit end) */
            [8] = sci_spi_eri_isr, /* SCI8 ERI (Receive error) */
        };
        const bsp_interrupt_event_t g_interrupt_event_link_select[BSP_ICU_VECTOR_MAX_ENTRIES] =
        {
            [0] = BSP_PRV_IELS_ENUM(EVENT_ICU_IRQ6), /* ICU IRQ6 (External pin interrupt 6) */
            [1] = BSP_PRV_IELS_ENUM(EVENT_SPI1_RXI), /* SPI1 RXI (Receive buffer full) */
            [2] = BSP_PRV_IELS_ENUM(EVENT_SPI1_TXI), /* SPI1 TXI (Transmit buffer empty) */
            [3] = BSP_PRV_IELS_ENUM(EVENT_SPI1_TEI), /* SPI1 TEI (Transmission complete event) */
            [4] = BSP_PRV_IELS_ENUM(EVENT_SPI1_ERI), /* SPI1 ERI (Error) */
            [5] = BSP_PRV_IELS_ENUM(EVENT_SCI8_RXI), /* SCI8 RXI (Received data full) */
            [6] = BSP_PRV_IELS_ENUM(EVENT_SCI8_TXI), /* SCI8 TXI (Transmit data empty) */
            [7] = BSP_PRV_IELS_ENUM(EVENT_SCI8_TEI), /* SCI8 TEI (Transmit end) */
            [8] = BSP_PRV_IELS_ENUM(EVENT_SCI8_ERI), /* SCI8 ERI (Receive error) */
        };
        #elif __has_include("r_ioport_b.h")
        BSP_DONT_REMOVE const fsp_vector_t g_vector_table[BSP_IRQ_VECTOR_MAX_ENTRIES] BSP_PLACE_IN_SECTION(BSP_SECTION_APPLICATION_VECTORS) =
        {
            [BSP_PRV_IELS_ENUM(ICU_IRQ6)] = r_icu_isr, /* ICU IRQ6 (External pin interrupt 6) */
            [BSP_PRV_IELS_ENUM(SPI1_RXI)] = spi_rxi_isr, /* SPI1 RXI (Receive buffer full) */
            [BSP_PRV_IELS_ENUM(SPI1_TXI)] = spi_txi_isr, /* SPI1 TXI (Transmit buffer empty) */
            [BSP_PRV_IELS_ENUM(SPI1_TEI)] = spi_tei_isr, /* SPI1 TEI (Transmission complete event) */
            [BSP_PRV_IELS_ENUM(SPI1_ERI)] = spi_eri_isr, /* SPI1 ERI (Error) */
            [BSP_PRV_IELS_ENUM(SCI8_RXI)] = sci_spi_rxi_isr, /* SCI8 RXI (Received data full) */
            [BSP_PRV_IELS_ENUM(SCI8_TXI)] = sci_spi_txi_isr, /* SCI8 TXI (Transmit data empty) */
            [BSP_PRV_IELS_ENUM(SCI8_TEI)] = sci_spi_tei_isr, /* SCI8 TEI (Transmit end) */
            [BSP_PRV_IELS_ENUM(SCI8_ERI)] = sci_spi_eri_isr, /* SCI8 ERI (Receive error) */
        };
        #endif
        #endif
