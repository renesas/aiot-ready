
/***********************************************************************************************************************
 * File Name    : pmd_hw_interface_aik_ra6m3.h
 * Description  : interface definitions for Display connection on AIK_RA6M3
 ***********************************************************************************************************************/
/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/

#ifndef PMD_TFT_PMD_HW_INTERFACE_AIK_RA6M3_H_
#define PMD_TFT_PMD_HW_INTERFACE_AIK_RA6M3_H_

/* incase c++ */
#if defined(__cplusplus)
 extern "C" {
#endif

// display connected to PMOD1 (Can use Full or RSPI by default FULL SPI is used)
#if defined(BOARD_RA6M3_AIK) && defined(TFT_ON_PMOD1)
  // Switching between Full SPI and RSPI (simple SPI)
  // #define TFT_USE_CSI_SPI  enables the simple SPI FSP commands
  //#define TFT_USE_CSI_SPI

  #define BOARD_RAxx_FOUND

  #define TFT_SPI_CTRL g_spi_pmod1_ctrl
  #define TFT_SPI_CFG  g_spi_pmod1_cfg
  #define TFT_SPI_CALLBACK spi_pmod1_callback

  // AIK PMOD 1 SPI
  // r_spi max (overdrive) [60MHz] 30Mbps 20MMbps, 15Mbps 12Mbps 10Mbps 5Mbps 2.5Mbps 1.25Mbps
  #define TFT_SPI_SEND_BAUDRATE    60000000
  #define TFT_SPI_RECEIVE_BAUDRATE 30000000

  #define PM_TFT_CS    BSP_IO_PORT_02_PIN_07
  #define PM_TFT_RESET BSP_IO_PORT_02_PIN_09
  #define PM_TFT_CD    BSP_IO_PORT_02_PIN_10

  #define PM_TFT_MISO  BSP_IO_PORT_02_PIN_02
  #define PM_TFT_MOSI  BSP_IO_PORT_02_PIN_03
  #define PM_TFT_SCK   BSP_IO_PORT_02_PIN_04

  #define PM_TOUCH_CS  BSP_IO_PORT_03_PIN_13
  #define PM_TOUCH_IRQ BSP_IO_PORT_00_PIN_00

  // used interrupt channel matching to PM_TOUCH_IRQ
  // please adapt in FSP config g_external_irq_touch the channel manually
  #define PM_TOUCH_IRQ_CHANNEL 6

#endif

// display connected to PMOD3 (simple SPI used)
#if defined(BOARD_RA6M3_AIK) && defined(TFT_ON_PMOD3)

  // Switching between Full SPI and RSPI (simple SPI)
  // #define TFT_USE_CSI_SPI  enables the simple SPI FSP commands
  #define TFT_USE_CSI_SPI

  #define BOARD_RAxx_FOUND

  // r_sci_spi limitation is 40MHz
  #define TFT_SPI_SEND_BAUDRATE    40000000
  #define TFT_SPI_RECEIVE_BAUDRATE 20000000

  #define TFT_SPI_CTRL     g_spi_pmod3_ctrl
  #define TFT_SPI_CFG      g_spi_pmod3_cfg
  #define TFT_SPI_CALLBACK sci_spi_pmod3_callback

  // AIK PMOD 3 CSI SPI
  #define PM_TFT_CS    BSP_IO_PORT_06_PIN_06
  #define PM_TFT_RESET BSP_IO_PORT_05_PIN_08
  #define PM_TFT_CD    BSP_IO_PORT_05_PIN_13

  #define PM_TFT_MISO  BSP_IO_PORT_06_PIN_07
  #define PM_TFT_MOSI  BSP_IO_PORT_10_PIN_00
  #define PM_TFT_SCK   BSP_IO_PORT_10_PIN_01

  #define PM_TOUCH_CS  BSP_IO_PORT_06_PIN_00
  #define PM_TOUCH_IRQ BSP_IO_PORT_00_PIN_02

  // used interrupt channel matching to PM_TOUCH_IRQ
  // please adapt in FSP config g_external_irq_touch the channel manually
  #define PM_TOUCH_IRQ_CHANNEL 8

#endif

/* in case c++ */
#if defined(__cplusplus)
 }
#endif

#endif /* PMD_TFT_PMD_HW_INTERFACE_AIK_RA6M3_H_ */
