/***********************************************************************************************************************
 * File Name    : ili9341.h
 * Description  : Contains macros, data structures and functions used  common to the EP
 ***********************************************************************************************************************/

#ifndef PMD_TFT_ILI9341_H_
#define PMD_TFT_ILI9341_H_

/* incase c++ */
#if defined(__cplusplus)
extern "C" {
#endif

#define ILI9341_NOP              0x00
#define ILI9341_SWRESET          0x01
#define ILI9341_RDDID            0x04
#define ILI9341_RDDST            0x09
#define ILI9341_RDDPM            0x0A
#define ILI9341_RDMADCTL         0x0B
#define ILI9341_RDPFORMAT        0x0C
#define ILI9341_RDDIF            0x0D
#define ILI9341_RDSM             0x0E
#define ILI9341_RDSDR            0x0F
#define ILI9341_SLPIN            0x10
#define ILI9341_SLPOUT           0x11
#define ILI9341_PTLON            0x12
#define ILI9341_NORON            0x13
#define ILI9341_INVOFF           0x20
#define ILI9341_INVON            0x21
#define ILI9341_GAMSET           0x26
#define ILI9341_DISPOFF          0x28
#define ILI9341_DISPON           0x29

#define ILI9341_CASET            0x2A
#define ILI9341_RASET            0x2B
#define ILI9341_RAMWR            0x2C
#define ILI9341_COLORSET         0x2D
#define ILI9341_RAMRD            0x2E

#define ILI9341_PTLAR            0x30
#define ILI9341_VSCRDEF          0x33
#define ILI9341_TEOFF            0x34
#define ILI9341_TEON             0x35
#define ILI9341_MADCTL           0x36
#define ILI9341_VSCRSADD         0x37
#define ILI9341_IDMOFF           0x38
#define ILI9341_IDMON            0x39

#define ILI9341_PIXSET           0x3A

#define ILI9341_WRAMCONT         0x3C
#define ILI9341_RRAMCONT         0x3E
#define ILI9341_STEARLINE        0x44
#define ILI9341_GSCANLINE        0x45
#define ILI9341_WRDISBV          0x51
#define ILI9341_RDDISBV          0x52
#define ILI9341_WRCTRLD          0x53
#define ILI9341_RDCTRLD          0x54
#define ILI9341_WRCABC           0x55
#define ILI9341_RDCABC           0x56
#define ILI9341_WRCABCMIN        0x5E
#define ILI9341_RDCABCMIN        0x5F

#define ILI9341_IFMODE           0xB0
#define ILI9341_FRMCTR1          0xB1
#define ILI9341_FRMCTR2          0xB2
#define ILI9341_FRMCTR3          0xB3
#define ILI9341_INVCTR           0xB4
#define ILI9341_PRCTR            0xB5
#define ILI9341_DISCTRL          0xB6
#define ILI9341_ETMOD            0xB7
#define ILI9341_BACKCTR1         0xB8
#define ILI9341_BACKCTR2         0xB9
#define ILI9341_BACKCTR3         0xBA
#define ILI9341_BACKCTR4         0xBB
#define ILI9341_BACKCTR5         0xBC
#define ILI9341_BACKCTR6         0xBD
#define ILI9341_BACKCTR7         0xBE
#define ILI9341_BACKCTR8         0xBF

#define ILI9341_PWCTRL1           0xC0
#define ILI9341_PWCTRL2           0xC1
#define ILI9341_VMCTRL1           0xC5
#define ILI9341_VMCTRL2           0xC7
#define ILI9341_PowerCTR_A	      0xCB 
#define ILI9341_PowerCTR_B        0xCF

#define ILI9341_NVMWR             0xD0
#define ILI9341_NVMPKEY           0xD1
#define ILI9341_RDNVM             0xD2

#define ILI9341_RDID1            0xDA
#define ILI9341_RDID2            0xDB
#define ILI9341_RDID3            0xDC
#define ILI9341_RDID4            0xD3

#define ILI9341_PGAMCTRL          0xE0
#define ILI9341_NGAMCTRL          0xE1
#define ILI9341_DGAMCTRL1         0xE2
#define ILI9341_DGAMCTRL2         0xE3
#define ILI9341_DriverTimingCTR	  0xE8 
#define ILI9341_DriverTimingCTR_B 0xEA 
#define ILI9341_PowerOnSeqCTR     0xED 

#define ILI9341_ENABLE_3G         0xF2
#define ILI9341_IFCTL             0xF6
#define ILI9341_PumpRatioCtr      0xF7

// bit config
#define ILI9341_MADCTL_MY       0x80
#define ILI9341_MADCTL_MX       0x40
#define ILI9341_MADCTL_MV       0x20
#define ILI9341_MADCTL_ML       0x10
#define ILI9341_MADCTL_RGB      0x00
#define ILI9341_MADCTL_BGR      0x08

#ifndef MADCTL_RGB
#define MADCTL_RGB 0x00
#define MADCTL_BGR 0x08
#endif

#define ILI9341_MADCTL_MH       0x04
#define ILI9341_Portrait        ILI9341_MADCTL_MX | ILI9341_MADCTL_BGR
#define ILI9341_Portrait180     ILI9341_MADCTL_MY | ILI9341_MADCTL_BGR
#define ILI9341_Landscape       ILI9341_MADCTL_MV | ILI9341_MADCTL_BGR
#define ILI9341_Landscape180    ILI9341_MADCTL_MY | ILI9341_MADCTL_MX | ILI9341_MADCTL_MV | ILI9341_MADCTL_BGR

#define ILI9341_HorizontalRes       240
#define ILI9341_VerticalRes         320

#define ILI9341_VerticalRes_2       (ILI9341_VerticalRes/2)
#define ILI9341_VerticalRes_4       (ILI9341_VerticalRes/4)
#define ILI9341_VerticalRes_8       (ILI9341_VerticalRes/8)

#define ILI9341_nodeadLockMaxCnt    5000
#define ILI9341_VerticalResMagic    40

/* incase c++ */
#if defined(__cplusplus)
}
#endif

#endif /* PMD_TFT_ILI9341_H_ */
