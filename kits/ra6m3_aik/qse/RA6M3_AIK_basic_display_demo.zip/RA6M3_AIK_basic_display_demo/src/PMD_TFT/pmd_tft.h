/***********************************************************************************************************************
 * File Name    : pmd_tft.h
 * Description  : Contains macros, data structures and functions used  common to the EP
 ***********************************************************************************************************************/
/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/

#ifndef PMD_TFT_PMD_TFT_H_
#define PMD_TFT_PMD_TFT_H_

#include <stddef.h>
#include <sys/_stdint.h>

/* incase c++ */
#if defined(__cplusplus)
extern "C" {
#endif


// use polling mode (mainly for developing very slow)
// #define TFT_POLL

//**************************************************************************************


// define the orientation after display initialization
#define TFT_ORIENTATION TFT_R270

#define BYTES_PER_PIXEL (2u)
#define TXBUFF_SIZE 2048

// storage index
#define TFT_SPI_SEND             0
#define TFT_SPI_RECEIVE          1
#define TFT_SPI_TOUCH            2

// init display color
#define CLS_COLOR (0xF0F020u)

typedef struct
{
    int16_t xstart;
    int16_t ystart;
    uint16_t width;
    uint16_t height;
    bool invalid;
} tft_defineRegion_s;

typedef enum
{
    TFT_FREE_RUN,
    TFT_FREE_RUN_CS_HIGH,
    TFT_SET_WINDOW,
    TFT_SET_WINDOW_send_cmd_1,
    TFT_SET_WINDOW_send_data16_1,
    TFT_SET_WINDOW_send_cmd_2,
    TFT_SET_WINDOW_send_data16_2,
    TFT_DRAW_RECT,
    TFT_DRAW_RECT_send_cmd,
    TFT_DRAW_RECT_send_data16_loop_pre,
    TFT_DRAW_RECT_send_data16_loop,
    TFT_READ_RECT,
    TFT_READ_RECT_send_cmd,
    TFT_READ_RECT_receive_data24_loop_pre,
    TFT_READ_RECT_receive_data24_loop
} tft_callback_states_enum;

typedef enum
{
    TFT_R90 = 0,
    TFT_R0 = 1,
    TFT_R270 = 2,
    TFT_R180 = 3
} tft_display_rotate_enum;

typedef enum  {
    TFT_TXT_R0      = 0,
    TFT_TXT_R90     = 1 ,
    TFT_TXT_R270    = 2,
    TFT_TXT_R180    = 3
} pmd_txt_orientation_enum ;

typedef struct
{
    int32_t dx;
    int32_t dy;
    int32_t offsx;
    int32_t offsy;
    bool swap_xy;
    bool mirror_x;
    bool mirror_y;
} touch_ctrl_adapt_s;

typedef struct
{
    touch_ctrl_adapt_s touch_adapt[4];
    uint16_t touch_x;
    uint16_t touch_y;
    uint16_t touch_press;
    uint16_t touch_x_raw; /* register read */
    uint16_t touch_y_raw; /* register read */
    uint16_t touch_press_raw; /* register read */
} touch_ctrl_s;


typedef struct
{
    union
    {
        uint16_t rgb565;            /*color entry*/
        struct
        {   //bit order assign is low to high so upper bits are at the end
            uint16_t       b       : 5; // blue  0..4
            uint16_t       g       : 6; // green 5..10
            uint16_t       r       : 5; // red  11..15
        } __attribute__ ((packed)) channel;
    };
} pmd_rgb565_color_u;

// initialization and mode settings

void tft_set_ori_set(tft_display_rotate_enum oriOption);
void tft_configure(void);

void tft_set_ori(tft_display_rotate_enum oriOption);
tft_display_rotate_enum tft_get_ori(void);

// functions running partially in SPI interrupt or are related to it
void tft_run_cmd(tft_callback_states_enum transfer_cmd);
tft_defineRegion_s tft_defineRegion(int16_t xstart, int16_t ystart, int16_t xend, int16_t yend, bool prepare_only);

// general usage
void tft_memcpy_write(uint8_t *buffer, int16_t x, int16_t y, uint16_t width, uint16_t height, uint16_t src_pitch,
        bool is_buffer);
void tft_memcpy_read(uint8_t *buffer, int16_t x, int16_t y, uint16_t width, uint16_t height, uint16_t src_pitch,
        bool is_buffer);
void tft_set_draw_color(uint32_t color);
uint16_t tft_get_draw_color(void);
void tft_cls(uint32_t color);
void tft_draw_rect(int16_t x1, int16_t y1, int16_t x2, int16_t y2);
void tft_draw_h_line(int16_t x1, int16_t y1, int16_t x2, uint16_t line_size);
void tft_draw_v_line(int16_t x1, int16_t y1, int16_t y2, uint16_t line_size);
void tft_draw_line(int16_t x1, int16_t y1, int16_t x2, int16_t y2);
void tft_draw_filled_circle(int16_t x, int16_t y, uint16_t r);
void tft_draw_circle(int16_t x, int16_t y, uint16_t r);
void tft_draw_frame(int16_t x, int16_t y, uint16_t w, uint16_t h, uint16_t line_size);
void tft_blit_copy_blend(uint16_t *buffer_rgb565, uint16_t *src_rgb565, int16_t x, int16_t y, uint16_t w, uint16_t h,
        uint32_t src_color_bg, uint32_t src_color_fg);

uint16_t tft_blend_pixel(uint16_t basePixel, uint16_t newPixel, uint8_t alpha);

// helper functions
bool tft_display_exist(void);
bool tftspi_ready_spi(void);
void tft_wait_for_spi(void);
uint16_t tft_get_act_width(void);
uint16_t tft_get_act_height(void);

// general purpose functions
uint16_t* memset16(uint16_t *dest, uint16_t val, size_t len);

// touch functions
void tft_touch_write_command(uint8_t *tx_buffer, uint16_t length);
uint16_t tft_touch_read_data(uint8_t cmd);
void tft_touch_read_raw(void);
void tft_touch_transform(void);
void tft_touch_calibrate(void);

// internal and expert usage
void tft_sent_initialization_data(const unsigned char *initData, unsigned int xSize);
void tft_register_read(uint8_t reg_code, uint8_t *rx_buffer, uint8_t read_start, uint8_t read_length,
        bool ctrlChipSelect);
void tft_register_read8(uint8_t reg_code, uint8_t *rx_buffer, bool ctrlChipSelect);

void tft_read_data(uint8_t *rx_buffer, uint16_t length);
void tft_read_rgb666_to_rgb565_data16(uint16_t *rx_buffer, uint16_t length);
void tft_read_src_clip_data16(uint16_t *dst, uint16_t x_pitch, uint16_t width_dst, uint16_t height_dst);

void tft_write_command(uint8_t *tx_buffer, uint16_t length);

void tft_write_data(uint8_t *tx_buffer, uint16_t length);
void tft_write_data16(uint16_t *tx_buffer, uint16_t length);
void tft_write_src_clip_data16(uint16_t *src, uint16_t x_pitch, uint16_t width_src, uint16_t height_src);

/* in case c++ */
#if defined(__cplusplus)
}
#endif

#endif /* PMD_TFT_PMD_TFT_H_ */
