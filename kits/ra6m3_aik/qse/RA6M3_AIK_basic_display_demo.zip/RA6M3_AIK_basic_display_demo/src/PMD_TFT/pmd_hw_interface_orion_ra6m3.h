
/***********************************************************************************************************************
 * File Name    : pmd_hw_interface.h
 * Description  : interface definitions for Display connection on ORION_RA6M3 board
 ***********************************************************************************************************************/
/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/

#ifndef PMD_TFT_PMD_HW_INTERFACE_ORION_RA6M3_H_
#define PMD_TFT_PMD_HW_INTERFACE_ORION_RA6M3_H_

/* in case c++ */
#if defined(__cplusplus)
 extern "C" {
#endif

//ORION-RA6M3 board definition

// display connected to PMOD1 (flexible adapter for flip required display is looking down)
#if defined(BOARD_RA6M3_ORION) && defined(TFT_ON_PMOD1)
   // Switching between Full SPI and RSPI (simple SPI)
   // #define TFT_USE_CSI_SPI  enables the simple SPI FSP commands
   //#define TFT_USE_CSI_SPI

   #define BOARD_RAxx_FOUND

   // PMOD 1
   // r_spi [60MHz] 30Mbps 20MMbps, 15Mbps 12Mbps 10Mbps 5Mbps 2.5Mbps 1.25Mbps
   #define TFT_SPI_SEND_BAUDRATE    60000000
   #define TFT_SPI_RECEIVE_BAUDRATE 30000000

   #define PM_TFT_CS    BSP_IO_PORT_04_PIN_13
   #define PM_TFT_RESET BSP_IO_PORT_07_PIN_06
   //PB00(hex) --> P1100(dec)
   #define PM_TFT_CD    BSP_IO_PORT_11_PIN_00

   #define PM_TFT_MISO  BSP_IO_PORT_04_PIN_10
   #define PM_TFT_MOSI  BSP_IO_PORT_04_PIN_11
   #define PM_TFT_SCK   BSP_IO_PORT_04_PIN_10

   #define PM_TOUCH_CS  BSP_IO_PORT_05_PIN_13
   #define PM_TOUCH_IRQ BSP_IO_PORT_00_PIN_09

   // used interrupt channel matching to PM_TOUCH_IRQ
   // please adapt in FSP config g_external_irq_touch the channel manually
   #define PM_TOUCH_IRQ_CHANNEL 8

 #endif

/* incase c++ */
#if defined(__cplusplus)
 }
#endif

#endif /* PMD_TFT_PMD_HW_INTERFACE_ORION_RA6M3_H_ */
