
/***********************************************************************************************************************
 * File Name    : pmd_text.h
 * Description  : Contains macros, data structures and functions used  common to the EP
 ***********************************************************************************************************************/
/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/

#ifndef PMD_TEXT_H_
#define PMD_TEXT_H_

#include "pmd_tft.h"

/* incase c++ */
#if defined(__cplusplus)
extern "C" {
#endif

// Color definitions
#define BUFFER_CLEAR_VAL        (0xFFFFFF)
#define RED_COLOR_VAL           (0xFF0000)
#define GREEN_COLOR_VAL         (0x00FF00)
#define BLUE_COLOR_VAL          (0x0000FF)
#define YELLOW_COLOR_VAL        (0xFFFF00)

typedef struct
{
    uint16_t f_color;                   /* foreground color for text */
    uint16_t b_color;                   /* background color for text */
    uint16_t act_font;                  /* actual font to use */
    pmd_txt_orientation_enum rotation ; /* set output rotation */
    uint8_t f_blend;                    /* 0-foreground not modified, 255-foreground color */
    uint8_t b_blend;                    /* 0-background not modified, 255-background color */
    bool f_color_draw;                  /* overwrite foreground */
    bool b_color_draw;                  /* overwrite background */
} pmd_textopt_ctrl_s ;

typedef struct
{
    int16_t x;                          /* text output next-x position */
    int16_t y;                          /* text output next-y position */
    pmd_textopt_ctrl_s request;          /* will be controlled by setting command */
    pmd_textopt_ctrl_s actual;           /* will be used by processing */
} pmd_textopt_s ;

//extern  pmd_textopt_s  pmd_textopt ;

void pmd_text_init(void);
void pmd_text_set_f_color(uint32_t color);
void pmd_text_set_b_color(uint32_t color);
uint16_t pmd_text_set_font(uint16_t font_index);
void pmd_text_set_rotation(pmd_txt_orientation_enum rotation);

int16_t pmd_text_get_cursor_x(void);
int16_t pmd_text_get_cursor_y(void);

uint16_t pmd_font_get_width(void);
uint16_t pmd_font_get_height(void);

void pmd_draw_string(char const *outstr, int16_t const x, int16_t const y);

void pmd_draw_frame(int16_t x, int16_t y, uint16_t w, uint16_t h);
void pmd_set_linesize(uint16_t l_size);
void pmd_draw_text_frame(char const *outstr, int16_t x, int16_t y, uint16_t w, uint16_t h);
uint16_t pmd_get_linesize(void);

// internal use only
void pmd_draw_text_bitmap(char target_char, int16_t x, int16_t y);

/* incase c++ */
#if defined(__cplusplus)
}
#endif

#endif /* PMD_TEXT_H_ */
