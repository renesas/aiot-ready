
/***********************************************************************************************************************
 * File Name    : pmd_tft.c
 * Description  : Contains function definitions.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2023 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/


#include "common_utils.h"
#include "hal_data.h"

#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <limits.h>
#include "PMD_TFT/pmd_hw_interface.h"
#include "PMD_TFT/pmd_tft.h"
#include "PMD_TFT/ili9341.h"
#include "PMD_TFT/xpt2046.h"
#include "PMD_TFT/pmd_touch_icu.h"

extern volatile bool g_touch_press;
uint16_t draw_color565;

#ifndef TFT_USE_CSI_SPI
    static void r_spi_hw_config_baudrate(spi_instance_ctrl_t*, rspck_div_setting_t*);
#else
    static void r_sci_spi_hw_config_baudrate (spi_ctrl_t *, sci_spi_div_setting_t * );
#endif

void TFT_SPI_CALLBACK(spi_callback_args_t * p_args);

#ifdef TFT_SPI_8BIT_ONLY
volatile uint16_t lineBuffer[320+8] BSP_ALIGN_VARIABLE(8) ;
#endif

// Init code based on MI0283QT datasheet
static const unsigned char _initDataILI[] = {    // delay after 1 = 10000, 2...  = n * 50000 ,cmd,num,data ... 0xDN D delay, N entries 15 --> 16
      0x20,ILI9341_SWRESET,                      // SW reset
      0x00,ILI9341_DISPOFF,                      // display off
      0x03,ILI9341_PowerCTR_B,0x00,0x83,0x30,
      0x04,ILI9341_PowerOnSeqCTR,0x64,0x03,0x12,0x81,
      0x03,ILI9341_DriverTimingCTR,0x85,0x01,0x79,
      0x05,ILI9341_PowerCTR_A,0x39,0x2C,0x00,0x34,0x02,
      0x01,ILI9341_PumpRatioCtr,0x20,
      0x02,ILI9341_DriverTimingCTR_B,0x00,0x00,
      0x01,ILI9341_PWCTRL1,0x26,                 // POWER_CONTROL_1
      0x01,ILI9341_PWCTRL2,0x11,                 // POWER_CONTROL_2
      0x02,ILI9341_VMCTRL1,0x35,0x3E,            // VCOM_CONTROL_1
      0x01,ILI9341_VMCTRL2,0xBE,
      0x01,ILI9341_MADCTL,ILI9341_Portrait,
      0x01,ILI9341_PIXSET,0x55,                  // COLMOD_PIXEL_FORMAT_SET
      0x02,ILI9341_FRMCTR1,0x00,0x1B,
      0x01,ILI9341_ENABLE_3G,0x08,
      0x01,ILI9341_GAMSET,0x01,                  // gamma set for curve 01/2/04/08
      0x0E,ILI9341_PGAMCTRL,0x1F,0x1A,0x18,0x0A,0x0F,0x06,0x45,0x87,0x32,0x0A,0x07,0x02,0x07,0x05,0x00, // positive gamma correction
      0x0E,ILI9341_NGAMCTRL,0x00,0x25,0x27,0x05,0x10,0x09,0x3A,0x78,0x4D,0x05,0x18,0x0D,0x38,0x3A,0x1F, // negative gamma correction
      0x04,ILI9341_CASET,0x00,0x00,0x00,0xEF,
      0x04,ILI9341_RASET,0x00,0x00,0x01,0x3F,
      0x01,ILI9341_ETMOD,0x07,                   // entry mode
      0x04,ILI9341_DISCTRL,0x0A,0x82,0x27,0x00,  // display function control
      0x20,ILI9341_SLPOUT,                       // sleep out
      0x20,ILI9341_DISPON } ;                    // display on


static const unsigned char _initDataOri[4][3] = { //delay after 1 = 10000, 2...  = n * 50000 ,cmd,num,data ... 0xDN D delay, N entries 15 --> 16
                                                  {0x01,ILI9341_MADCTL, ILI9341_Landscape},
                                                  {0x01,ILI9341_MADCTL, ILI9341_Portrait},
                                                  {0x01,ILI9341_MADCTL, ILI9341_Landscape180},
                                                  {0x01,ILI9341_MADCTL, ILI9341_Portrait180},
                                                 } ;

static volatile spi_event_t g_pmod1_event_flag = SPI_EVENT_TRANSFER_COMPLETE ; // SPI Event completion flag
volatile tft_callback_states_enum tft_callback_act_state  = TFT_FREE_RUN;
volatile tft_callback_states_enum tft_callback_next_state = TFT_FREE_RUN;
volatile tft_callback_states_enum tft_callback_next_jump_state = TFT_FREE_RUN_CS_HIGH ;

uint16_t tft_callback_tx_buffer16[16] BSP_ALIGN_VARIABLE(8);

// Following size definition must be a multiple of 64 byte
uint16_t tft_function_tx_buffer16[TXBUFF_SIZE] BSP_ALIGN_VARIABLE(32);

volatile uint16_t tft_function_tx_buffer16_send_length = 0 ;
volatile uint16_t tft_function_tx_buffer16_send_repeat = 0 ;
volatile uint16_t tft_function_tx_buffer16_send_pitch  = 0 ;
uint16_t * tft_function_tx_buffer16_send_addr = tft_function_tx_buffer16 ;
uint8_t  * tft_function_tx_buffer8_send_addr =  (uint8_t*)tft_function_tx_buffer16 ;

#ifndef TFT_USE_CSI_SPI
rspck_div_setting_t          tft_spck_div[3];           ///< Register values for configuring the SPI Clock Divider.
#else
sci_spi_div_setting_t        tft_spck_div[3];           ///< Register values for configuring the SPI Clock Divider.
#endif

typedef struct
{
    int16_t disp_width; /* physical */
    int16_t disp_height; /* physical */
    char col_add; /* preparation for ST7735 1.4 inch, display shift required */
    char row_add; /* preparation for ST7735 1.4 inch, display shift required */
    char is_type_144; /* ST7735 1.4 inch special type */
    char bgr_on; /* RGB --> BGR output */
    int16_t act_width; /* logical considering rotation */
    int16_t act_height; /* logical considering rotation */
    tft_display_rotate_enum act_oritentation; /* 0 - landscape 1 - portrait 2 - landscape 180 3 portrait 180 */
} options_s;

static volatile options_s option =
{
  .disp_width = ILI9341_HorizontalRes, /* physical */
  .disp_height = ILI9341_VerticalRes,  /* physical */
  .col_add = 0,                        /* preparation for ST7735 1.4 inch, display shift required */
  .row_add = 0,                        /* preparation for ST7735 1.4 inch, display shift required */
  .bgr_on = 0,                         /* RGB --> BGR output */
  .is_type_144 = 0,                    /* 7735 special type display */
  .act_width =  ILI9341_HorizontalRes, /* logical considering rotation */
  .act_height = ILI9341_VerticalRes,   /* logical considering rotation */
  .act_oritentation = TFT_ORIENTATION, /* R90- landscape  R0 - portrait R270 - landscape 180 R180 - portrait 180 */
};

bool tft_display_found = false ;
uint16_t disp_width;       /* physical width */
uint16_t disp_height;      /* physical height */
unsigned char col_add;     /* preparation for ST7735 1.4 inch, display shift required */
unsigned char row_add;     /* preparation for ST7735 1.4 inch, display shift required */
char is_type_144;          /* ST7735 1.4 inch special type */
char bgr_on;               /* RGB --> BGR output */
uint16_t act_width;        /* logical considering rotation */
uint16_t act_height;       /* logical considering rotation */

// touch calibration data
static volatile touch_ctrl_s touch_ctrl = {
   .touch_x     = 0 ,
   .touch_y     = 0 ,
   .touch_press = 0 ,
   .touch_adapt[TFT_R90]  =  {0x2CE4, 0x3A74, 0x29F18, 0x57B78, 0x01, 0x01, 0x01},
   .touch_adapt[TFT_R0]   =  {0x3C3C, 0x2B99, 0x3A5A8, 0x37406, 0x00, 0x00, 0x01},
   .touch_adapt[TFT_R270] =  {0x2C36, 0x3C1B, 0x5B5E4, 0x356F2, 0x01, 0x00, 0x00},
   .touch_adapt[TFT_R180] =  {0x3C53, 0x2CF5, 0x3DCC2, 0x5866E, 0x00, 0x01, 0x00},
};

//__attribute__ ((section("ImageWork_RAM")))  ;

/**
 * @brief check if a TFT display was found by init communication
 * @return false - no display true - display exists
 */
bool tft_display_exist(void)
{
    return(tft_display_found);
}

/**
 * @brief get information about actual display width
 * @return width
 */
uint16_t tft_get_act_width(void)
{
    return (uint16_t)option.act_width;
}

/**
 * @brief get information about actual display height
 * @return height
 */
uint16_t tft_get_act_height(void)
{
    return (uint16_t)option.act_height;
}


/**
 * @brief set memory with a 16 bit value
 * @param dest target address
 * @param val 16bit value for initialization
 * @param len number of words to write
 * @return destination address for reference
 * @note Target address must be aligned to 16
 */
uint16_t* memset16(uint16_t *dest, uint16_t val, size_t len)
{
    uint16_t *ptr;
    ptr = __builtin_assume_aligned (dest, 16, 0);
    while (len-- > 0)
        *ptr++ = val;
    return dest;
}

/**
 * @brief Write configuration data to the display controller
 * @param initData
 * @param xSize
 */
void tft_sent_initialization_data ( const unsigned char *initData, unsigned int xSize)  {
    const unsigned char  * initDataX = initData + xSize  ;
    unsigned char ii ;
    unsigned int  d ;
    unsigned char c ;
    unsigned char n ;
    unsigned char data_byte ;
    fsp_err_t      err;

    /* Enable the display */
    R_IOPORT_PinWrite(&g_ioport_ctrl, PM_TFT_CS, BSP_IO_LEVEL_LOW);
    while(initData < initDataX){
       while ( SPI_EVENT_TRANSFER_COMPLETE != g_pmod1_event_flag ) { ; } /* wait for finished transfer */
       /* set display command mode */
       R_IOPORT_PinWrite(&g_ioport_ctrl, PM_TFT_CD, BSP_IO_LEVEL_LOW);

       c = initData[1] ;

       /* write tft command byte */
       g_pmod1_event_flag = 0 ;
#ifndef TFT_USE_CSI_SPI
       err  = R_SPI_Write(&TFT_SPI_CTRL, &c, 1, SPI_BIT_WIDTH_8_BITS );
#else
       err  = R_SCI_SPI_Write(&TFT_SPI_CTRL, &c, 1, SPI_BIT_WIDTH_8_BITS );
#endif
        if (FSP_SUCCESS != err)
        {
#ifdef SEGGER_DEBUG_ON
           APP_MESSAGE("** TFT_INIT cmd failed **\r\n");
#else
            __BKPT(0);
#endif
        }

       d = initData[0] >> 4;
       n = initData[0] & 0x0F;
       if ( n >= 14 ) {n++;}
       initData += 2 ;

       /* set display data mode */
       while ( SPI_EVENT_TRANSFER_COMPLETE != g_pmod1_event_flag ) { ; }

       R_IOPORT_PinWrite(&g_ioport_ctrl, PM_TFT_CD, BSP_IO_LEVEL_HIGH);

       for (ii=0 ;ii < n ; ii++ ) {
         char offSet = 0 ;
         if (option.bgr_on && c == ILI9341_MADCTL ) { offSet = MADCTL_BGR ;}
         if (ii==1 || ii==3) {
           if ( c == ILI9341_CASET ) { offSet = option.col_add; }
           if ( c == ILI9341_RASET ) { offSet = option.row_add; }
         }

         while ( SPI_EVENT_TRANSFER_COMPLETE != g_pmod1_event_flag ) { ; } /* wait for finished transfer */
         if ( ii == 3 && c == ILI9341_RASET  && option.is_type_144) {
             data_byte = (unsigned char)(offSet + 0x7F) ;
         } else {
             data_byte = (unsigned char)(offSet + *initData) ;
         }

         /* write tft command byte */
         g_pmod1_event_flag = 0 ;

#ifndef TFT_USE_CSI_SPI
         err  = R_SPI_Write(&TFT_SPI_CTRL, &data_byte, 1, SPI_BIT_WIDTH_8_BITS );
#else
         err  = R_SCI_SPI_Write(&TFT_SPI_CTRL, &data_byte, 1, SPI_BIT_WIDTH_8_BITS );
#endif
         if (FSP_SUCCESS != err)
         {
#ifdef SEGGER_DEBUG_ON
             APP_MESSAGE("** TFT_INIT cmd failed **\r\n");
#else
             __BKPT(0);
#endif
         }

         initData++ ;
       }
       if ( d ) {
         if ( d == 1) {
           d  = 10000 ;
         } else {
           d *= 50000 ;
         }
         while ( SPI_EVENT_TRANSFER_COMPLETE != g_pmod1_event_flag ) { ; } /* wait for finished transfer */
         R_BSP_SoftwareDelay(d, BSP_DELAY_UNITS_MICROSECONDS);
       }
    }
    while ( SPI_EVENT_TRANSFER_COMPLETE != g_pmod1_event_flag ) { ; } /* wait for finished transfer */
    /* Disable the display */
    R_IOPORT_PinWrite(&g_ioport_ctrl, PM_TFT_CS, BSP_IO_LEVEL_HIGH);
}

/**
 * @brief set the display orientation for initialization
 * @param oriOption allowed values TFT_R0, TFT_R90, TFT_R180 and TFT_R270
 * @note  function will be used only upfront the call to tft_configure()
 */
void tft_set_ori_set(tft_display_rotate_enum oriOption)
{
    option.act_oritentation = oriOption ;
}


/**
 * @brief orientation change after initialization of display
 * @param oriOption allowed values TFT_R0, TFT_R90, TFT_R180 and TFT_R270
 * @note  orientation can be changed on the fly after tft_configure()
 */
void tft_set_ori( tft_display_rotate_enum oriOption){
  if ( oriOption > 3 )  oriOption = 0 ;
  int16_t HR = option.disp_height ;
  int16_t VR = option.disp_width ;
  option.act_oritentation = oriOption;

  unsigned char  * initDataOri = (unsigned char *)(_initDataOri[oriOption]) ;

  if( (oriOption+1) & 1){
    option.act_height=VR;
    option.act_width=HR;
  } else {
    option.act_width=VR;
    option.act_height=HR;
  }

  //set orientation
  tft_sent_initialization_data(initDataOri,(unsigned int)sizeof(_initDataOri[0])) ;
}

/**
 * @brief get the display orientation
 * @return actual orientation TFT_R0, TFT_R90, TFT_R180 and TFT_R270
 */
tft_display_rotate_enum tft_get_ori(void)
{
    return( option.act_oritentation );
}

/**
 * @brief sent command bytes to the TFT display
 * @param tx_buffer buffer with commands for the display
 * @param length    number of bytes to sent
 */
void tft_write_command (uint8_t *tx_buffer, uint16_t length)
{
    fsp_err_t err = FSP_SUCCESS;

    tft_wait_for_spi();

    // cmd pin to command mode
    R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CD, BSP_IO_LEVEL_LOW);
    g_pmod1_event_flag = 0 ;
#ifndef TFT_USE_CSI_SPI
    err = R_SPI_Write (&TFT_SPI_CTRL, tx_buffer, length, SPI_BIT_WIDTH_8_BITS);
#else
    err = R_SCI_SPI_Write (&TFT_SPI_CTRL, tx_buffer, length, SPI_BIT_WIDTH_8_BITS);
#endif
    if (FSP_SUCCESS != err)
    {
#ifdef SEGGER_DEBUG_ON
        APP_MESSAGE("** TFT_CASET cmd failed **\r\n");
#else
        __BKPT(0);
#endif
    }

    tft_wait_for_spi();
    // cmd pin to data mode
    R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CD, BSP_IO_LEVEL_HIGH);
}


/**
 * @brief sent data bytes to the TFT display
 * @param tx_buffer buffer with uint8_t data for the display
 * @param length    number of bytes to sent
 */
void tft_write_data (uint8_t *tx_buffer, uint16_t length)
{
    fsp_err_t err = FSP_SUCCESS;
    tft_wait_for_spi();

    // cmd pin to data mode
    R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CD, BSP_IO_LEVEL_HIGH);

    g_pmod1_event_flag = 0 ;
#ifndef TFT_USE_CSI_SPI
    err = R_SPI_Write (&TFT_SPI_CTRL, tx_buffer, length, SPI_BIT_WIDTH_8_BITS);
#else
    err = R_SCI_SPI_Write (&TFT_SPI_CTRL, tx_buffer, length, SPI_BIT_WIDTH_8_BITS);
#endif
    if (FSP_SUCCESS != err)
    {
#ifdef SEGGER_DEBUG_ON
        APP_MESSAGE("** TFT_CASET cmd failed **\r\n");
#else
        __BKPT(0);
#endif
    }
    tft_wait_for_spi();

}


/**
 * @brief sent data bytes to the TFT display
 * @param tx_buffer buffer with uint16_t data for the display
 * @param length    number of bytes to sent
 */
void tft_write_data16 (uint16_t *tx_buffer, uint16_t length)
{
    fsp_err_t err = FSP_SUCCESS;
    /* set display command mode */
    tft_wait_for_spi();

    // cmd pin to data mode
    R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CD, BSP_IO_LEVEL_HIGH);
    g_pmod1_event_flag = 0 ;
#ifndef TFT_SPI_8BIT_ONLY
    err = R_SPI_Write (&TFT_SPI_CTRL, tx_buffer, length, SPI_BIT_WIDTH_16_BITS);
#else
    for (uint16_t cnt=0; cnt < length; cnt++)
        lineBuffer[cnt] = __builtin_bswap16(tx_buffer[cnt]) ;
    err = R_SCI_SPI_Write (&TFT_SPI_CTRL, (const void *)lineBuffer, length*2, SPI_BIT_WIDTH_8_BITS);
#endif
    if (FSP_SUCCESS != err)
    {
#ifdef SEGGER_DEBUG_ON
        APP_MESSAGE("** TFT_CASET cmd failed **\r\n");
#else
        __BKPT(0);
#endif
    }

    tft_wait_for_spi();
}


/**
 * @brief write a clipping area of data to the TFT display
 * @param src pointer to the source data
 * @param x_pitch pitch of the source data
 * @param width_src width of the area to write
 * @param height_src height of the area to write
 */
void tft_write_src_clip_data16(uint16_t *src, uint16_t x_pitch, uint16_t width_src, uint16_t height_src)
{
    while (height_src-- > 0)
    {
        tft_write_data16 (src, width_src);
        src += x_pitch;
    }
}

/**
 * @brief read back information data from the TFT display
 * @param rx_buffer buffer for data storage
 * @param length of the data to read
 * @note this function is blocking till the data is completely read back
 */
void tft_read_data (uint8_t *rx_buffer, uint16_t length)
{
    fsp_err_t err = FSP_SUCCESS;
    /* set display command mode */

    tft_wait_for_spi();

    // cmd pin to data mode
    R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CD, BSP_IO_LEVEL_HIGH);

    g_pmod1_event_flag = 0 ;
#ifndef TFT_USE_CSI_SPI
    err = R_SPI_Read (&TFT_SPI_CTRL, rx_buffer, length, SPI_BIT_WIDTH_8_BITS);
#else
    err = R_SCI_SPI_Read (&TFT_SPI_CTRL, rx_buffer, length, SPI_BIT_WIDTH_8_BITS);
#endif
    if (FSP_SUCCESS != err)
    {
#ifdef SEGGER_DEBUG_ON
        APP_MESSAGE("** TFT_CASET cmd failed **\r\n");
#else
        __BKPT(0);
#endif
    }

    tft_wait_for_spi();
}

/**
 * @brief read pixel data from TFT display in RGB565 format
 * @param rx_buffer buffer where the data should be stored
 * @param length number of data t store
 * @note the display return RGB666 format only so this function also converts to RGB565
 * @note the function comes back after operation is completed
 */
void tft_read_rgb666_to_rgb565_data16 (uint16_t *rx_buffer, uint16_t length)
{
    fsp_err_t err = FSP_SUCCESS;
    /* set display command mode */
    tft_wait_for_spi();

    // cmd pin to data mode
    R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CD, BSP_IO_LEVEL_HIGH);
    g_pmod1_event_flag = 0 ;
#ifndef TFT_USE_CSI_SPI
    err = R_SPI_Read (&TFT_SPI_CTRL, rx_buffer, length*3, SPI_BIT_WIDTH_8_BITS);
#else
    err = R_SCI_SPI_Read (&TFT_SPI_CTRL, rx_buffer, length*3, SPI_BIT_WIDTH_8_BITS);
#endif
    if (FSP_SUCCESS != err)
    {
#ifdef SEGGER_DEBUG_ON
        APP_MESSAGE("** TFT_CASET cmd failed **\r\n");
#else
        __BKPT(0);
#endif
    }
    tft_wait_for_spi();
    for(uint16_t i=0 , ii=0 ; ii<length; i+=3, ii++)
    {
       uint16_t r=(uint16_t)((uint8_t*)rx_buffer)[i] ;
       uint16_t g=(uint16_t)((uint8_t*)rx_buffer)[i+1] ;
       uint16_t b=(uint16_t)((uint8_t*)rx_buffer)[i+2] ;
       rx_buffer[ii]= (uint16_t)((( r << 8 ) & (uint16_t)0b1111100000000000 ) |  (( g  << 3  ) & (uint16_t)0b0000011111100000 ) | (b >>3 ));
    }
}

/**
 * @brief read RGB565 data in a clipping window area
 * @param dst         location where to store the data
 * @param x_pitch     pitch of the destination area
 * @param width_dst   width of the clipping windows
 * @param height_dst  height of the clipping window
 */
void tft_read_src_clip_data16(uint16_t *dst, uint16_t x_pitch, uint16_t width_dst, uint16_t height_dst)
{

    // dummy read
    tft_read_data((uint8_t*)dst, 1);
    // get the data
    while (height_dst-- > 0)
    {
        tft_read_rgb666_to_rgb565_data16 ((uint16_t*)dst, width_dst);
        dst += x_pitch;
    }
}


/**
 * @brief read data from register of TFT display
 * @param reg_code  command code for register
 * @param rx_buffer address of destination buffer
 * @param read_start address index for register on TFT display
 * @param read_length number of bytes to read
 * @param ctrlChipSelect chip select will be set by this function false/true
 */
void tft_register_read(uint8_t reg_code, uint8_t *rx_buffer, uint8_t read_start, uint8_t read_length, bool ctrlChipSelect)
{
    uint8_t tx_buffer[2] =
    { 0xD9, 0x0 }; // entry 0 is hidden command for read register addr set
    tx_buffer[1] = reg_code;
    /* TFT CS on */
    if (ctrlChipSelect)
        R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CS, BSP_IO_LEVEL_LOW);

    for (uint8_t delta_cnt = 0; delta_cnt < read_length; delta_cnt++)
    {
        tft_write_command (&tx_buffer[0], 1);
        uint8_t addr_data = (uint8_t) (0x10u + delta_cnt + read_start);
        tft_write_data (&addr_data, 1);

        tft_write_command (&tx_buffer[1], 1);
        tft_read_data (&rx_buffer[delta_cnt], 1);
    }

    /* TFT CS off */
    if (ctrlChipSelect)
        R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CS, BSP_IO_LEVEL_HIGH);

}

/**
 * @brief read data from normal reachable register
 * @param reg_code of TFT display
 * @param rx_buffer user receive buffer
 * @param ctrlChipSelect chip select will be set by this function false/true
 */
void tft_register_read8(uint8_t reg_code, uint8_t *rx_buffer, bool ctrlChipSelect)
{
    /* TFT CS on */
    if (ctrlChipSelect)
        R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CS, BSP_IO_LEVEL_LOW);

    tft_write_command (&reg_code, 1);
    tft_read_data (&rx_buffer[0], 1);

    /* TFT CS off */
    if (ctrlChipSelect)
        R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CS, BSP_IO_LEVEL_HIGH);

}


/**
 * @brief initialization of TFT display and interfaces
 * @note  please run tft_set_ori_set before usage
 * @note  cls will be done with color defined by #define CLS_COLOR (0xF0F020u) in pmd_tft.h
 */
void tft_configure(void)
{

    fsp_err_t err;

#ifdef SEGGER_DEBUG_ON
    APP_MESSAGE("** GPIO start **\r\n");
#endif
    /* SPI Pins in case it is switched off */
    /* t.b.d. PM_TFT_MISO */

    err = R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_MOSI, BSP_IO_LEVEL_HIGH);
    if (FSP_SUCCESS != err)
    {
#ifdef SEGGER_DEBUG_ON
        APP_MESSAGE("** GPIO <PM_TFT_MOSI> BSP_IO_LEVEL_HIGH failed **\r\n");
#else
        __BKPT(0);
#endif

    }

    err = R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_SCK, BSP_IO_LEVEL_LOW);
    if (FSP_SUCCESS != err)
    {
#ifdef SEGGER_DEBUG_ON
        APP_MESSAGE("** GPIO <PM_TFT_SCK> BSP_IO_LEVEL_HIGH failed **\r\n");
#else
        __BKPT(0);
#endif
    }

    /* TOUCH to default */
    err = R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TOUCH_CS, BSP_IO_LEVEL_HIGH);
    if (FSP_SUCCESS != err)
    {
#ifdef SEGGER_DEBUG_ON
        APP_MESSAGE("** GPIO <PM_TOUCH_CS> BSP_IO_LEVEL_HIGH failed **\r\n");
#else
        __BKPT(0);
#endif
    }

    /* TFT to default */
    err = R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CS, BSP_IO_LEVEL_HIGH);
    if (FSP_SUCCESS != err)
    {
#ifdef SEGGER_DEBUG_ON
        APP_MESSAGE("** <GPIO PM_TFT_CS> BSP_IO_LEVEL_HIGH failed **\r\n");
#else
        __BKPT(0);
#endif
    }

    /* Low - command, High is data */
    err = R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CD, BSP_IO_LEVEL_HIGH);
    if (FSP_SUCCESS != err)
    {
#ifdef SEGGER_DEBUG_ON
        APP_MESSAGE("** GPIO <PM_TFT_DC> BSP_IO_LEVEL_HIGH failed **\r\n");
#else
        __BKPT(0);
#endif
    }

    /* configure the Reset pin nd rn the reset sequence */
    err = R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_RESET, BSP_IO_LEVEL_HIGH);
    if (FSP_SUCCESS != err)
    {

#ifdef SEGGER_DEBUG_ON
        APP_MESSAGE("** GPIO <PM_TFT_RESET> BSP_IO_LEVEL_HIGH failed **\r\n");
#else
        __BKPT(0);
#endif
    }
    // wait 1ms before reset should be secure
    // Reset pulse low min 10us --> 50us secure
    // After reset release 120ms are require
    R_BSP_SoftwareDelay(1000, BSP_DELAY_UNITS_MICROSECONDS);
    R_IOPORT_PinWrite(&g_ioport_ctrl, PM_TFT_RESET, BSP_IO_LEVEL_LOW);
    R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MICROSECONDS);
    R_IOPORT_PinWrite(&g_ioport_ctrl, PM_TFT_RESET, BSP_IO_LEVEL_HIGH);
    R_BSP_SoftwareDelay(120000, BSP_DELAY_UNITS_MICROSECONDS);

    /* Calculate the baudrate settings for the SPI interface */
#ifndef TFT_USE_CSI_SPI
    R_SPI_CalculateBitrate(TFT_SPI_SEND_BAUDRATE, &tft_spck_div[TFT_SPI_SEND]);
    // out of SPEC setting maximum baudrate for sending not receiving
    if (TFT_SPI_SEND_BAUDRATE >= 60000000)
        tft_spck_div[TFT_SPI_SEND].spbr = 0 ;
#else
    R_SCI_SPI_CalculateBitrate(TFT_SPI_SEND_BAUDRATE, &tft_spck_div[TFT_SPI_SEND],false);
    // out of SPEC setting maximum baudrate for sending not receiving
    if (TFT_SPI_SEND_BAUDRATE >= 60000000)
        tft_spck_div[TFT_SPI_SEND].brr = 0 ;
#endif

#ifndef TFT_USE_CSI_SPI
    R_SPI_CalculateBitrate(TFT_SPI_RECEIVE_BAUDRATE, &tft_spck_div[TFT_SPI_RECEIVE]);
    R_SPI_CalculateBitrate(XPT2046_SPI_BAUDRATE, &tft_spck_div[TFT_SPI_TOUCH]);

#ifdef SEGGER_DEBUG_ON
    APP_MESSAGE("\r\nSPI Baudrate settings:\r\n");
    APP_PRINT("TFT_SPI_SEND    : %8d - brdv %d spbr %d\r\n",TFT_SPI_SEND,tft_spck_div[TFT_SPI_SEND].brdv,tft_spck_div[TFT_SPI_SEND].spbr);
    APP_PRINT("TFT_SPI_RECEIVE : %8d - brdv %d spbr %d\r\n",TFT_SPI_RECEIVE, tft_spck_div[TFT_SPI_RECEIVE].brdv,tft_spck_div[TFT_SPI_RECEIVE].spbr);
    APP_PRINT("TFT_SPI_TOUCH   : %8d - brdv %d spbr %d\r\n",TFT_SPI_TOUCH, tft_spck_div[TFT_SPI_TOUCH].brdv,tft_spck_div[TFT_SPI_TOUCH].spbr);
#endif

#else
    R_SCI_SPI_CalculateBitrate(TFT_SPI_RECEIVE_BAUDRATE, &tft_spck_div[TFT_SPI_RECEIVE],false);
    R_SCI_SPI_CalculateBitrate(XPT2046_SPI_BAUDRATE, &tft_spck_div[TFT_SPI_TOUCH],false);

#ifdef SEGGER_DEBUG_ON
    APP_MESSAGE("\r\nSPI Baudrate settings:\r\n");
    APP_PRINT("TFT_SPI_SEND    : %8d - cks %d brr %d\r\n",TFT_SPI_SEND,tft_spck_div[TFT_SPI_SEND].cks,tft_spck_div[TFT_SPI_SEND].brr);
    APP_PRINT("TFT_SPI_RECEIVE : %8d - cks %d brr %d\r\n",TFT_SPI_RECEIVE, tft_spck_div[TFT_SPI_RECEIVE].cks,tft_spck_div[TFT_SPI_RECEIVE].brr);
    APP_PRINT("TFT_SPI_TOUCH   : %8d - cks %d brr %d\r\n",TFT_SPI_TOUCH, tft_spck_div[TFT_SPI_TOUCH].cks,tft_spck_div[TFT_SPI_TOUCH].brr);
#endif

#endif


#ifndef TFT_USE_CSI_SPI
    err = R_SPI_Open(&TFT_SPI_CTRL, &TFT_SPI_CFG);
#else
    err = R_SCI_SPI_Open(&TFT_SPI_CTRL, &TFT_SPI_CFG);
#endif

    if (FSP_SUCCESS != err)
    {
#ifdef SEGGER_DEBUG_ON
        APP_MESSAGE("** SPI PMOD1 initialization failed **\r\n");
#else
        __BKPT(0);
#endif
    }

    // set the reduced SPI baudrate for reading data from the controller
#ifndef TFT_USE_CSI_SPI
    r_spi_hw_config_baudrate (&TFT_SPI_CTRL, &tft_spck_div[TFT_SPI_RECEIVE]);
#else
    r_sci_spi_hw_config_baudrate(&TFT_SPI_CTRL, &tft_spck_div[TFT_SPI_RECEIVE]);
#endif
    {
        uint8_t buffera[4];
        tft_register_read (ILI9341_RDID4, buffera, 1, 3, true);
        tft_display_found = (buffera[1] == 0x93 && buffera[2] == 0x41);

#ifdef SEGGER_DEBUG_ON
        APP_PRINT("Register data %02x ID: %02x %02x %02x\r\n", 0xD3, buffera[0], buffera[1], buffera[2]);

        if (tft_display_found)
        {
            APP_MESSAGE("Display: ILI9341\r\n");
        }
#endif
    }

    // set the full speed SPI baudrate for writing data to the display contoller
#ifndef TFT_USE_CSI_SPI
    r_spi_hw_config_baudrate (&TFT_SPI_CTRL, &tft_spck_div[TFT_SPI_SEND]);
#else
    r_sci_spi_hw_config_baudrate(&TFT_SPI_CTRL, &tft_spck_div[TFT_SPI_SEND]);
#endif

    //start config
    tft_sent_initialization_data(_initDataILI, sizeof(_initDataILI)) ;

    //set orientation
    tft_set_ori(option.act_oritentation );

    //handle the touch controller interrupt

    /* Initialize External IRQ driver*/
    err = pmd_touch_icu_init();
    /* Handle error */
    if(FSP_SUCCESS != err)
    {
#ifdef SEGGER_DEBUG_ON
        APP_ERR_PRINT("** ICU INIT FAILED ** \r\n");
        APP_ERR_TRAP(err);
#else
        __BKPT(0);
#endif
    }

    /* Enable External IRQ driver*/
    err = pmd_touch_icu_enable();
    /* Handle error */
    if(FSP_SUCCESS != err)
    {
#ifdef SEGGER_DEBUG_ON
        APP_ERR_PRINT("** ICU ENABLE FAILED ** \r\n");
        /* Close External IRQ module.*/
        pmd_touch_icu_deinit();
        APP_ERR_TRAP(err);
#else
        pmd_touch_icu_deinit();
        __BKPT(0);
#endif
    }

    // Demo code start here

    //CLS
    tft_cls(CLS_COLOR) ;

//#define BERND_DEVELOP_TOUCH
#ifdef BERND_DEVELOP_TOUCH
    tft_set_draw_color(0xff0000);
    tft_draw_rect(20,20,option.act_width/2-1,option.act_height/2-1);
    tft_set_draw_color(0x00ff00);
    tft_draw_rect(option.act_width/2,option.act_height/2,option.act_width-1-20,option.act_height-1-20);
    tft_set_draw_color(0x00ffff);
    tft_draw_h_line(10, 100, 200, 1);
    tft_set_draw_color(0xff00ff);
    tft_draw_v_line(10, 100, 200, 1);
    tft_set_draw_color(0xff00ff);
    tft_draw_frame(102,100,140,100, 1);

    tft_memcpy_read((uint8_t*)tft_function_tx_buffer16 , 100, 98, 20, 20, 0, true);
    tft_memcpy_write((uint8_t*)tft_function_tx_buffer16 , 5,5, 20, 20 , (uint16_t)option.act_width, true);


   while (1) { ;

   if ( g_touch_press )
       tft_touch_read_raw();
   R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_SECONDS );

   }
#endif

//#define BERND_DEBUG_TFT
#ifdef BERND_DEBUG_TFT
   tft_set_draw_color(0xff0000);
   tft_draw_rect(20,20,option.act_width/2-1,option.act_height/2-1);
   tft_set_draw_color(0x00ff00);
   tft_draw_rect(option.act_width/2,option.act_height/2,option.act_width-1-20,option.act_height-1-20);
#endif

#ifdef SEGGER_DEBUG_ON
    APP_MESSAGE("** SPI INIT done **\r\n");
#endif

}

#ifndef TFT_USE_CSI_SPI

/**
 * @brief change baudrate of SPI interface by direct register modification
 * @param p_ctrl     FSP ctrl
 * @param p_spck_div register settings
 */
static void r_spi_hw_config_baudrate (spi_instance_ctrl_t * p_ctrl, rspck_div_setting_t * p_spck_div)
{
    /* The status register must be read before cleared. Reference section 38.2.4 SPI Status Register (SPSR) in the
     * RA6M3 manual R01UH0886EJ0100. */

    p_ctrl->p_regs->SPSR;
    p_ctrl->p_regs->SPSR = 0;

    uint16_t spcmd0 = p_ctrl->p_regs->SPCMD[0] ;
    uint16_t tmp = ((uint16_t)(p_spck_div->brdv) << 0x02 ) & 0b0000000000001100 ;
    spcmd0 &=  0b1111111111110011 ;
    spcmd0 |=  tmp ;
    // we need some dummy read commands
    p_ctrl->p_regs->SPBR;
    p_ctrl->p_regs->SPCMD[0];
    // change the register
    p_ctrl->p_regs->SPBR     = p_spck_div->spbr;
    p_ctrl->p_regs->SPCMD[0] = spcmd0 ;
    // we need some dummy read commands
    p_ctrl->p_regs->SPBR;
    p_ctrl->p_regs->SPCMD[0];
}

#else

/**
 * @brief change baudrate of RSPI interface by direct register modification
 * @param p_ctrl FSP ctrl
 * @param p_spck_div register settings
 */
static void r_sci_spi_hw_config_baudrate (spi_ctrl_t * p_api_ctrl, sci_spi_div_setting_t * p_spck_div)
{
    /* The status register must be read before cleared. Reference section 38.2.4 SPI Status Register (SPSR) in the
     * RA6M3 manual R01UH0886EJ0100. */
    sci_spi_instance_ctrl_t * p_ctrl = (sci_spi_instance_ctrl_t *) p_api_ctrl;

    /* Clear the RE and TE bits before writing other settings. See section 34.2 Register Descriptions in the
      * RA6M3 manual R01UH0886EJ0100. */
    p_ctrl->p_reg->SCR ;
    p_ctrl->p_reg->SCR = 0;


    uint8_t smr_i = p_ctrl->p_reg->SMR ;
    uint16_t tmp = ((uint8_t)(p_spck_div->cks) << 0x00 ) & 0b00000011 ;
    smr_i &=  (uint8_t)0b11111100 ;
    smr_i |=  (uint8_t)tmp ;
    // we need some dummy read commands
    p_ctrl->p_reg->BRR;
    p_ctrl->p_reg->SMR;
    // change the register
    p_ctrl->p_reg->BRR  = p_spck_div->brr;
    p_ctrl->p_reg->SMR  = (uint8_t) smr_i;
    // we need some dummy read commands
    p_ctrl->p_reg->BRR;
    p_ctrl->p_reg->SMR;
}

#endif


/**
 * @brief set the command to run in the call back routine of the display SPI transfer state machine
 * @param transfer_cmd next command to run in interrupt state machine
 * @brief please cross check for valid calls there are no security checks implemented
 */
void tft_run_cmd(tft_callback_states_enum transfer_cmd){
    spi_callback_args_t *p_args = NULL ;
    tft_wait_for_spi();
    tft_callback_act_state = transfer_cmd ;
    TFT_SPI_CALLBACK(p_args) ;
}


/**
 * @brief wait till spi transfer to or from TFT display are finished
 */
void tft_wait_for_spi(void)
{
    while (SPI_EVENT_TRANSFER_COMPLETE != g_pmod1_event_flag)
    {
        ;
    } /* wait for finished transfer */
}

/**
 * @brief chekc status of display spi state machine and return without wait
 * @return true if not busy, false if operation is still running
 */
bool tftspi_ready_spi(void)
{
    if (SPI_EVENT_TRANSFER_COMPLETE == g_pmod1_event_flag)
      return true ;
    else
      return false ;
}


/**
 * @brief set draw region on TFT display
 * @param xstart position
 * @param ystart position
 * @param xend   position
 * @param yend   position
 * @param prepare_only false - calculate and sent data to TFT, true calculate only and return,
 * @return aggreagte with calculation data for active region
 */
tft_defineRegion_s tft_defineRegion(int16_t xstart, int16_t ystart, int16_t xend, int16_t yend, bool prepare_only)
{
    tft_defineRegion_s regionOut;
    regionOut.invalid = 0;

    /* make some window calculations for allowed x-coordinates */
    if (xend <= xstart)
    {
        int16_t t = xstart;
        xstart = xend;
        xend = t;
    }
    if (xend < 0)
    {
        xend = 0;
        xstart = xend;
        regionOut.invalid = 1;
    }
    else
    {
        if (xstart < 0)
            xstart = 0;
    }

    if (xstart >= option.act_width)
    {
        xstart = option.act_width - 1;
        xend = xstart;
        regionOut.invalid = 1;
    }
    else
    {
        if (xend >= option.act_width)
            xend = option.act_width - 1;
    }

    /* make some window calculations for allowed x-coordinates */
    if (yend <= ystart)
    {
        int16_t t = ystart;
        ystart = yend;
        yend = t;
    }

    if (yend < 0)
    {
        yend = 0;
        ystart = yend;
        regionOut.invalid = 1;
    }
    else
    {
        if (ystart < 0)
            ystart = 0;
    }

    if (ystart >= option.act_height)
    {
        ystart = option.act_height - 1;
        yend = ystart;
        regionOut.invalid = 1;
    }
    else
    {
        if (yend >= option.act_height)
            yend = option.act_height - 1;
    }

    /* calculate number of bytes in window */

    regionOut.xstart = xstart;
    regionOut.ystart = ystart;
    regionOut.width = (uint16_t) (xend - xstart + 1);
    regionOut.height = (uint16_t) (yend - ystart + 1);

    /* prepare data for x left - x right window */
    tft_callback_tx_buffer16[0] = ILI9341_CASET;

    xstart += option.col_add;
    tft_callback_tx_buffer16[1] = (uint16_t) xstart;

    xend += option.col_add;
    tft_callback_tx_buffer16[2] = (uint16_t) xend;

    /* prepare data for y top - y bottom window */
    tft_callback_tx_buffer16[3] = ILI9341_RASET;

    ystart += option.row_add;
    tft_callback_tx_buffer16[4] = (uint16_t) ystart;

    yend += option.row_add;
    tft_callback_tx_buffer16[5] = (uint16_t) yend;

#ifdef TFT_POLL
    if ( prepare_only == false )
    {
        // Write data to display by polling
        tft_wait_for_spi();
        R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CS, BSP_IO_LEVEL_LOW);
        tft_write_command ((uint8_t *)&tft_callback_tx_buffer16[0], 1);
        tft_write_data16 (&tft_callback_tx_buffer16[1], 2 );
        tft_write_command ((uint8_t *)&tft_callback_tx_buffer16[3], 1);
        tft_write_data16 ( &tft_callback_tx_buffer16[4], 2);
        R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CS, BSP_IO_LEVEL_HIGH);
    }
#else
    // write data to display by interrupt
    if (prepare_only == false)
        tft_run_cmd (TFT_SET_WINDOW);
#endif

    /* return number of bytes to transfer in window */
    return (regionOut);
}


/**
 * @brief read data out of TFT-RAM by SPI within the clipping window and copy it into the buffer
 * @param buffer pointer to a byte addressed buffer (size width * height * 3 )
 * @param x position for writing (0,0) top left corner
 * @param y position for writing (0,0) top left corner
 * @param width of area on TFT
 * @param height of area on TFT
 * @param src_pitch pitch of source buffer
 * @param is_buffer mode switching 0-copy content to framebuffer from TFT 1 - pitch will be ignored, copy into buffer directly
 * @note user adressing of buffer can be case cast to (uint16_t *) to get access to RGB565 data directly
 * @note the buffer needs 3 byte per pixel internally also the result in rgb565 needs less
 */
void tft_memcpy_read( uint8_t * buffer , int16_t x, int16_t y, uint16_t width, uint16_t height, uint16_t src_pitch, bool is_buffer)
{
    tft_defineRegion_s  actRegionSettings ;

#ifdef TFT_POLL
    unsigned char c ;

    /* define the region */
    actRegionSettings = tft_defineRegion(x, y, (int16_t)(x+width-1), (int16_t)(y+height-1),false);

#ifndef TFT_USE_CSI_SPI
    // set the reduced SPI baudrate for reading data from the controller
    r_spi_hw_config_baudrate (&TFT_SPI_CTRL, &tft_spck_div[TFT_SPI_RECEIVE]);
#else
    r_sci_spi_hw_config_baudrate(&TFT_SPI_CTRL, &tft_spck_div[TFT_SPI_RECEIVE]);
#endif

    /* enable TFT display */
    R_IOPORT_PinWrite(&g_ioport_ctrl, PM_TFT_CS, BSP_IO_LEVEL_LOW);
    c = ILI9341_RAMRD;
    tft_write_command(&c, 1);
    if ( is_buffer == false )
    {
        tft_read_src_clip_data16(((uint16_t*)buffer)+ actRegionSettings.xstart + actRegionSettings.ystart * src_pitch, src_pitch, actRegionSettings.width, actRegionSettings.height);
    }
    else
    {
        tft_read_src_clip_data16((uint16_t*)buffer, actRegionSettings.width, actRegionSettings.width, actRegionSettings.height);
    }
    // set the full speed SPI baudrate for writing data to the display contoller
#ifndef TFT_USE_CSI_SPI
    r_spi_hw_config_baudrate (&TFT_SPI_CTRL, &tft_spck_div[TFT_SPI_SEND]);
#else
    r_sci_spi_hw_config_baudrate(&TFT_SPI_CTRL, &tft_spck_div[TFT_SPI_SEND]);
#endif

    R_IOPORT_PinWrite(&g_ioport_ctrl, PM_TFT_CS, BSP_IO_LEVEL_HIGH);
#else
    // set the reduced SPI baudrate for reading data from the controller
#ifndef TFT_USE_CSI_SPI
    r_spi_hw_config_baudrate (&TFT_SPI_CTRL, &tft_spck_div[TFT_SPI_RECEIVE]);
#else
    r_sci_spi_hw_config_baudrate(&TFT_SPI_CTRL, &tft_spck_div[TFT_SPI_RECEIVE]);
#endif
    actRegionSettings = tft_defineRegion(x, y, (int16_t)(x+width-1), (int16_t)(y+height-1),true);
    if ( actRegionSettings.invalid )
        return ;
    tft_callback_tx_buffer16[6] = ILI9341_RAMRD;
    /* run in interrupt routine to avoid polling */
    tft_function_tx_buffer16_send_length = actRegionSettings.width;
    if ( is_buffer == false )
    {   // write source and target same coordinates
        tft_function_tx_buffer16_send_pitch  = src_pitch ;
        tft_function_tx_buffer16_send_addr   = ((uint16_t*)buffer)+ actRegionSettings.xstart + actRegionSettings.ystart * src_pitch ;
    }
    else
    {   // write into 0.0 aligned buffer
        tft_function_tx_buffer16_send_pitch  = actRegionSettings.width ;
        tft_function_tx_buffer16_send_addr   = (uint16_t*)buffer;
    }
    tft_function_tx_buffer8_send_addr    = (uint8_t *) tft_function_tx_buffer16_send_addr;
    tft_function_tx_buffer16_send_repeat = actRegionSettings.height ;
    tft_callback_next_jump_state = TFT_READ_RECT ;
    tft_run_cmd(TFT_SET_WINDOW) ;
    //tft_wait_for_spi();
    tft_wait_for_spi();

    // set the full speed SPI baudrate for writing data to the display contoller
#ifndef TFT_USE_CSI_SPI
    r_spi_hw_config_baudrate (&TFT_SPI_CTRL, &tft_spck_div[TFT_SPI_SEND]);
#else
    r_sci_spi_hw_config_baudrate(&TFT_SPI_CTRL, &tft_spck_div[TFT_SPI_SEND]);
#endif
    for(uint16_t i=0 , ii=0 ; ii< actRegionSettings.width * actRegionSettings.height ; i+=3, ii++)
    {
       uint16_t r=(uint16_t)((uint8_t*)buffer)[i] ;
       uint16_t g=(uint16_t)((uint8_t*)buffer)[i+1] ;
       uint16_t b=(uint16_t)((uint8_t*)buffer)[i+2] ;
       ((uint16_t *)buffer)[ii]= (uint16_t)((( r << 8 ) & (uint16_t)0b1111100000000000 ) |  (( g  << 3  ) & (uint16_t)0b0000011111100000 ) | (b >>3 ));
    }
#endif
}


/**
 * @brief copy content of a buffer or frame buffer to the TFT display
 * @param buffer pointer to a byt addressed buffer
 * @param x position for writing (0,0) top left corner
 * @param y position for writing (0,0) top left corner
 * @param width of area on TFT
 * @param height of area on TFT
 * @param src_pitch pitch of source buffer
 * @param is_buffer mode switching 0-copy contetn of framebuffer to TFT 1- contents of a buffer will be copied, pitch will be ignored
 */
void tft_memcpy_write( uint8_t * buffer , int16_t x, int16_t y, uint16_t width, uint16_t height, uint16_t src_pitch, bool is_buffer)
{
    tft_defineRegion_s  actRegionSettings ;

#ifdef TFT_POLL
    unsigned char c ;

    tsTftDrawAct = tx_time_get ();

    /* define the region */
    actRegionSettings = tft_defineRegion(x, y, (int16_t)(x+width-1), (int16_t)(y+height-1),false);

    /* enable TFT display */
    R_IOPORT_PinWrite(&g_ioport_ctrl, PM_TFT_CS, BSP_IO_LEVEL_LOW);
    c = ILI9341_RAMWR;
    tft_write_command(&c, 1);
    if ( is_buffer == false )
    {
      tft_write_src_clip_data16(((uint16_t*)buffer)+ actRegionSettings.xstart  + actRegionSettings.ystart * src_pitch, src_pitch, actRegionSettings.width, actRegionSettings.height);
    }
    else
    {
      tft_write_src_clip_data16((uint16_t*)buffer, actRegionSettings.width, actRegionSettings.width, actRegionSettings.height);
    }
    R_IOPORT_PinWrite(&g_ioport_ctrl, PM_TFT_CS, BSP_IO_LEVEL_HIGH);
#else

    actRegionSettings = tft_defineRegion(x, y, (int16_t)(x+width-1), (int16_t)(y+height-1),true);
    if ( actRegionSettings.invalid )
        return ;
    tft_callback_tx_buffer16[6] = ILI9341_RAMWR;
    /* run in interrupt routine to avoid polling */
    tft_function_tx_buffer16_send_length = actRegionSettings.width;

    if ( is_buffer == false )
    {   // write source and target same coordinates
        tft_function_tx_buffer16_send_pitch  = src_pitch ; // 80
        tft_function_tx_buffer16_send_addr   = ((uint16_t*)buffer)+ (actRegionSettings.xstart + 0 )+ actRegionSettings.ystart * src_pitch ;
    }
    else
    {   // write into 0.0 aligned buffer
        tft_function_tx_buffer16_send_pitch  = actRegionSettings.width ;
        tft_function_tx_buffer16_send_addr   = (uint16_t*)buffer;
    }

    tft_function_tx_buffer16_send_repeat = actRegionSettings.height ;
    tft_callback_next_jump_state = TFT_DRAW_RECT ;
    tft_run_cmd(TFT_SET_WINDOW) ;
    //tft_wait_for_spi();
#endif
}


/**
 * @brief copy a RGB565 source picture onto the TFT display
 * @param buffer_rgb565 buffer for picture processing size of array must be ( w * h + (w*h + 1) / 2 )
 * @param src_rgb565 ( source with data to copy to tft w * h )
 * @param x position on TFT
 * @param y position on TFT
 * @param w width of source picture
 * @param h height of source picture
 * @param src_color_bg back ground color format ARGB8888 The specified color will use the Alpha values 0 -255
 * @param src_color_fg fore ground (picture data) ARGB8888 only A will be used alpha blending for picture over background on TFT
 */
void tft_blit_copy_blend(uint16_t *buffer_rgb565, uint16_t *src_rgb565, int16_t x, int16_t y, uint16_t w, uint16_t h,
        uint32_t src_color_bg, uint32_t src_color_fg)
{

    uint8_t picture_color_alpha = (uint8_t) (src_color_fg >> 24);
    uint16_t picture_background_color = (uint16_t) (((src_color_bg >> 8) & 0b1111100000000000u)
            | ((src_color_bg >> 5) & 0b0000011111100000u) | ((src_color_bg >> 3) & 0b0000000000011111u));
    ;
    uint8_t picture_background_alpha = (uint8_t) (src_color_bg >> 24);
    tft_wait_for_spi();

    if (picture_color_alpha == 255 && picture_background_alpha == 255)
    {
        // picture color replaces everything, overwrite the picture
        tft_memcpy_write ((uint8_t*) src_rgb565, x, y, w, h, w, true);
        return;
    }
    if (picture_color_alpha == 0 && picture_background_alpha == 0)
    {
        // do nothing on the picture
        return;
    }

    tft_memcpy_read ((uint8_t*) buffer_rgb565, x, y, w, h, w, true);
    for (uint16_t row = 0; row < h; row++)
    {
        uint32_t l_addr = row * w;
        for (uint16_t col = 0; col < w; col++)
        {
            if (src_rgb565[l_addr + col] == picture_background_color)
            {
                if (picture_background_alpha == 0)
                {
                    ;
                }
                else if (picture_background_alpha == 255)
                {
                    buffer_rgb565[l_addr + col] = src_rgb565[l_addr + col];
                }
                else
                {
                    buffer_rgb565[l_addr + col] = tft_blend_pixel (buffer_rgb565[l_addr + col],
                                                                   src_rgb565[l_addr + col], picture_background_alpha);
                }
            }
            else
            {
                if (picture_color_alpha == 0)
                {
                    ;
                }
                else if (picture_color_alpha == 255)
                {
                    buffer_rgb565[l_addr + col] = src_rgb565[l_addr + col];
                }
                else
                {
                    buffer_rgb565[l_addr + col] = tft_blend_pixel (buffer_rgb565[l_addr + col],
                                                                   src_rgb565[l_addr + col], picture_color_alpha);
                }
            }
        }
    }

    tft_memcpy_write ((uint8_t*) buffer_rgb565, x, y, w, h, w, true);

}


// drawing routines
/**
 * @brief set color for draw commands like line..
 * @param color input in RGB888 format
 * @note  data will be translated into RGB565 format
 */
void tft_set_draw_color (uint32_t color)
{
    // convert the colors to 565 format
    draw_color565 = (uint16_t)(((color >> 8) & 0b1111100000000000u) | ((color >> 5) & 0b0000011111100000u) | ((color >> 3) & 0b0000000000011111u));
}


/**
 * @brief  get the actual color for the drawing commands like rect, line, ...
 * @return actual color in RGB565 format
 */
uint16_t tft_get_draw_color (void)
{
    // convert the colors to 565 format
    return((uint16_t)draw_color565) ;
}

/**
 * @brief draw rectangular filled shape
 * @param x1 (top left)
 * @param y1 (top left)
 * @param x2 (bottom right)
 * @param y2 (bottom right)
 */
void tft_draw_rect( int16_t x1, int16_t y1, int16_t x2, int16_t y2){
    uint16_t color565 ;
    tft_defineRegion_s actRegionSettings ;
    uint16_t width, height ;
    /* define the region */

#ifdef TFT_POLL
    actRegionSettings = tft_defineRegion(x1, y1, x2, y2,false);
#else
    // run only the calculations for the valid window
    actRegionSettings = tft_defineRegion(x1, y1, x2, y2,true);
#endif

    if ( actRegionSettings.invalid )
        return ;

    // convert the colors to 565 format
    color565 = tft_get_draw_color();

    // optimize memory transfer less loops more data transfer per command
    if ( actRegionSettings.height < actRegionSettings.width) {
        width = actRegionSettings.width;
        height= actRegionSettings.height;
    } else {
        width =actRegionSettings.height;
        height=actRegionSettings.width;
    }

    // create a buffer with single color elements
    tft_wait_for_spi();
    memset16(tft_function_tx_buffer16, color565, width);
    tft_callback_tx_buffer16[6] = ILI9341_RAMWR;

#ifdef TFT_POLL
    R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CS, BSP_IO_LEVEL_LOW);
    tft_write_command((uint8_t*)&tft_callback_tx_buffer16[6], 1);
    tft_write_src_clip_data16(tft_function_tx_buffer16, 0, width, height);
    R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CS, BSP_IO_LEVEL_HIGH);
#else
    /* run in interrupt routine to avoid polling */
    tft_function_tx_buffer16_send_length = width ;
    tft_function_tx_buffer16_send_repeat = height ;
    tft_callback_next_jump_state = TFT_DRAW_RECT ;
    tft_run_cmd(TFT_SET_WINDOW) ;
    tft_wait_for_spi();
#endif

}

/**
 * @brief clear the TFT screen with a defined color
 * @param color RGB format
 */
void tft_cls(uint32_t color)
{
  uint16_t draw_color565_back = tft_get_draw_color();
  tft_set_draw_color(color);
  tft_draw_rect(0,0,option.act_width-1,option.act_height-1);
  draw_color565 = draw_color565_back ;
}


/**
 * @bief draw horizontal line
 * @param x1 left position
 * @param y1 position
 * @param x2 right position
 * @param line_size siz of drawing line
 */
void tft_draw_h_line( int16_t x1, int16_t y1, int16_t x2, uint16_t line_size)
{
    tft_draw_rect( x1,  y1,  x2,  (int16_t)(y1 + line_size - 1));
}

/**
 * @bief draw vertical line
 * @param x1 left position
 * @param y1 position
 * @param x2 right position
 * @param line_size size of drawing line
 */
void tft_draw_v_line( int16_t x1, int16_t y1, int16_t y2, uint16_t line_size)
{
    tft_draw_rect( x1,  y1,  (int16_t)(x1 + line_size-1),  y2);
}

/**
 * @brief draw a filled circle
 * @param x center position
 * @param y center position
 * @param r radius in pixel
 * @note  center coordinate only matches for odd radius vvlues
 */
void tft_draw_filled_circle(int16_t x, int16_t y, uint16_t r)
{
    int16_t dx = (int16_t)r;
    int16_t dy = 0;
    int16_t ovflow = 1 - dx;

    while (dy <= dx)
    {
        // TDO overlapping write operations, some room for speed up by considering dx in boxing
        tft_draw_rect (-dy + x, dx + y, dy + x, dx + y); //quadrant 2,3
        tft_draw_rect (-dx + x, dy + y, dx + x, dy + y); //quadrant 1,4
        tft_draw_rect (-dx + x, -dy + y, dx + x, -dy + y); //quadrant 5,8
        tft_draw_rect (-dy + x, -dx + y, dy + x, -dx + y); //quadrant 6,7
        dy++;
        if (ovflow <= 0)
        {
            ovflow += (int16_t)(2 * dy + 1);
        }
        else
        {
            dx--;
            ovflow += (int16_t)(2 * (dy - dx) + 1);
        }
    }
}



/**
 * @brief draw line with 1 pixel fixed size
 * @param x1 left position
 * @param y1 position
 * @param x2 right position
 * @param line_size size of drawing line
 */
void tft_draw_line(int16_t x1, int16_t y1, int16_t x2, int16_t y2)
{
    int16_t dx, step_x;
    int16_t dy, step_y;
    int16_t step_error, step_error_cmp = 0;

    if (x1 == x2 || y1 == y2)
    {
        tft_draw_rect (x1, y1, x2, y2);
        return;
    }

    if (x1 > x2)
    {
        dx = x1 - x2;
        step_x = -1;
    }
    else
    {
        dx = x2 - x1;
        step_x = 1;
    }

    if (y1 > y2)
    {
        dy = y1 - y2;
        step_y = -1;
    }
    else
    {
        dy = y2 - y1;
        step_y = 1;
    }
    step_error = (dx > dy ? dx : -dy) / 2;

    tft_draw_rect (x1, y1, x1, y1);

    while (x1 != x2 || y1 != y2)
    {

        step_error_cmp =  step_error;
        if (step_error_cmp > -dx)
        {
            step_error -=  dy;
            x1 += step_x;
        }
        if (step_error_cmp < dy)
        {
            step_error += dx;
            y1 += step_y;
        }

        tft_draw_rect (x1, y1, x1, y1);
    }


}


/**
 * @brief draw a circle
 * @param x center position
 * @param y center position
 * @param r radius in pixel
 * @note center coordinate only matches for odd radius values
 * @note line width setting ignored only 1 pixel for now
 */
void tft_draw_circle(int16_t x, int16_t y, uint16_t r)
{
    int16_t dx = (int16_t)r;
    int16_t dy = 0;
    int16_t ovflow = 1 - dx;

    while (dy <= dx)
    {
        // TDO overlapping write operations, some room for speed up by considering dx in boxing

        // ul
        tft_draw_rect (-dy + x,  dx + y, -dy + x,  dx + y ); //quadrant 2
        // ur
        tft_draw_rect ( dy + x,  dx + y,  dy + x,  dx + y ); //quadrant 3

        // ul
        tft_draw_rect (-dx + x,  dy + y, -dx + x,  dy + y ); //quadrant 1
        // ur
        tft_draw_rect ( dx + x,  dy + y,  dx + x,  dy + y ); //quadrant 4


        // ol
        tft_draw_rect (-dx + x, -dy + y, -dx + x, -dy + y ); //quadrant 8
        // or
        tft_draw_rect ( dx + x, -dy + y,  dx + x, -dy + y ); //quadrant 5

        // ol
        tft_draw_rect (-dy + x, -dx + y, -dy + x, -dx + y ); //quadrant 7
        // or
        tft_draw_rect ( dy + x, -dx + y,  dy + x, -dx + y ); //quadrant 6

        dy++;

        if (ovflow <= 0)
        {
            ovflow += (int16_t)((int16_t)2 * (int16_t)dy + (int16_t)1);
        }
        else
        {
            dx--;
            ovflow += (int16_t)((int16_t)2 * (int16_t)(dy - dx) + (int16_t)1);
        }
    }
}




/**
 * @brief draw a frame box
 * @param x start (top left)
 * @param y start (top left)
 * @param w width of box
 * @param h height of box
 * @param line_size line size
 */
void tft_draw_frame(int16_t x, int16_t y, uint16_t w, uint16_t h, uint16_t line_size)
{
    // horizontal top
    tft_draw_h_line(  x,  y, (int16_t)(x + w - 1) , line_size) ;

    // vertical left
    tft_draw_v_line( x, (int16_t)(y + line_size),(int16_t)( y + h - 1 - line_size), line_size);

    // vertical right
    tft_draw_v_line( (int16_t)(x + w - line_size) , (int16_t)(y + line_size), (int16_t)(y + h -1 - line_size), line_size);

    // horizontal bottom
    tft_draw_h_line( x, (int16_t)(y + h - 1 -line_size), (int16_t)(x + w - 1), line_size);
}


/**
 * @brief blending function on  RGB565 color space
 * @param basePixel color RGB565 value of existing pixel
 * @param newPixel  color RGB565 value of new drawing pixel
 * @param alpha     alpha value [0-255] 255 - new over writes old
 * @return          color RGB565 value after alpha blending
 */
/*
 *
 * Alpha Blending simplified from calculation point of view.
 * resultPixel = basePixel * ( 1 - alpha ) + newPixel * alpha
 * resultPixel = basePixel - basePixel* alpha + newPixel * alpha
 * finally we get
 * resultPixel = basePixel + ( newPixel - basePixel ) * alpha
 * RGB565 the lowest number of used pixel is 5 so alpha can be reduced to [0-31]
 * Alpha will be of type int8_t, pixel data uint16_t
 * For implementation we want to have [0-32] as range, because than we can use a shift >> 3 instead of a divider
 * We can add 1, 2, 3, 4, 5, 6, 7 to alpha before shift.
 * Lets's start with a 1 for the moment (mainly an increment unit)
 * Implementation preparation
 * alpha = ( alpha + 1 ) >> 3
 * resultPixel = basePixel + (( newPixel - basePixel ) * alpha ) >> 5
 * looks nice so far, but we have our color data in a packet format
 * 1 - unpack into R G B channel and calculate separately
 * 2 - Eliminate G and calculate on R - B and - G - separately --> negative number problem for channels
 * 3 - convert 16 bit into 32 bit with mirroring and mask  - G - R - B --> negative number problem for channels
 * Which version to use?
 * lets take 1 for implementation with a union / struct for element access
 * 2 and 3 needs additional operation to overcome the negative number problem
 */
uint16_t tft_blend_pixel(uint16_t basePixel, uint16_t newPixel, uint8_t alpha)
{
    pmd_rgb565_color_u color_b, color_n, color_r;
    // preparation
    color_b.rgb565 = basePixel;
    color_n.rgb565 = newPixel;
    uint16_t alpha16 =  (uint16_t)((uint16_t)alpha + (uint16_t)1) >> 3;

    // The following lines creates warnings with -Wconversion
    // There is no cast operation like (uint8_t:5) available so have to be ignored
    color_r.channel.r = (uint8_t) ((int16_t) color_b.channel.r
            + ((((int16_t) color_n.channel.r - (int16_t) color_b.channel.r) * alpha16) >> 5));
    color_r.channel.g = (uint8_t) ((int16_t) color_b.channel.g
            + ((((int16_t) color_n.channel.g - (int16_t) color_b.channel.g) * alpha16) >> 5));
    color_r.channel.b = (uint8_t) ((int16_t) color_b.channel.b
            + ((((int16_t) color_n.channel.b - (int16_t) color_b.channel.b) * alpha16) >> 5));

    return (color_r.rgb565); // RGB565 format
}


/***********************************************************************************************************************
 *
 * Touch routines
 *
 ***********************************************************************************************************************/

/**
 * @brief send commnad to touch controller
 * @param tx_buffer send buffer
 * @param length number of bytes to transfer
 */
void tft_touch_write_command (uint8_t *tx_buffer, uint16_t length)
{
    fsp_err_t err = FSP_SUCCESS;

    tft_wait_for_spi();
    g_pmod1_event_flag = 0 ;
#ifndef TFT_USE_CSI_SPI
    err = R_SPI_Write (&TFT_SPI_CTRL, tx_buffer, length, SPI_BIT_WIDTH_8_BITS);
#else
    err = R_SCI_SPI_Write (&TFT_SPI_CTRL, tx_buffer, length, SPI_BIT_WIDTH_8_BITS);
#endif
    if (FSP_SUCCESS != err)
    {
#ifdef SEGGER_DEBUG_ON
        APP_MESSAGE("** TFT_CASET cmd failed **\r\n");
#else
        __BKPT(0);
#endif
    }
    tft_wait_for_spi();
    // cmd pin to data mode
}


/**
 * @brief send a command to the touch controller and read the result
 * @param cmd controller command
 * @return read back value
 */
uint16_t tft_touch_read_data (uint8_t cmd)
{
    uint8_t rx_buffer[2];
    uint16_t temp ;
    fsp_err_t err = FSP_SUCCESS;
    /* set display command mode */

    tft_wait_for_spi();
    g_pmod1_event_flag = 0 ;
#ifndef TFT_USE_CSI_SPI
    err = R_SPI_Write (&TFT_SPI_CTRL, &cmd, 1, SPI_BIT_WIDTH_8_BITS);
#else
    err = R_SCI_SPI_Write (&TFT_SPI_CTRL, &cmd, 1, SPI_BIT_WIDTH_8_BITS);
#endif
    if (FSP_SUCCESS != err)
    {
#ifdef SEGGER_DEBUG_ON
      APP_MESSAGE("** TFT send cmd  failed **\r\n");
#else
      __BKPT(0);
#endif
    }

    tft_wait_for_spi ();
    g_pmod1_event_flag = 0;
#ifndef TFT_USE_CSI_SPI
    err = R_SPI_Read (&TFT_SPI_CTRL, rx_buffer, 2, SPI_BIT_WIDTH_8_BITS);
#else
    err = R_SCI_SPI_Read (&TFT_SPI_CTRL, rx_buffer, 2, SPI_BIT_WIDTH_8_BITS);
#endif
    if (FSP_SUCCESS != err)
    {
#ifdef SEGGER_DEBUG_ON
        APP_MESSAGE("** TFT read data failed **\r\n");
#else
        __BKPT(0);
#endif

    }

    tft_wait_for_spi();
    temp = (uint16_t)((((uint16_t)rx_buffer[0]) << 5) + (((uint16_t)rx_buffer[1]) >> 3));
    return (temp);
}

/**
 * @brief read raw data from touch controller
 * @note results are stored in touch_ctrl struct
 */
void tft_touch_read_raw(void)
{
    uint16_t x_act = 0, y_act = 0, p_act = 0;
    uint32_t x_cal = 0, y_cal = 0, p_cal = 0;
    uint16_t max_value_x = 0;
    uint16_t max_value_y = 0;
    uint16_t max_value_p = 0;
    uint16_t min_value_x = USHRT_MAX;
    uint16_t min_value_y = USHRT_MAX;
    uint16_t min_value_p = USHRT_MAX;

    tft_wait_for_spi ();
    // set the reduced SPI baudrate for reading data from the controller
#ifndef TFT_USE_CSI_SPI
    r_spi_hw_config_baudrate (&TFT_SPI_CTRL, &tft_spck_div[TFT_SPI_TOUCH]);
#else
    r_sci_spi_hw_config_baudrate(&TFT_SPI_CTRL, &tft_spck_div[TFT_SPI_TOUCH]);
#endif

    R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TOUCH_CS, BSP_IO_LEVEL_LOW);

    // get a specified number of samples of touch values
    // skip one minimum and one maximum number ove x, y and pressure values
    for (uint16_t i = 0; i < XPT2046_AVERAGE_READS; i++)
    {
        x_act = tft_touch_read_data (XPT2046_CMD_READ_XPOS);
        if (x_act > max_value_x)
            max_value_x = x_act;
        if (x_act < min_value_x)
            min_value_x = x_act;
        x_cal += x_act;

        y_act = tft_touch_read_data (XPT2046_CMD_READ_YPOS);
        if (y_act > max_value_y)
            max_value_y = y_act;
        if (y_act < min_value_y)
            min_value_y = y_act;
        y_cal += y_act;

        p_act = tft_touch_read_data (XPT2046_CMD_READ_PRESS);
        if (p_act > max_value_p)
            max_value_p = p_act;
        if (p_act < min_value_p)
            min_value_p = p_act;
        p_cal += p_act;
    }

    p_cal = (p_cal - max_value_p - min_value_p) / (XPT2046_AVERAGE_READS - 2);
    x_cal = (x_cal - max_value_x - min_value_x) / (XPT2046_AVERAGE_READS - 2);
    y_cal = (y_cal - max_value_y - min_value_y) / (XPT2046_AVERAGE_READS - 2);

    // store the raw data
    touch_ctrl.touch_x_raw = (uint16_t) x_cal;
    touch_ctrl.touch_y_raw = (uint16_t) y_cal;
    touch_ctrl.touch_press_raw = (uint16_t) p_cal;

    R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TOUCH_CS, BSP_IO_LEVEL_HIGH);
    // set the full speed SPI baudrate for writing data to the display controller
#ifndef TFT_USE_CSI_SPI
    r_spi_hw_config_baudrate (&TFT_SPI_CTRL, &tft_spck_div[TFT_SPI_SEND]);
#else
    r_sci_spi_hw_config_baudrate(&TFT_SPI_CTRL, &tft_spck_div[TFT_SPI_SEND]);
#endif

    // transform to display coordinate system
    tft_touch_transform ();

}

/**
 * @brief calculate the positions related to display orientation
 * @note also handles the calibration data
 * @note data stored in touch_ctrl struct
 */
void tft_touch_transform(void)
{
    int32_t x_cal = (int32_t) touch_ctrl.touch_x_raw;
    int32_t y_cal = (int32_t) touch_ctrl.touch_y_raw;
    uint16_t p_cal = touch_ctrl.touch_press_raw;

    if (p_cal > XPT2046_PRESSURE_REC)
    {

        {
            // pressure calculation is x depending, calculation to t.b.d
            if (p_cal < 255)
                touch_ctrl.touch_press = p_cal;
            else
                touch_ctrl.touch_press = 255;

            // adapt to rotation of display
            if (touch_ctrl.touch_adapt[option.act_oritentation].swap_xy == true)
            {
                int32_t swap;
                swap = x_cal;
                x_cal = y_cal;
                y_cal = swap;
            }

            if (touch_ctrl.touch_adapt[option.act_oritentation].mirror_x == true)
            {
                x_cal = XPT2046_DATA_MAX - x_cal;
            }
            if (touch_ctrl.touch_adapt[option.act_oritentation].mirror_y == true)
            {
                y_cal = XPT2046_DATA_MAX - y_cal;
            }

            int32_t xe = ((int32_t) x_cal * 1024 - touch_ctrl.touch_adapt[option.act_oritentation].offsx)
                    / touch_ctrl.touch_adapt[option.act_oritentation].dx;

            if (xe < 0)
                xe = 0;
            if (xe >= option.act_width)
                xe = option.act_width - 1;
            touch_ctrl.touch_x = (uint16_t) xe;

            int32_t ye = ((int32_t) y_cal * 1024 - touch_ctrl.touch_adapt[option.act_oritentation].offsy)
                    / touch_ctrl.touch_adapt[option.act_oritentation].dy;
            if (ye < 0)
                ye = 0;
            if (ye >= option.act_height)
                ye = option.act_height - 1;
            touch_ctrl.touch_y = (uint16_t) ye;
#ifdef SEGGER_DEBUG_ON
            APP_PRINT("g_touch_press %d x= %04d  y= %04d  p= %04d  \r\n", g_touch_press, touch_ctrl.touch_x,
                      touch_ctrl.touch_y, touch_ctrl.touch_press);
#endif
        }
    }
    else
    {
        g_touch_press = false;
    }

}


/***********************************************************************************************************************
 *
 * Interrupt routines
 *
 ***********************************************************************************************************************/


//__attribute__ ((section(".code_in_ram")))

/**
 * @brief PMOD1 SPI callback function.
 * @param[in]  p_args
 * @retval     None
 * @note      tft_callback_act_state defines the actual execution state
 * @note      g_pmod1_event_flagshow status of state machine
 **********************************************************************************************************************/
 void TFT_SPI_CALLBACK(spi_callback_args_t * p_args)
{
    switch(tft_callback_act_state)
    {
        // Set Window
        case TFT_SET_WINDOW:
            g_pmod1_event_flag = 0 ;
            R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CS, BSP_IO_LEVEL_LOW);
            // FALLTHRU
            // No break
        case TFT_SET_WINDOW_send_cmd_1:
            R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CD, BSP_IO_LEVEL_LOW);
            tft_callback_next_state = TFT_SET_WINDOW_send_data16_1 ;
#ifndef TFT_USE_CSI_SPI
            R_SPI_Write (&TFT_SPI_CTRL, &tft_callback_tx_buffer16[0], 1, SPI_BIT_WIDTH_8_BITS);
#else
            R_SCI_SPI_Write (&TFT_SPI_CTRL, &tft_callback_tx_buffer16[0], 1, SPI_BIT_WIDTH_8_BITS);
#endif
            break;
        case TFT_SET_WINDOW_send_data16_1:
            R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CD, BSP_IO_LEVEL_HIGH);
            tft_callback_next_state = TFT_SET_WINDOW_send_cmd_2 ;

#ifndef TFT_SPI_8BIT_ONLY
            // 2, we will write one dummy word at the end
            R_SPI_Write (&TFT_SPI_CTRL, &tft_callback_tx_buffer16[1], 3, SPI_BIT_WIDTH_16_BITS);
#else
            lineBuffer[0] = __builtin_bswap16(tft_callback_tx_buffer16[1]) ;
            lineBuffer[1] = __builtin_bswap16(tft_callback_tx_buffer16[2]) ;
#ifndef TFT_USE_CSI_SPI
            R_SPI_Write (&TFT_SPI_CTRL, (const void *)lineBuffer, 4, SPI_BIT_WIDTH_8_BITS);
#else
            R_SCI_SPI_Write (&TFT_SPI_CTRL, (const void *)lineBuffer, 4, SPI_BIT_WIDTH_8_BITS);
#endif
#endif

            break;
        case TFT_SET_WINDOW_send_cmd_2:
            R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CD, BSP_IO_LEVEL_LOW);
            tft_callback_next_state = TFT_SET_WINDOW_send_data16_2 ;
#ifndef TFT_USE_CSI_SPI
            R_SPI_Write (&TFT_SPI_CTRL, &tft_callback_tx_buffer16[3], 1, SPI_BIT_WIDTH_8_BITS);
#else
            R_SCI_SPI_Write (&TFT_SPI_CTRL, &tft_callback_tx_buffer16[3], 1, SPI_BIT_WIDTH_8_BITS);
#endif
            break;
        case TFT_SET_WINDOW_send_data16_2:
            R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CD, BSP_IO_LEVEL_HIGH);
            tft_callback_next_state = tft_callback_next_jump_state ;
            tft_callback_next_jump_state = TFT_FREE_RUN_CS_HIGH ;
#ifndef TFT_SPI_8BIT_ONLY
            // 2, we will write one dummy word at the end
            R_SPI_Write (&TFT_SPI_CTRL, &tft_callback_tx_buffer16[4], 3, SPI_BIT_WIDTH_16_BITS);
#else
            lineBuffer[0] = __builtin_bswap16(tft_callback_tx_buffer16[4]) ;
            lineBuffer[1] = __builtin_bswap16(tft_callback_tx_buffer16[5]) ;
#ifndef TFT_USE_CSI_SPI
            R_SPI_Write (&TFT_SPI_CTRL, (const void *)lineBuffer, 4, SPI_BIT_WIDTH_8_BITS);
#else
            R_SCI_SPI_Write (&TFT_SPI_CTRL, (const void *)lineBuffer, 4, SPI_BIT_WIDTH_8_BITS);
#endif
#endif
            break;
            // draw a filled rectangle
        case TFT_DRAW_RECT:
            //LED RED used for time measurement
            //R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_09_PIN_07, 0);

            g_pmod1_event_flag = 0 ;
            R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CS, BSP_IO_LEVEL_LOW);
            // FALLTHRU
            // No break
        case TFT_DRAW_RECT_send_cmd:
            R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CD, BSP_IO_LEVEL_LOW);
            tft_callback_next_state = TFT_DRAW_RECT_send_data16_loop_pre ;
#ifndef TFT_USE_CSI_SPI
            R_SPI_Write (&TFT_SPI_CTRL, &tft_callback_tx_buffer16[6], 1, SPI_BIT_WIDTH_8_BITS);
#else
            R_SCI_SPI_Write (&TFT_SPI_CTRL, &tft_callback_tx_buffer16[6], 1, SPI_BIT_WIDTH_8_BITS);
#endif
            break;
        case TFT_DRAW_RECT_send_data16_loop_pre:
            R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CD, BSP_IO_LEVEL_HIGH);
            // FALLTHRU
            // No break
        case TFT_DRAW_RECT_send_data16_loop:

#ifndef TFT_SPI_8BIT_ONLY
            R_SPI_Write (&TFT_SPI_CTRL, tft_function_tx_buffer16_send_addr, tft_function_tx_buffer16_send_length,
                         SPI_BIT_WIDTH_16_BITS);
#else
            for (uint16_t cnt=0; cnt < tft_function_tx_buffer16_send_length; cnt++)
                lineBuffer[cnt] = __builtin_bswap16(tft_function_tx_buffer16_send_addr[cnt]) ;
#ifndef TFT_USE_CSI_SPI
            R_SPI_Write (&TFT_SPI_CTRL, ((char *)(lineBuffer)), tft_function_tx_buffer16_send_length*2,
                         SPI_BIT_WIDTH_8_BITS);
#else
            R_SCI_SPI_Write (&TFT_SPI_CTRL, ((char *)(lineBuffer)), tft_function_tx_buffer16_send_length*2,
                         SPI_BIT_WIDTH_8_BITS);
#endif
#endif

            if (tft_function_tx_buffer16_send_repeat > 1)
            {
                tft_function_tx_buffer16_send_repeat--;
                tft_function_tx_buffer16_send_addr += tft_function_tx_buffer16_send_pitch;
                tft_callback_next_state = TFT_DRAW_RECT_send_data16_loop;
            }
            else
            {
                tft_callback_next_state = TFT_FREE_RUN_CS_HIGH;
            }
        break;
        case TFT_READ_RECT:
            g_pmod1_event_flag = 0 ;
            R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CS, BSP_IO_LEVEL_LOW);
            // FALLTHRU
            // No break
        case TFT_READ_RECT_send_cmd:
            R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CD, BSP_IO_LEVEL_LOW);
            tft_callback_next_state = TFT_READ_RECT_receive_data24_loop_pre ;
#ifndef TFT_USE_CSI_SPI
            R_SPI_Write (&TFT_SPI_CTRL, &tft_callback_tx_buffer16[6], 1, SPI_BIT_WIDTH_8_BITS);
#else
            R_SCI_SPI_Write (&TFT_SPI_CTRL, &tft_callback_tx_buffer16[6], 1, SPI_BIT_WIDTH_8_BITS);
#endif
            break;
        case TFT_READ_RECT_receive_data24_loop_pre:
            R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CD, BSP_IO_LEVEL_HIGH);
#ifndef TFT_USE_CSI_SPI
            R_SPI_Read (&TFT_SPI_CTRL, tft_function_tx_buffer8_send_addr, 1, SPI_BIT_WIDTH_8_BITS);
#else
            R_SCI_SPI_Read (&TFT_SPI_CTRL, tft_function_tx_buffer8_send_addr, 1, SPI_BIT_WIDTH_8_BITS);
#endif
            tft_callback_next_state = TFT_READ_RECT_receive_data24_loop ;
            break;
        case TFT_READ_RECT_receive_data24_loop:
#ifndef TFT_USE_CSI_SPI
            R_SPI_Read (&TFT_SPI_CTRL, (uint8_t*)tft_function_tx_buffer8_send_addr, tft_function_tx_buffer16_send_length * 3, SPI_BIT_WIDTH_8_BITS);
#else
            R_SCI_SPI_Read (&TFT_SPI_CTRL, (uint8_t*)tft_function_tx_buffer8_send_addr, tft_function_tx_buffer16_send_length * 3, SPI_BIT_WIDTH_8_BITS);
#endif
            if ( tft_function_tx_buffer16_send_repeat > 1 ){
                tft_function_tx_buffer16_send_repeat--;
                tft_function_tx_buffer8_send_addr += tft_function_tx_buffer16_send_pitch * 3 ;
                tft_callback_next_state = TFT_READ_RECT_receive_data24_loop ;
            } else {
                tft_callback_next_state = TFT_FREE_RUN_CS_HIGH ;
            }
            break;
        case TFT_FREE_RUN_CS_HIGH:
            //Restore the default values
            tft_function_tx_buffer16_send_pitch  = 0 ;
            tft_function_tx_buffer16_send_addr   = tft_function_tx_buffer16 ;
            R_IOPORT_PinWrite (&g_ioport_ctrl, PM_TFT_CS, BSP_IO_LEVEL_HIGH);

            //LED RED used for time measurement
            //R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_09_PIN_07, 1);

            // FALLTHRU
            // No break
        case TFT_FREE_RUN:
        default:
            if ( p_args != NULL) {
                if (SPI_EVENT_TRANSFER_COMPLETE == p_args->event)
                {
                    g_pmod1_event_flag = SPI_EVENT_TRANSFER_COMPLETE;
                }
                else
                {
                    g_pmod1_event_flag = SPI_EVENT_TRANSFER_ABORTED;
                }
            } else {
                g_pmod1_event_flag = SPI_EVENT_TRANSFER_ABORTED;
            }
            tft_callback_next_state = TFT_FREE_RUN ;
            break;
    }
    tft_callback_act_state = tft_callback_next_state ;
}

//t.b.d under development
void tft_touch_calibrate(void)
{
    uint32_t x_cal = 0, y_cal = 0;
    //uint16_t p_cal = 0;

    // draw point 1
    float XA = 10.0, YA = 10.0;
    // draw point 2
    float XB = (float) option.act_width - (float) 10.0, YB = (float) option.act_height - (float) 10.0;

    // the following can be done automatically by two probe positions
    // on the same axis
    bool swap_xy = false;
    bool mirror_x = false;
    bool mirror_y = false;

    if (option.act_oritentation == TFT_R90)
    {
        swap_xy = true;
        mirror_x = true;
        mirror_y = true;
    }

    if (option.act_oritentation == TFT_R270)
        swap_xy = true;

    if (option.act_oritentation == TFT_R0)
        mirror_y = true;

    if (option.act_oritentation == TFT_R180)
        mirror_x = true;

    // calc prepare
    if (swap_xy)
    {
        uint32_t swap = x_cal;
        x_cal = y_cal;
        y_cal = swap;
    }
    if (mirror_x == true)
        x_cal = XPT2046_DATA_MAX - x_cal;
    if (mirror_y == true)
        y_cal = XPT2046_DATA_MAX - y_cal;

    // draw point 1 upper left corner
    // Top left cross
    tft_set_draw_color(0xffffff);
    tft_draw_h_line(5, 10, 15, 1);
    tft_draw_v_line(10, 5, 15, 1);

    // read touch position x0, y0

    // delete touch position one
    // draw point 2 bottom right corner
    // bottom right cross
    tft_draw_h_line(option.act_width-15, option.act_height-10, option.act_width-5, 1);
    tft_draw_v_line(option.act_width-10, option.act_height-15, option.act_height-5, 1);

    // read touch position x1, y1
    // delete touch position two

// manual input for the moment
// top left position cross x0,y0
    float x0 = 398.0, y0 = 466.0;
// bottom right positions cross
    float x1 = 3716.0, y1 = 3838.0;

    int32_t dx = ((int32_t) (x1 - x0) * 1024) / (int32_t) (XB - XA);
    int32_t dy = ((int32_t) (y1 - y0) * 1024) / (int32_t) (YB - YA);
    int32_t offsx = (int32_t) x0 * 1024 - (int32_t) XA * dx;
    int32_t offsy = (int32_t) y0 * 1024 - (int32_t) YA * dy;

#ifdef SEGGER_DEBUG_ON
    APP_PRINT("dx= 0x%04x dy= 0x%04x  offsx= 0x%04x offsy= 0x%04x swap= %d mirror_x= %d mirror_y= %d\r\n", dx, dy,
              offsx, offsy, swap_xy, mirror_x, mirror_y);
    APP_PRINT("{0x%04x, 0x%04x, 0x%04x, 0x%04x, 0x%04x, 0x%04x, 0x%04x}\r\n", dx, dy, offsx, offsy, swap_xy, mirror_x,
              mirror_y);
#endif

    // rerun for all four rotations
    // transfer data to ee-prom????
}



