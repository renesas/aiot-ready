/***********************************************************************************************************************
 * File Name    : xpt2046.h
 * Description  : Contains macros, data structures and functions used  common to the EP
 ***********************************************************************************************************************/

#ifndef PMD_TFT_XPT2046_H_
#define PMD_TFT_XPT2046_H_

/* incase c++ */
#if defined(__cplusplus)
extern "C" {
#endif

// commands for the controller
#define XPT2046_CMD_READ_XPOS  (0xD0)
#define XPT2046_CMD_READ_YPOS  (0x90)
#define XPT2046_CMD_READ_PRESS (0xB0)
#define XPT2046_DATA_MAX       (4095)
#define XPT2046_PRESSURE_REC   (14)

// Number of reread for average calculation
#define XPT2046_AVERAGE_READS  5

// Max Baudrate is 2.5MHz
#define XPT2046_SPI_BAUDRATE    2500000
//#define XPT2046_SPI_BAUDRATE    1250000

/* incase c++ */
#if defined(__cplusplus)
}
#endif

#endif /* PMD_TFT_XPT2046_H_ */
