
/***********************************************************************************************************************
 * File Name    : pmd_hw_interface.h
 * Description  : Contains macros, data structures and functions used  common to the EP
 ***********************************************************************************************************************/
/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/

#ifndef PMD_TFT_PMD_HW_INTERFACE_H_
#define PMD_TFT_PMD_HW_INTERFACE_H_

// Lets check for the existing include files
// AIK-RA6M3 BOARD
#if defined(BOARD_RA6M3_AIK)
  //#define TFT_ON_PMOD1
  #define TFT_ON_PMOD3
#endif

// AIK-RA4E1 BOARD
#if defined(BOARD_RA4E1_AIK)
  //#define TFT_ON_PMOD1
  #define TFT_ON_PMOD2
#endif

// ORION BOARD
#if defined(BOARD_RA6M3_ORION)
  #define TFT_ON_PMOD1
#endif

#include "PMD_TFT/pmd_tft.h"

/* incase c++ */
#if defined(__cplusplus)
 extern "C" {
#endif

//AIK-RA6M3 definitions
#include "PMD_TFT/pmd_hw_interface_aik_ra6m3.h"

//AIK-RA4E1 definitions
#include "PMD_TFT/pmd_hw_interface_aik_ra4e1.h"

//ORION-RA6M3 definitions
#include "PMD_TFT/pmd_hw_interface_orion_ra6m3.h"


// USe default setting RA6M3G development board
#ifndef  BOARD_RAxx_FOUND

ERROR DISPLAY NOT SUPPORTED

#define PM_TFT_CS    BSP_IO_PORT_02_PIN_05
#define PM_TFT_RESET BSP_IO_PORT_08_PIN_00
#define PM_TFT_CD    BSP_IO_PORT_08_PIN_01

#define PM_TFT_MISO  BSP_IO_PORT_02_PIN_02
#define PM_TFT_MOSI  BSP_IO_PORT_02_PIN_03
#define PM_TFT_SCK   BSP_IO_PORT_02_PIN_04

#define PM_TOUCH_CS  BSP_IO_PORT_08_PIN_02
#define PM_TOUCH_IRQ BSP_IO_PORT_00_PIN_04

#define TFT_SPI_SEND_BAUDRATE    40000000
#define TFT_SPI_RECEIVE_BAUDRATE 20000000

#endif

//  RSPI has only 8bit interface so automatically switch to 8bit mode for RSPI
//#define TFT_SPI_8BIT_ONLY
#ifdef TFT_USE_CSI_SPI
#define TFT_SPI_8BIT_ONLY
#endif

/* incase c++ */
#if defined(__cplusplus)
 }
#endif

#endif /* PMD_TFT_PMD_HW_INTERFACE_H_ */
