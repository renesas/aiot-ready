/***********************************************************************************************************************
 * File Name    : font.h
 * Description  : data structures and font information for main program usage (please include this file)
 ***********************************************************************************************************************/

#ifndef DRW_USR_FONT_H_
#define DRW_USR_FONT_H_

#include <stdint.h>

/* incase c++ */
#if defined(__cplusplus)
extern "C" {
#endif


/* available fonts */
#define FONTDATA_NUM (3u)

typedef struct
{
    uint16_t font_width;       /* pixel num */
    uint16_t font_height;      /* pixel num */
    uint16_t font_char_pitch;  /* pitch in bytes from one char to the next */
    uint16_t font_char_valid;  /* first valid char in the font data */
    uint32_t font_array_size;  /* size of data array*/
    uint16_t font_char_bytes ; /* bytes used per row in char [pitch] */
    uint16_t font_has_rotate ; /* 0, 90 (rotation of character in the source */
    uint8_t *font_addr;        /* pointer to font structure */
} singlefont_s;

//extern uint16_t     const fontdata_12x24[];
//extern uint8_t      const fontdata_8x16[];
//extern uint8_t      const fontdata_8x6_r90[];
//extern uint8_t      const fontdata_6x8[];

extern singlefont_s const font_array[FONTDATA_NUM];

// Please use the correct setting for buffer allocation of the used font with the highest memory consumption
// in our actual case it is FONTDATA_12X24_WIDTH * FONTDATA_12X24_HEIGHT
// defines are not in scope so please use the numbers instead
#define FONT_MAX_WIDTH_MUL_HEIGHT  ( 12 * 24 )

/* incase c++ */
#if defined(__cplusplus)
}
#endif

#endif /* DRW_USR_FONT_H_ */
