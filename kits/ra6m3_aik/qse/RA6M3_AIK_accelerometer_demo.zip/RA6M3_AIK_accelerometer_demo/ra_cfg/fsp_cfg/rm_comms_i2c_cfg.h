/* generated configuration header file - do not edit */
#ifndef RM_COMMS_I2C_CFG_H_
#define RM_COMMS_I2C_CFG_H_
#ifdef __cplusplus
extern "C" {
#endif

#define RM_COMMS_I2C_CFG_PARAM_CHECKING_ENABLE          (BSP_CFG_PARAM_CHECKING_ENABLE)

#ifdef __cplusplus
}
#endif
#endif /* RM_COMMS_I2C_CFG_H_ */
