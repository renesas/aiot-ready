/***********************************************************************************************************************
 * Copyright [2020-2023] Renesas Electronics Corporation and/or its affiliates.  All Rights Reserved.
 *
 * This software and documentation are supplied by Renesas Electronics America Inc. and may only be used with products
 * of Renesas Electronics Corp. and its affiliates ("Renesas").  No other uses are authorized.  Renesas products are
 * sold pursuant to Renesas terms and conditions of sale.  Purchasers are solely responsible for the selection and use
 * of Renesas products and Renesas assumes no liability.  No license, express or implied, to any intellectual property
 * right is granted by Renesas. This software is protected under all applicable laws, including copyright laws. Renesas
 * reserves the right to change or discontinue this software and/or this documentation. THE SOFTWARE AND DOCUMENTATION
 * IS DELIVERED TO YOU "AS IS," AND RENESAS MAKES NO REPRESENTATIONS OR WARRANTIES, AND TO THE FULLEST EXTENT
 * PERMISSIBLE UNDER APPLICABLE LAW, DISCLAIMS ALL WARRANTIES, WHETHER EXPLICITLY OR IMPLICITLY, INCLUDING WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT, WITH RESPECT TO THE SOFTWARE OR
 * DOCUMENTATION.  RENESAS SHALL HAVE NO LIABILITY ARISING OUT OF ANY SECURITY VULNERABILITY OR BREACH.  TO THE MAXIMUM
 * EXTENT PERMITTED BY LAW, IN NO EVENT WILL RENESAS BE LIABLE TO YOU IN CONNECTION WITH THE SOFTWARE OR DOCUMENTATION
 * (OR ANY PERSON OR ENTITY CLAIMING RIGHTS DERIVED FROM YOU) FOR ANY LOSS, DAMAGES, OR CLAIMS WHATSOEVER, INCLUDING,
 * WITHOUT LIMITATION, ANY DIRECT, CONSEQUENTIAL, SPECIAL, INDIRECT, PUNITIVE, OR INCIDENTAL DAMAGES; ANY LOST PROFITS,
 * OTHER ECONOMIC DAMAGE, PROPERTY DAMAGE, OR PERSONAL INJURY; AND EVEN IF RENESAS HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH LOSS, DAMAGES, CLAIMS OR COSTS.
 **********************************************************************************************************************/

#include "hal_data.h"

// START USER include

//some definitions for RTT
#include "common_utils.h"
//some definitions for TFT
#include "PMD_TFT/pmd_tft.h"
#include "PMD_TFT/pmd_text.h"
// END USER include

//picture input by array
#include "pictures.h"
//

static uint16_t buffer_rgb565[RENESAS_110_17_WIDTH*RENESAS_110_17_HEIGHT +
                              (RENESAS_110_17_WIDTH*RENESAS_110_17_HEIGHT +1)/2
                             ];

extern bsp_leds_t g_bsp_leds;
uint16_t act_state=0 ;
uint16_t tft_ori_cnt=0;
// End user

FSP_CPP_HEADER
void R_BSP_WarmStart(bsp_warm_start_event_t event);
FSP_CPP_FOOTER


/*******************************************************************************************************************//**
 * @brief  Blinky example application
 *
 * Blinks all leds at a rate of 1 second using the software delay function provided by the BSP.
 *
 **********************************************************************************************************************/
void hal_entry(void)
{

#if BSP_TZ_SECURE_BUILD
    /* Enter non-secure code */
    R_BSP_NonSecureEnter();
#endif

    /* Define the units to be used with the software delay function */
    const bsp_delay_units_t bsp_delay_units = BSP_DELAY_UNITS_MILLISECONDS;

    /* Set the blink frequency (must be <= bsp_delay_units */
    const uint32_t freq_in_hz = 2;

    /* Calculate the delay in terms of bsp_delay_units */
    const uint32_t delay = bsp_delay_units / freq_in_hz;

    /* LED type structure */
    bsp_leds_t leds = g_bsp_leds;

    /* If this board has no LEDs then trap here */
    if (0 == leds.led_count)
    {
        while (1)
        {
            ;                          // There are no LEDs on this board
        }
    }

    /* Holds level to set for pins */
    bsp_io_level_t pin_level = BSP_IO_LEVEL_LOW;

    // START USER include

    /* set the TFT orientation */
    tft_set_ori_set (TFT_R90);

    /* init the TFT */
    tft_configure ();

    /* draw some shapes */
    tft_set_draw_color(0xff0000);
    tft_draw_rect((int16_t)20,(int16_t)20,
                  (int16_t)(tft_get_act_width()/2-1),(int16_t)(tft_get_act_height()/2-1));
    tft_set_draw_color(0x00ff00);
    tft_draw_rect((int16_t)(tft_get_act_width()/2), (int16_t)(tft_get_act_height()/2),
                  (int16_t)(tft_get_act_width()-1-20),(int16_t)(tft_get_act_height()-1-20));

    // START USER include
    pmd_text_init();


    while (1)
    {
        /* Enable access to the PFS registers. If using r_ioport module then register protection is automatically
         * handled. This code uses BSP IO functions to show how it is used.
         */
        R_BSP_PinAccessEnable();

        /* Update all board LEDs */
        for (uint32_t i = 0; i < leds.led_count; i++)
        {
            /* Get pin to toggle */
            uint32_t pin = leds.p_leds[i];

            /* Write to this pin */
            R_BSP_PinWrite((bsp_io_port_pin_t) pin, pin_level);
        }

        /* Protect PFS registers */
        R_BSP_PinAccessDisable();

        /* Toggle level for next write */
        if (BSP_IO_LEVEL_LOW == pin_level)
        {
            pin_level = BSP_IO_LEVEL_HIGH;
        }
        else
        {
            pin_level = BSP_IO_LEVEL_LOW;
        }

        /* some output on the Display */
        //act_state=0 ;
        switch (act_state++)
        {
            case 0 :
                if (tft_ori_cnt > 3)
                    tft_ori_cnt = 0;
                if (tft_ori_cnt == 0)
                    tft_set_ori (TFT_R0);
                if (tft_ori_cnt == 1)
                    tft_set_ori (TFT_R90);
                if (tft_ori_cnt == 2)
                    tft_set_ori (TFT_R180);
                if (tft_ori_cnt == 3)
                    tft_set_ori (TFT_R270);

                //clear the screen
                tft_cls(CLS_COLOR) ;
                /* draw some shapes */
                tft_set_draw_color(0x0000ff);
                tft_draw_rect(5,5, 15,15);  //This top left corner

                tft_set_draw_color(0xff0000);
                tft_draw_rect(20,20,
                              (int16_t)(tft_get_act_width()/2-1),
                              (int16_t)(tft_get_act_height()/2-1));
                tft_set_draw_color(0x00ff00);
                tft_draw_rect((int16_t)(tft_get_act_width()/2),
                              (int16_t)(tft_get_act_height()/2),
                              (int16_t)(tft_get_act_width()-1-20),
                              (int16_t)(tft_get_act_height()-1-20));

                pmd_text_set_b_color(0x0000ff00); // A - is 0 keep background
                pmd_text_set_f_color(0xff0000ff); // A - is 255 use foreground color blue
                pmd_text_set_font(1) ;
                pmd_text_set_rotation(TFT_TXT_R0);
                if (tft_ori_cnt == 0)
                    pmd_draw_string("TFT_R0",20,3);
                if (tft_ori_cnt == 1)
                    pmd_draw_string("TFT_R90",20,3);
                if (tft_ori_cnt == 2)
                    pmd_draw_string("TFT_R180",20,3);
                if (tft_ori_cnt == 3)
                    pmd_draw_string("TFT_R270",20,3);
                tft_ori_cnt++;
                break ;

            case 2:
                // output a RGB565 picture at x(centered horizontal) y(bottom in vertical)
                // background of picture has color 0x00000 we want to keep the LCD background so alpha -is 0x00
                // --> color = 0x00000000u
                // foreground of picture we want to blend E7
                // foreground RGB is set to 0x00000 (no use)
                // --> color = 0xE7000000u

                tft_blit_copy_blend ((uint16_t*) buffer_rgb565, (uint16_t*) picture_renesas_110_17_rgb565,
                                     (int16_t) ((tft_get_act_width () - RENESAS_110_17_WIDTH) / 2),
                                     (int16_t) ((tft_get_act_height () - RENESAS_110_17_HEIGHT - 1)),
                                     RENESAS_110_17_WIDTH,
                                     RENESAS_110_17_HEIGHT,
                                     0x00000000u,  // BG color is RGB 0x000000 and alpha will be 0x00 so keep background on LCD
                                     0xE7000000u); // FG color is unused only alpha channel will be used for blend

            break;

            case 4:
                pmd_text_set_rotation(TFT_TXT_R0);
                pmd_text_set_b_color(0x0000ff00); // A - is 0 keep background
                pmd_text_set_f_color(0xff000000); //black
                pmd_text_set_font(1) ;
                pmd_draw_string("Hey\f   Renesas\r\n",
                                (int16_t)(tft_get_act_width()/2),
                                (int16_t)(tft_get_act_height()/2));
                pmd_text_set_font(0) ;
                pmd_draw_string(" TFT_TXT_R0 \r\n",
                                pmd_text_get_cursor_x(),       // please take care for correct offsets to screen and text start point
                                pmd_text_get_cursor_y() + 10); // please take care for correct offsets to screen and text start point
                break;

            case 6:
                pmd_text_set_rotation(TFT_TXT_R90);
                pmd_text_set_b_color(0x38eff0ef); // A lets'use some alpha blending
                pmd_text_set_f_color(0xff0000bf); //blue ARGB
                pmd_text_set_font(1) ;
                pmd_draw_string("Hey\f   Renesas\r\n",
                                (int16_t)(tft_get_act_width()/2),
                                (int16_t)(tft_get_act_height()/2));
                pmd_text_set_font(0) ;
                pmd_draw_string(" TFT_TXT_R90 \r\n",
                                pmd_text_get_cursor_x() + 10 , // please take care for correct offsets to screen and text start point
                                pmd_text_get_cursor_y());      // please take care for correct offsets to screen and text start point
                break;

            case 8:
                pmd_text_set_rotation(TFT_TXT_R180);
                pmd_text_set_b_color(0x0000ff00); // A - is 0 keep background
                pmd_text_set_f_color(0xffffffff); //white ARGB
                pmd_text_set_font(1) ;
                pmd_draw_string("Hey\f   Renesas\r\n",
                                (int16_t)(tft_get_act_width()/2),
                                (int16_t)(tft_get_act_height()/2));
                pmd_text_set_font(0) ;
                pmd_draw_string(" TFT_TXT_R180 \r\n",
                                pmd_text_get_cursor_x() ,       // please take care for correct offsets to screen and text start point
                                pmd_text_get_cursor_y() -10 );  // please take care for correct offsets to screen and text start point
                break;

            case 10:
                pmd_text_set_rotation(TFT_TXT_R270);
                pmd_text_set_b_color(0x0000ff00); // A - is 0 keep background
                pmd_text_set_f_color(0xff0000ff); //blue ARGB
                pmd_text_set_font(1) ;
                pmd_draw_string("Hey\f   Renesas\r\n",
                                (int16_t)(tft_get_act_width()/2),
                                (int16_t)(tft_get_act_height()/2));
                pmd_text_set_font(0) ;
                pmd_draw_string(" TFT_TXT_R270 \r\n",
                                pmd_text_get_cursor_x() -10, // please take care for correct offsets to screen and text start point
                                pmd_text_get_cursor_y() );   // please take care for correct offsets to screen and text start point
                break;

            case 12:
                tft_set_draw_color (0x8f8f8f);
                tft_draw_rect (20, 20, (int16_t) (tft_get_act_width () - 1 - 20),
                               (int16_t) (tft_get_act_height () - 1 - 20));
            break;

            case 13:
            {
                int16_t xt = 30;
                int16_t x = (int16_t) ((tft_get_act_width () - 0 ) / 2 + 25 );
                int16_t y2 = 40;

                pmd_text_set_rotation(TFT_TXT_R0);
                pmd_text_set_b_color(0x0000ff00); // A - is 0 keep background
                pmd_text_set_f_color(0xffb0ffb0); //  ARGB
                pmd_text_set_font(1) ;
                pmd_draw_string("circle",
                                xt,
                                (int16_t)(y2-pmd_font_get_height()/2));

                tft_set_draw_color(0x2020ff);
                tft_draw_circle(x + 6, y2, 11);
                tft_draw_circle(x + 6, y2, 9);
            }
                break ;

            case 14:
            {
                int16_t xt = 30;
                int16_t x = (int16_t) ((tft_get_act_width () - 0 ) / 2 + 25 );
                int16_t y3 = 70;

                pmd_text_set_rotation(TFT_TXT_R0);
                pmd_text_set_b_color(0x0000ff00); // A - is 0 keep background
                pmd_text_set_f_color(0xffb0ffb0); //  ARGB
                pmd_text_set_font(1) ;
                // circle does not support line width
                pmd_draw_string("filled circle",
                                xt,
                                (int16_t)(y3-pmd_font_get_height()/2));

                tft_set_draw_color(0x2020ff);
                tft_draw_filled_circle(x + 6, y3, 11);
            }
                break ;

            case 15:
            {
                int16_t xt = 30;
                int16_t x = (int16_t) ((tft_get_act_width () - 0 ) / 2 + 25);
                int16_t y1 = 100 -26/2;

                pmd_text_set_rotation(TFT_TXT_R0);
                pmd_text_set_b_color(0x0000ff00); // A - is 0 keep background
                pmd_text_set_f_color(0xffb0ffb0); //  ARGB
                pmd_text_set_font(1) ;

                pmd_draw_string("frame",
                                xt,
                                (int16_t)(y1-pmd_font_get_height()/2+13));

                tft_set_draw_color(0x2020ff);
                pmd_set_linesize (1);
                pmd_draw_frame(x, y1, 60, 26);

                }

                break ;


            case 16:
            {
                int16_t xt = 30;
                int16_t x = (int16_t) ((tft_get_act_width () - 0 ) / 2 + 25);
                int16_t y2 = 130 -26/2;

                pmd_text_set_rotation(TFT_TXT_R0);
                pmd_text_set_b_color(0x0000ff00); // A - is 0 keep background
                pmd_text_set_f_color(0xffb0ffb0); //  ARGB
                pmd_text_set_font(1) ;

                pmd_draw_string("text frame",
                                xt,
                                (int16_t)(y2-pmd_font_get_height()/2+13));

                pmd_set_linesize (3);
                pmd_text_set_font(0) ;

                pmd_text_set_b_color(0xff0000Af); // overwrite background
                pmd_text_set_f_color(0xffffffff); //  ARGB
                pmd_draw_text_frame("IN_BOX\f42", x, y2, 60, 26);

                }

                break ;


            case 17:
            {
                int16_t xt = 30;
                int16_t x = (int16_t) ((tft_get_act_width () - 0) / 2 + 25);
                int16_t y3 = 160 + 10;

                pmd_text_set_rotation (TFT_TXT_R0);
                pmd_text_set_b_color (0x0000ff00); // A - is 0 keep background
                pmd_text_set_f_color (0xffb0ffb0); //  ARGB
                pmd_text_set_font (1);
                pmd_draw_string ("line", xt, (int16_t)(y3 - pmd_font_get_height () / 2 + 0) );

                tft_draw_line (0 + x, 20 + y3, 10 + x, 0 + y3);
                tft_draw_line (0 + x, 20 + y3, -10 + x, 0 + y3);

                tft_draw_line (-10 + x, 0 + y3, 0 + x, -20 + y3);
                tft_draw_line (+10 + x, 0 + y3, 0 + x, -20 + y3);

                tft_draw_v_line (x + 20, y3 - 10, y3 + 10, 3);
                tft_draw_h_line (x + 30, y3, x + 30 + 20, 3);

                }

                break ;


            case 18:
            {
                int16_t xt = 30;
                int16_t x = (int16_t) ((tft_get_act_width () - 0) / 2 + 25);
                int16_t x2 = x ;
                int16_t y4 = 190 + 10 ;

                if ( tft_get_ori() == TFT_R0 || tft_get_ori() == TFT_R180)
                    x2 -= 40 ;

                pmd_text_set_rotation (TFT_TXT_R0);
                pmd_text_set_b_color (0x0000ff00); // A - is 0 keep background
                pmd_text_set_f_color (0xffb0ffb0); //  ARGB
                pmd_text_set_font (1);
                pmd_draw_string ("picture", xt, (int16_t)(y4 + (RENESAS_110_17_HEIGHT - pmd_font_get_height ()) / 2 + 0) );

                // output a RGB565 picture at x(centered horizontal) y(bottom in vertical)
                // background of picture has color 0x00000 we want to keep the LCD background so alpha -is 0x00
                // --> color = 0x00000000u
                // foreground of picture we want to blend E7
                // foreground RGB is set to 0x00000 (no use)
                // --> color = 0xE7000000u

                tft_blit_copy_blend ((uint16_t*) buffer_rgb565, (uint16_t*) picture_renesas_110_17_rgb565,
                                     x2,
                                     y4,
                                     RENESAS_110_17_WIDTH,
                                     RENESAS_110_17_HEIGHT,
                                     0x00000000u,  // BG color is RGB 0x000000 and alpha will be 0x00 so keep background on LCD
                                     0xff000000u); // FG color is unused only alpha channel will be used for blend

                }


                break ;


            case 24:
                act_state = 0 ;
                break ;

            default:
               break ;

        }

        /* Delay */
        R_BSP_SoftwareDelay(delay, bsp_delay_units);
    }

}

/*******************************************************************************************************************//**
 * This function is called at various points during the startup process.  This implementation uses the event that is
 * called right before main() to set up the pins.
 *
 * @param[in]  event    Where at in the start up process the code is currently at
 **********************************************************************************************************************/
void R_BSP_WarmStart(bsp_warm_start_event_t event)
{
    if (BSP_WARM_START_RESET == event)
    {
#if BSP_FEATURE_FLASH_LP_VERSION != 0

        /* Enable reading from data flash. */
        R_FACI_LP->DFLCTL = 1U;

        /* Would normally have to wait tDSTOP(6us) for data flash recovery. Placing the enable here, before clock and
         * C runtime initialization, should negate the need for a delay since the initialization will typically take more than 6us. */
#endif
    }

    if (BSP_WARM_START_POST_C == event)
    {
        /* C runtime environment and system clocks are setup. */

        /* Configure pins. */
        IOPORT_CFG_OPEN (&IOPORT_CFG_CTRL, &IOPORT_CFG_NAME);
    }
}

#if BSP_TZ_SECURE_BUILD

FSP_CPP_HEADER
BSP_CMSE_NONSECURE_ENTRY void template_nonsecure_callable ();

/* Trustzone Secure Projects require at least one nonsecure callable function in order to build (Remove this if it is not required to build). */
BSP_CMSE_NONSECURE_ENTRY void template_nonsecure_callable ()
{

}
FSP_CPP_FOOTER

#endif

