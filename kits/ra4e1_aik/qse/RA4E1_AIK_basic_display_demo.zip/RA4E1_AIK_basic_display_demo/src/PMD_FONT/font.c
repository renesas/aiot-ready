/***********************************************************************************************************************
 * File Name    : font.c
 * Description  : data structures and font information/definitions for main program
 ***********************************************************************************************************************/

#include "font.h"
#include "font_def_12x24.h"
#include "font_def_8x16.h"
#include "font_def_6x8.h"
//#include "font_def_8x6_r90.h"

singlefont_s const font_array[FONTDATA_NUM] = {
//                                               { .font_width = FONTDATA_8X6_WIDTH,
//                                                 .font_height = FONTDATA_8X6_HEIGHT,
//                                                 .font_char_pitch = FONTDATA_8X6_CHAR_PITCH,
//                                                 .font_char_valid = FONTDATA_8X6_CHAR_FIRST_CODE,
//                                                 .font_char_bytes = FONTDATA_8X6_ROW_BYTES,
//                                                 .font_array_size = sizeof(fontdata_8x6_r90) / (FONTDATA_8X6_ROW_BYTES * FONTDATA_8X6_HEIGHT),
//                                                 .font_has_rotate= 90,
//                                                 .font_addr = (uint8_t*) fontdata_8x6_r90 },
                                               { .font_width = FONTDATA_6X8_WIDTH,
                                                 .font_height = FONTDATA_6X8_HEIGHT,
                                                 .font_char_pitch = FONTDATA_6X8_CHAR_PITCH,
                                                 .font_char_valid = FONTDATA_6X8_CHAR_FIRST_CODE,
                                                 .font_char_bytes = FONTDATA_6X8_ROW_BYTES,
                                                 .font_array_size = sizeof(fontdata_6x8) / (FONTDATA_6X8_ROW_BYTES * FONTDATA_6X8_HEIGHT),
                                                 .font_has_rotate= 0,
                                                 .font_addr = (uint8_t*) fontdata_6x8 },

                                               { .font_width = FONTDATA_8X16_WIDTH,
                                                 .font_height = FONTDATA_8X16_HEIGHT,
                                                 .font_char_pitch = FONTDATA_8X16_CHAR_PITCH,
                                                 .font_char_valid = FONTDATA_8X16_CHAR_FIRST_CODE,
                                                 .font_char_bytes = FONTDATA_8X16_ROW_BYTES,
                                                 .font_array_size = sizeof(fontdata_8x16) / (FONTDATA_8X16_ROW_BYTES * FONTDATA_8X16_HEIGHT),
                                                 .font_has_rotate= 0,
                                                 .font_addr = (uint8_t*) fontdata_8x16 },

                                               { .font_width = FONTDATA_12X24_WIDTH,
                                                 .font_height = FONTDATA_12X24_HEIGHT,
                                                 .font_char_pitch = FONTDATA_12X24_CHAR_PITCH,
                                                 .font_char_valid = FONTDATA_12X24_CHAR_FIRST_CODE,
                                                 .font_char_bytes = FONTDATA_12X24_ROW_BYTES,
                                                 .font_array_size = sizeof(fontdata_12x24) / (FONTDATA_12X24_ROW_BYTES * FONTDATA_12X24_HEIGHT),
                                                 .font_has_rotate= 0,
                                                 .font_addr = (uint8_t*) fontdata_12x24 },
};

