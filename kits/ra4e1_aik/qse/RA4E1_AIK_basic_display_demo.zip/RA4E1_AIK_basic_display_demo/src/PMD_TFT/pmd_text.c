
/***********************************************************************************************************************
 * File Name    : pmd_text.c
 * Description  : Contains function definition.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2023 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/


#include "common_utils.h"
#include "hal_data.h"

#include <stdlib.h>
#include <string.h>
#include <stddef.h>

#include "PMD_TFT/pmd_text.h"
#include "PMD_FONT/font.h"

/* DRW local Variables */

static volatile pmd_textopt_s  textopt ;
static uint16_t   line_size = 1 ;
static uint16_t   line_sizeh= 1 ;

/*
 * take care alpha blending needs up to 3 bytes per pixel in character
 * This is cause by readback operation of display data
 */
uint16_t char_draw_buffer_A[FONT_MAX_WIDTH_MUL_HEIGHT * sizeof(uint16_t) + (FONT_MAX_WIDTH_MUL_HEIGHT * sizeof(uint16_t))/2 ] ;
uint16_t char_draw_buffer_B[FONT_MAX_WIDTH_MUL_HEIGHT * sizeof(uint16_t) + (FONT_MAX_WIDTH_MUL_HEIGHT * sizeof(uint16_t))/2 ] ;
uint16_t *char_draw_buffer = char_draw_buffer_A ;

/**
 * @brief  set the parameter for text drawing to standard values
 * @param  none
 * @retval none
 */
void pmd_text_init(void)
{

    textopt = (pmd_textopt_s){
        .actual.f_color = 0xffff,            /* foreground color for text */
        .actual.b_color = 0x0000,            /* background color for text */
        .actual.act_font = 1,                /* actual font to use */
        .x = 0,                              /* text output next-x position */
        .y = 0,                              /* text output next-y position */
        .actual.rotation =  TFT_TXT_R0,      /* set output rotation */
        .actual.f_blend = 255 ,              /* 0-foreground not modified, 255-foreground color */
        .actual.b_blend = 255 ,              /* 0-background not modified, 255-background color */
        .actual.f_color_draw = true,         /* overwrite foreground */
        .actual.b_color_draw = true,         /* overwrite background */
    } ;
    textopt.request = textopt.actual ;
}


/**
 * @brief set foreground color for text drawing
 * @param color in ARGB format (A is alpha blending 0-nodraw 255- replacement
 * @note alpha blending uses only the upper 5bit of the alpha channel for operation
 */
void pmd_text_set_f_color (uint32_t color)
{
    textopt.request.f_color = (uint16_t)(((color >> 8) & 0b1111100000000000u) | ((color >> 5) & 0b0000011111100000u) | ((color >> 3) & 0b0000000000011111u));
    textopt.request.f_blend = (uint8_t)(color >> 24) ;
    textopt.request.f_color_draw = (bool)( textopt.request.f_blend == 255u) ;
    //APP_PRINT("pmd_text_set_f_color f_color_draw %d f_blend %d f_color 0x%04x\r\n",textopt.f_color_draw,textopt.f_blend,textopt.f_color);

}

/**
 * @brief set background color for text drawing
 * @param color in ARGB format (A is alpha blending 0-nodraw 255- replacement
 * @note alpha blending uses only the upper 5bit of the alpha channel for operation
 */
void pmd_text_set_b_color (uint32_t color)
{
    textopt.request.b_color = (uint16_t)(((color >> 8) & 0b1111100000000000u) | ((color >> 5) & 0b0000011111100000u) | ((color >> 3) & 0b0000000000011111u));
    textopt.request.b_blend = (uint8_t)(color >> 24);
    textopt.request.b_color_draw = (bool)( textopt.request.b_blend == 255u) ;
    //APP_PRINT("pmd_text_set_b_color b_color_draw %d b_blend %d b_color 0x%04x\r\n",textopt.b_color_draw,textopt.b_blend,textopt.b_color);
}

/**
 * @brief set the actual used font
 * @param font_index starting with 0
 * @return 0-success, 1-error font_index is out of range
 * @note uses PMD_FONT check the source code for details of available fonts
 */
uint16_t pmd_text_set_font (uint16_t font_index)
{
    if ( font_index < FONTDATA_NUM)
    {
        textopt.request.act_font = font_index ;
        return 0 ;
    }
    return 1 ;
}

/**
 * @brief set the text rotation
 * @param rotation TFT_TXT_[R0,R90,R180,R270,R0_FX,R90_FX,R180_FX,R270_FX]
 * @note currently only TFT_TXT_R0 is supported
 */
void pmd_text_set_rotation (pmd_txt_orientation_enum rotation)
{
    textopt.request.rotation = rotation ;
}

/**
 * @brief get actual text x-position after text draw operation
 * @return x-postion
 */
int16_t pmd_text_get_cursor_x(void)
{
    return textopt.x;
}

/**
 * @brief get actual text y-position after text draw operation
 * @return y-postion
 */
int16_t pmd_text_get_cursor_y(void)
{
    return textopt.y;
}

/**
 * @brief get the width of the actual requested font considering the set rotation for text
 * @return number of pixel
 */
uint16_t pmd_font_get_width(void)
{
    switch (textopt.request.rotation)
    {
        case TFT_TXT_R0:
        case TFT_TXT_R180:
            return (font_array[textopt.request.act_font].font_width);
        break;

        case TFT_TXT_R90:
        case TFT_TXT_R270:
            return (font_array[textopt.request.act_font].font_height);
        break;

        default:
            return (0);
    }
}

/**
 * @brief get the height of the actual requested font considering the set rotation for text
 * @return number of pixel
 */
uint16_t pmd_font_get_height(void)
{
    switch (textopt.request.rotation)
    {
        case TFT_TXT_R0:
        case TFT_TXT_R180:
            return (font_array[textopt.request.act_font].font_height);
        break;

        case TFT_TXT_R90:
        case TFT_TXT_R270:
            return (font_array[textopt.request.act_font].font_width);
        break;

        default:
            return (0);
    }
}

/**
 * @brief print a single character on the TFT display
 * @param target_char - character to draw
 * @param x - drawing position (0,0) is top left of character
 * @param y - drawing position (0,0) is top left of character
 * @note for internal use only requires wait_for_tft() and textopt.actual = textopt.request
 * @note in caller function
 */
void pmd_draw_text_bitmap(char target_char, int16_t x, int16_t y)
{

    // copy the request to the actual used settings
    // textopt.actual = textopt.request;
    uint16_t font_width = font_array[textopt.actual.act_font].font_width;
    uint16_t font_height = font_array[textopt.actual.act_font].font_height;
    uint16_t font_pfull_bytes = font_width / 8;
    uint16_t font_premind_bytes = font_width % 8;

    int16_t delta_cx;
    int16_t delta_cy;
    int16_t delta_lx;
    int16_t delta_ly;
    int16_t x_offs;
    int16_t y_offs;
    int16_t font_width_c;
    int16_t font_height_c;
    bool flip_x = 0;
    bool flip_y = 0;

#ifdef DEBUG_TEXT_CAHR_ACCESS
    uint16_t maxi = 0 ;
    uint16_t mini = 0xffff ;
#endif

    switch (textopt.actual.rotation)
    {
        case TFT_TXT_R0:
            delta_cx = (int16_t) font_width;
            delta_cy = 0;
            delta_lx = 0;
            delta_ly = (int16_t) font_height;
            flip_x = 1;
            flip_y = 0;
            x_offs = 0;
            y_offs = 0;
            font_width_c = (int16_t) font_width;
            font_height_c = (int16_t) 1;
        break;
        case TFT_TXT_R90:
            delta_cx = 0;
            delta_cy = -(int16_t) font_width;
            delta_lx = (int16_t) font_height;
            delta_ly = 0;
            flip_x = 0;
            flip_y = 0;
            x_offs = 0;
            y_offs = -(int16_t) font_width;
            font_width_c = (int16_t) 1;
            font_height_c = (int16_t) font_height;
        break;
        case TFT_TXT_R180:
            delta_cx = -(int16_t) font_width;
            delta_cy = 0;
            delta_lx = 0;
            delta_ly = -(int16_t) font_height;
            flip_x = 0;
            flip_y = 1;
            x_offs = -(int16_t) font_width;
            y_offs = -(int16_t) font_height;
            font_width_c = (int16_t) font_width;
            font_height_c = (int16_t) 1;
        break;

        case TFT_TXT_R270:
            delta_cx = 0;
            delta_cy = (int16_t) font_width;
            delta_lx = -(int16_t) font_height;
            delta_ly = 0;
            flip_x = 1;
            flip_y = 1;
            x_offs = -(int16_t) font_height;
            y_offs = 0;
            font_width_c = (int16_t) 1;
            font_height_c = (int16_t) font_height;
        break;

        default:
            delta_cx = (int16_t) font_width;
            delta_cy = 0;
            delta_lx = 0;
            delta_ly = (int16_t) font_height;
            flip_x = 1;
            x_offs = 0;
            y_offs = 0;
            font_width_c = (int16_t) font_width;
            font_height_c = (int16_t) 1;
    }

    if ((target_char == '\n') || (target_char == '\f'))
    {
        textopt.y = y + delta_ly;
        textopt.x = x + delta_lx;
        return;
    }

    if (target_char == '\b')
    {
        if ((y - delta_cy) > 0)
            textopt.y = y - delta_cy;
        else
            textopt.y = 0;

        if ((x - delta_cx) > 0)
            textopt.x = x - delta_cx;
        else
            textopt.x = 0;
        return;
    }

    // use a double buffer for text character output
    if ( char_draw_buffer != char_draw_buffer_B)
        char_draw_buffer = char_draw_buffer_B ;
    else
        char_draw_buffer = char_draw_buffer_A ;
    //back to normal flow

    textopt.x += delta_cx;
    textopt.y += delta_cy;

    if ((target_char < font_array[textopt.actual.act_font].font_char_valid)
            || (target_char
                    > (char) (font_array[textopt.actual.act_font].font_char_valid
                            + font_array[textopt.actual.act_font].font_array_size - 1)))
        return;

    uint8_t *font_src = font_array[textopt.actual.act_font].font_addr
            + (target_char - font_array[textopt.actual.act_font].font_char_valid)
                    * font_array[textopt.actual.act_font].font_char_pitch;

    if ((textopt.actual.f_color_draw == false) || (textopt.actual.b_color_draw == false))
    {
        // read back the contents of the tft display
        tft_wait_for_spi ();
        // the following commands comes back after transfer is finsihed
        if (delta_cx != 0)
            tft_memcpy_read ((uint8_t*) char_draw_buffer, x + x_offs, y + y_offs, font_width, font_height, 0, true);
        else
            tft_memcpy_read ((uint8_t*) char_draw_buffer, x + x_offs, y + y_offs, font_height, font_width, 0, true);
    }
    else
    {
        //tft_wait_for_spi();
        ;
    }
    for (uint16_t char_cnt_y = 0; char_cnt_y < font_height; char_cnt_y++)
    {
        uint16_t char_y;
        uint16_t lineAddr;
        int16_t cnt_dir;
        if (flip_y)
        {
            char_y = (uint16_t)(((font_height - 1) - char_cnt_y) * font_width_c);
        }
        else
        {
            char_y = (uint16_t)(char_cnt_y * font_width_c);
        }

        if (flip_x)
        {
            if (font_height_c > 1)
                lineAddr = (uint16_t)((font_width - 1) * font_height_c);
            else
                lineAddr = font_width - 1;
            cnt_dir = -1 * font_height_c;
        }
        else
        {
            lineAddr = 0;
            cnt_dir = 1 * font_height_c;
        }
        for (uint8_t act_byte = 0; act_byte < font_pfull_bytes; act_byte++)
        {
            uint8_t act_line = *font_src;
            font_src++;
            for (uint8_t char_x = 0; char_x < 8; char_x++)
            {
                if (act_line & 0x01)
                {
                    if ((textopt.actual.f_color_draw == true))
                        char_draw_buffer[char_y + lineAddr] = textopt.actual.f_color;
                    else
                    {
                        if ((textopt.actual.f_blend != 0))
                            char_draw_buffer[char_y + lineAddr] = tft_blend_pixel (char_draw_buffer[char_y + lineAddr],
                                                                                   textopt.actual.f_color, textopt.actual.f_blend);
                    }
                }
                else
                {
                    if (textopt.actual.b_color_draw == true)
                        char_draw_buffer[char_y + lineAddr] = textopt.actual.b_color;
                    else
                    {
                        if ((textopt.actual.b_blend != 0))
                            char_draw_buffer[char_y + lineAddr] = tft_blend_pixel (char_draw_buffer[char_y + lineAddr],
                                                                                   textopt.actual.b_color, textopt.actual.b_blend);
                    }
                }
#ifdef DEBUG_TEXT_CAHR_ACCESS
                if ( (char_y + lineAddr) > maxi)
                    maxi = char_y + lineAddr ;
                if ( (char_y + lineAddr) < mini)
                    mini = char_y + lineAddr ;
#endif

                act_line >>= 1;
                lineAddr = (uint16_t) (lineAddr + cnt_dir);
            }

        }
        if (font_premind_bytes)
        {
            uint8_t act_line = *font_src;
            font_src++;
            for (uint8_t char_x = 0; char_x < font_premind_bytes; char_x++)
            {
                if (act_line & 0x01)
                {
                    if ((textopt.actual.f_color_draw == true))
                        char_draw_buffer[char_y + lineAddr] = textopt.actual.f_color;
                    else
                    {
                        if ((textopt.actual.f_blend != 0))
                            char_draw_buffer[char_y + lineAddr] = tft_blend_pixel (char_draw_buffer[char_y + lineAddr],
                                                                                   textopt.actual.f_color, textopt.actual.f_blend);
                    }
                }
                else
                {
                    if (textopt.actual.b_color_draw == true)
                        char_draw_buffer[char_y + lineAddr] = textopt.actual.b_color;
                    else
                    {
                        if ((textopt.actual.b_blend != 0))
                            char_draw_buffer[char_y + lineAddr] = tft_blend_pixel (char_draw_buffer[char_y + lineAddr],
                                                                                   textopt.actual.b_color, textopt.actual.b_blend);
                    }
                }
#ifdef DEBUG_TEXT_CAHR_ACCESS
                if ( (char_y + lineAddr) > maxi)
                    maxi = char_y + lineAddr ;
                if ( (char_y + lineAddr) < mini)
                    mini = char_y + lineAddr ;
#endif
                act_line >>= 1;
                lineAddr = (uint16_t) (lineAddr + cnt_dir);
            }
        }
    }
#ifdef DEBUG_TEXT_CAHR_ACCESS
    APP_PRINT("%d %d\r\n",mini,maxi);
#endif
    tft_wait_for_spi();
    if (delta_cx != 0)
        tft_memcpy_write ((uint8_t*) char_draw_buffer, x + x_offs, y + y_offs, font_width, font_height, 0, true);
    else
        tft_memcpy_write ((uint8_t*) char_draw_buffer, x + x_offs, y + y_offs, font_height, font_width, 0, true);

}


/**
 * @brief direct text string output tft display without a framebuffer
 * @param outstr      pointer to text output string
 * @param x position (top left corner)
 * @param y position (top left corner)
 * @note supported special character \r \n \f(please use instead of \r\n within a textline) \b one character back
 */
void pmd_draw_string(char const *outstr, int16_t const x, int16_t const y)
{
    tft_wait_for_spi();
    textopt.x = x;
    textopt.y = y;
    // copy the request to the actual used settings
    textopt.actual = textopt.request;

    uint16_t char_index = 0;

    while (outstr[char_index] != 0)
    {
        if ( (outstr[char_index] == '\r') || (outstr[char_index] == '\f') )
        {
            if (font_array[textopt.actual.act_font].font_has_rotate == 90)
            {
                textopt.y = y;
            }
            else
            {
               if (( textopt.actual.rotation == TFT_TXT_R0) || ( textopt.actual.rotation == TFT_TXT_R180))
                    {
                       textopt.x = x;
                    }
               else
                    {
                       textopt.y = y;
                    }
            }
            if  (outstr[char_index] == '\f')
                pmd_draw_text_bitmap (outstr[char_index], textopt.x, textopt.y);
        }
        else
            pmd_draw_text_bitmap (outstr[char_index], textopt.x, textopt.y);

        char_index++;
    }

}

/**
 * @brief set line width
 * @param l_size width of line in pixel
 * @note used by pmd_draw_frame and draw_named_frame
 */
void pmd_set_linesize ( uint16_t l_size)
{
    if ( l_size == 0 )
        line_size = 1 ;
    else
        line_size = l_size ;

    line_sizeh = (uint16_t)(( line_size + 1u ) >> 1) ;
}


/**
 * @brief get line width
 * @return actual line width
 */
uint16_t pmd_get_linesize(void)
{
    return (line_size);
}


/**
 * @brief Draw outline box
 * @param x position (top left corner)
 * @param y position (top left corner)
 * @param w width of box
 * @param h height of box
 * @note  Use pmd_set_linesize for setting the line width
 */
void pmd_draw_frame(int16_t x, int16_t y, uint16_t w, uint16_t h)
{
    tft_draw_frame(x, y, w, h, line_size) ;
}

/**
 * @brief Draw frame box with text at top left corner
 * @param x position (top left corner)
 * @param y position (top left corner)
 * @param w width of box
 * @param h height of box
 * @param outstr string for to output inside of the box (top left corner)
 * @note  Use pmd_set_linesize for setting the line width
 */
void pmd_draw_text_frame(char const *outstr, int16_t x, int16_t y, uint16_t w, uint16_t h)
{
    int16_t x_in = (int16_t)(x + line_sizeh) ;
    int16_t y_in = (int16_t)(y + line_sizeh) ;

    tft_wait_for_spi();
    textopt.actual = textopt.request ;
    pmd_txt_orientation_enum rotate = textopt.actual.rotation ;
    textopt.actual.rotation = TFT_TXT_R0 ;
    pmd_draw_frame (x, y, w, h);
    pmd_draw_string (outstr, x_in, y_in);
    textopt.actual.rotation = rotate ;
}

