/* generated configuration header file - do not edit */
#ifndef BOARD_CFG_H_
#define BOARD_CFG_H_
#include "../../../ra/board/aik_ra4e1/board.h"
#endif /* BOARD_CFG_H_ */
