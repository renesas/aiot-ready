/* generated configuration header file - do not edit */
#ifndef BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_R7FA4E10D2CFM
#define BSP_MCU_FEATURE_SET ('0')
#define BSP_ROM_SIZE_BYTES (524288)
#define BSP_RAM_SIZE_BYTES (131072)
#define BSP_DATA_FLASH_SIZE_BYTES (8192)
#define BSP_PACKAGE_QFP
#define BSP_PACKAGE_PINS (64)
#endif /* BSP_MCU_DEVICE_PN_CFG_H_ */
