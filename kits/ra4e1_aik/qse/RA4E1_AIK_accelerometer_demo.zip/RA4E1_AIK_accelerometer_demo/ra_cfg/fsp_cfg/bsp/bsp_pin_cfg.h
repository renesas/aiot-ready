/* generated configuration header file - do not edit */
#ifndef BSP_PIN_CFG_H_
#define BSP_PIN_CFG_H_
#if __has_include("r_ioport.h")
#include "r_ioport.h"
#elif __has_include("r_ioport_b.h")
#include "r_ioport_b.h"
#endif

/* Common macro for FSP header files. There is also a corresponding FSP_FOOTER macro at the end of this file. */
FSP_HEADER

#define MIC_AN1 (BSP_IO_PORT_00_PIN_00)
#define MIC_AN2 (BSP_IO_PORT_00_PIN_01)
#define PMOD2_GPIO3_SW2IIC (BSP_IO_PORT_00_PIN_02)
#define PMOD2_GPIO1_CS2 (BSP_IO_PORT_00_PIN_03)
#define PMOD2_GPIO2_CS3 (BSP_IO_PORT_00_PIN_04)
#define PMOD1_GPIO2_CS3 (BSP_IO_PORT_00_PIN_13)
#define PMOD1_GPIO1_CS2 (BSP_IO_PORT_00_PIN_14)
#define PMOD1_GPIO3_SW1IIC (BSP_IO_PORT_00_PIN_15)
#define PMOD1_MISO_RXD_SW1SPI (BSP_IO_PORT_01_PIN_00)
#define PMOD1_RESET_SW1IIC_MOSI_TXD_SW1SPI (BSP_IO_PORT_01_PIN_01)
#define PMOD1_SCK_RTS_SW1SPI (BSP_IO_PORT_01_PIN_02)
#define PMOD1_SS_CTS_SW1SPI (BSP_IO_PORT_01_PIN_03)
#define PMOD1_INT (BSP_IO_PORT_01_PIN_04)
#define LED1_RED (BSP_IO_PORT_01_PIN_05)
#define PMOD1_GPIO4_SW1IIC_RESET_SW1SPI (BSP_IO_PORT_01_PIN_06)
#define J6_GPIO2 (BSP_IO_PORT_01_PIN_07)
#define JTAG_SWD_TMS (BSP_IO_PORT_01_PIN_08)
#define JTAG_SWD_TDO (BSP_IO_PORT_01_PIN_09)
#define JTAG_SWD_TDI (BSP_IO_PORT_01_PIN_10)
#define PMOD6_INT (BSP_IO_PORT_01_PIN_11)
#define J6_GPIO3 (BSP_IO_PORT_01_PIN_12)
#define LED1_GREEN (BSP_IO_PORT_01_PIN_13)
#define USR_BTN2_S2 (BSP_IO_PORT_02_PIN_00)
#define JTAG_MD (BSP_IO_PORT_02_PIN_01)
#define PMOD1_SDA_SW1IIC_PMOD2_SDA_SW2IIC_PMOD6 (BSP_IO_PORT_02_PIN_05)
#define PMOD1_SCL_SW1IIC_PMOD2_SCL_SW2IIC_PMOD6 (BSP_IO_PORT_02_PIN_06)
#define PMOD2_GPIO4_SW2IIC_RESET_SW2SPI (BSP_IO_PORT_02_PIN_07)
#define J6_PXD0 (BSP_IO_PORT_02_PIN_08)
#define CGC_EXTAL (BSP_IO_PORT_02_PIN_12)
#define CGC_XTAL (BSP_IO_PORT_02_PIN_13)
#define JTAG_SWD_TCK (BSP_IO_PORT_03_PIN_00)
#define LED1_BLUE (BSP_IO_PORT_03_PIN_01)
#define PMOD2_INT (BSP_IO_PORT_03_PIN_02)
#define J6_GPIO4 (BSP_IO_PORT_03_PIN_03)
#define USR_BTN1_S3 (BSP_IO_PORT_03_PIN_04)
#define J9_CAN1_DE (BSP_IO_PORT_04_PIN_00)
#define J9_CAN1_CTX (BSP_IO_PORT_04_PIN_01)
#define J9_CAN1_CRX (BSP_IO_PORT_04_PIN_02)
#define USBFS0_VBUS (BSP_IO_PORT_04_PIN_07)
#define PMOD2_MISO_RXD_SW2SPI (BSP_IO_PORT_04_PIN_08)
#define PMOD2_RESET_SW2IIC_MOSI_TXD_SW2SPI (BSP_IO_PORT_04_PIN_09)
#define PMOD2_SCK_RTS_SW2SPI (BSP_IO_PORT_04_PIN_10)
#define PMOD2_SS_CTS_SW2SPI (BSP_IO_PORT_04_PIN_11)
#define J6_GPIO1 (BSP_IO_PORT_05_PIN_00)
extern const ioport_cfg_t g_bsp_pin_cfg; /* AIK_RA4E1.pincfg */

void BSP_PinConfigSecurityInit();

/* Common macro for FSP header files. There is also a corresponding FSP_HEADER macro at the top of this file. */
FSP_FOOTER
#endif /* BSP_PIN_CFG_H_ */
