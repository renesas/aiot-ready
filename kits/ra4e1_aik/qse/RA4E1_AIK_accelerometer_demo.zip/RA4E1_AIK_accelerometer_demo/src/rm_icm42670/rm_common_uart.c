/***********************************************************************************************************************
 * File Name    : rm_common_uart.c
 * Description  : Contains UART functions definition.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * Copyright [2020-2022] Renesas Electronics Corporation and/or its affiliates.  All Rights Reserved.
 *
 * This software and documentation are supplied by Renesas Electronics America Inc. and may only be used with products
 * of Renesas Electronics Corp. and its affiliates ("Renesas").  No other uses are authorized.  Renesas products are
 * sold pursuant to Renesas terms and conditions of sale.  Purchasers are solely responsible for the selection and use
 * of Renesas products and Renesas assumes no liability.  No license, express or implied, to any intellectual property
 * right is granted by Renesas. This software is protected under all applicable laws, including copyright laws. Renesas
 * reserves the right to change or discontinue this software and/or this documentation. THE SOFTWARE AND DOCUMENTATION
 * IS DELIVERED TO YOU "AS IS," AND RENESAS MAKES NO REPRESENTATIONS OR WARRANTIES, AND TO THE FULLEST EXTENT
 * PERMISSIBLE UNDER APPLICABLE LAW, DISCLAIMS ALL WARRANTIES, WHETHER EXPLICITLY OR IMPLICITLY, INCLUDING WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT, WITH RESPECT TO THE SOFTWARE OR
 * DOCUMENTATION.  RENESAS SHALL HAVE NO LIABILITY ARISING OUT OF ANY SECURITY VULNERABILITY OR BREACH.  TO THE MAXIMUM
 * EXTENT PERMITTED BY LAW, IN NO EVENT WILL RENESAS BE LIABLE TO YOU IN CONNECTION WITH THE SOFTWARE OR DOCUMENTATION
 * (OR ANY PERSON OR ENTITY CLAIMING RIGHTS DERIVED FROM YOU) FOR ANY LOSS, DAMAGES, OR CLAIMS WHATSOEVER, INCLUDING,
 * WITHOUT LIMITATION, ANY DIRECT, CONSEQUENTIAL, SPECIAL, INDIRECT, PUNITIVE, OR INCIDENTAL DAMAGES; ANY LOST PROFITS,
 * OTHER ECONOMIC DAMAGE, PROPERTY DAMAGE, OR PERSONAL INJURY; AND EVEN IF RENESAS HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH LOSS, DAMAGES, CLAIMS OR COSTS.
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Includes
 **********************************************************************************************************************/
#include "rm_common_uart.h"

/***********************************************************************************************************************
 * Private function prototypes
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Private global variables
 **********************************************************************************************************************/

#define RM_ICM42670_UART_TIMEOUT     90
/* Temporary buffer to save data from receive buffer for further processing */

volatile bool rm_uart_transmitComplete = false;
volatile bool rm_uart_receiveComplete = false;

// Buffers
char rm_uart_outputBuffer[UART_BUFFER_SIZE] = { 0 };
char rm_uart_inputBuffer[INPUT_BUFFER_SIZE] = { 0 };

volatile int rm_uart_inputBufferIndex = 0;

/*******************************************************************************************************************//**
 * @addtogroup r_sci_uart
 * @{
 **********************************************************************************************************************/
#if 1
int _write(int fd,char *pBuffer,int size)  __attribute__ ((used)); ;
int _write(int fd,char *pBuffer,int size)
{
    fsp_err_t              err = FSP_SUCCESS;
    uint32_t  count = 0;

    rm_uart_transmitComplete = false;
    err = R_SCI_UART_Write(&g_uart3_pmod2_ctrl, (uint8_t *)pBuffer, (uint32_t)size);
    if(FSP_SUCCESS != err) __BKPT();
    while(rm_uart_transmitComplete == false)
    {
        if(count >= RM_ICM42670_UART_TIMEOUT)
        {
            //return UART_TIMEOUT;
            return 0;
        }
        R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_MILLISECONDS);
        count++;
    }

    return size;
    FSP_PARAMETER_NOT_USED(fd);
}
#else
#ifdef __GNUC__
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif
PUTCHAR_PROTOTYPE
{
    fsp_err_t              err = FSP_SUCCESS;
    err = R_SCI_UART_Write(&g_uart5_ctrl, (uint8_t *)&ch, 1);
    if(FSP_SUCCESS != err)
        return err;
    while(rm_uart_transmitComplete == false){
        ;
    }
    rm_uart_transmitComplete = false;
    return ch;
}
int _write(int fd,char *pBuffer,int size)
{

    for(int i=0;i<size;i++)
    {
        __io_putchar(*pBuffer++);
    }
    return size;
}
#endif
/*******************************************************************************************************************//**
 * @brief       Initialize  UART.
 * @param[in]   None
 * @retval      FSP_SUCCESS         Upon successful open and start of timer
 * @retval      Any Other Error code apart from FSP_SUCCESS  Unsuccessful open
 ***********************************************************************************************************************/
fsp_err_t rm_uart_initialize(void)
{
    fsp_err_t err = FSP_SUCCESS;
    rm_uart_transmitComplete = false;
    rm_uart_receiveComplete = false;
    rm_uart_inputBufferIndex = 0;

    /* Initialize UART channel 5 with baud rate 115200 */
    err = R_SCI_UART_Open (&g_uart3_pmod2_ctrl, &g_uart3_pmod2_cfg);
    FSP_ERROR_RETURN(FSP_SUCCESS == err, err);
    return FSP_SUCCESS;
}

/*******************************************************************************************************************//**
 *  @brief       Deinitialize SCI UART module
 *  @param[in]   None
 *  @retval      None
 **********************************************************************************************************************/
fsp_err_t rm_deinit_uart(void)
{
    fsp_err_t err = FSP_SUCCESS;

    /* Close module */
    err =  R_SCI_UART_Close (&g_uart3_pmod2_ctrl);
    FSP_ERROR_RETURN(FSP_SUCCESS == err, err);

    return FSP_SUCCESS;
}

/*****************************************************************************************************************
 *  @brief      UART user callback
 *  @param[in]  p_args
 *  @retval     None
 ****************************************************************************************************************/
void rm_uart_callback(uart_callback_args_t *p_args)
{

    // Get Event Type
    switch (p_args->event)
    {
        // Transmission Complete
        case UART_EVENT_TX_COMPLETE:
            rm_uart_transmitComplete = true;
        break;

            // Received Character
        case UART_EVENT_RX_CHAR:
            // Add data to input Buffer
            rm_uart_inputBuffer[rm_uart_inputBufferIndex] = (char) p_args->data;

            // Check for end of data (new line or carriage return)
            if ((rm_uart_inputBuffer[rm_uart_inputBufferIndex] == '\n') || (rm_uart_inputBuffer[rm_uart_inputBufferIndex] == '\r'))
            {
                // Replace new line/carriage return with null character
                rm_uart_inputBuffer[rm_uart_inputBufferIndex] = 0;

                // Set Flag
                rm_uart_receiveComplete = true;
            }

            // Increment Buffer Index
            rm_uart_inputBufferIndex++;

            // Check for overflow
            if (rm_uart_inputBufferIndex >= INPUT_BUFFER_SIZE)
            {
                // Overflow occurred, set flag and reset buffer index.
                rm_uart_receiveComplete = true;
                rm_uart_inputBufferIndex = 0;
            }

        break;
            default: break;
    }
}

/*******************************************************************************************************************//**
 * @} (end addtogroup r_sci_uart)
 **********************************************************************************************************************/
