/*
 * E45RA_MW276_C_io.c
 *
 *  Created on: 29.05.2024
 *      Author: a5050305
 */

#include "E45RA_MW276_C_config.h"
#include "E45RA_MW276_C_io.h"
#include "E45RA_MW276_C_interface.h"

static volatile bool pinControlS=false ;
static unsigned char dutyCycleS=50 ;

/*******************************************************************************************************************//**
 * @brief      Use pin control enable/disable fpr all port accesses
 *
 * @param[in]  false/true [default is false after reset]
 * @retval     none
 **********************************************************************************************************************/

void mipi_dsi_lcd_usePinControl_focuslcd_e45ra_mw276_c (bool pinControl)
{
    pinControlS= pinControl;
}


/*******************************************************************************************************************//**
 * @brief      Initialize LCD
 *
 * @param[in]  None.
 * @retval     Status
 **********************************************************************************************************************/
fsp_err_t mipi_dsi_lcd_init_focuslcd_e45ra_mw276_c (void)
{
    fsp_err_t err = mipi_dsi_io_push_table (g_lcd_init_focuslcd_e45ra_mw276_c);
    return(err);
}

/*******************************************************************************************************************//**
 * @brief      Reset the LCD board including the touch controller
 *
 * @param[in]  None.
 * @retval     None.
 **********************************************************************************************************************/
void mipi_dsi_lcd_reset_focuslcd_e45ra_mw276_c (void)
{
     if (pinControlS)
         R_BSP_PinAccessEnable();
     /* Reset touch chip by setting GPIO reset pin low. */
     R_IOPORT_PinWrite(&g_ioport_ctrl, PIN_DISPLAY_RST, BSP_IO_LEVEL_LOW);
     R_IOPORT_PinCfg(&g_ioport_ctrl, PIN_DISPLAY_INT, IOPORT_CFG_PORT_DIRECTION_OUTPUT | IOPORT_CFG_PORT_OUTPUT_LOW);
     R_BSP_SoftwareDelay(200, BSP_DELAY_UNITS_MICROSECONDS);

     /* Start Delay to set the device slave address to 0x28/0x29 */
     R_IOPORT_PinWrite(&g_ioport_ctrl, PIN_DISPLAY_INT, BSP_IO_LEVEL_HIGH);
     R_BSP_SoftwareDelay(200, BSP_DELAY_UNITS_MICROSECONDS);

     /* Release touch chip from reset */
     R_IOPORT_PinWrite(&g_ioport_ctrl, PIN_DISPLAY_RST, BSP_IO_LEVEL_HIGH);
     R_BSP_SoftwareDelay(10, BSP_DELAY_UNITS_MILLISECONDS);

     /* Set GPIO INT pin low */
     R_IOPORT_PinWrite(&g_ioport_ctrl, PIN_DISPLAY_INT, BSP_IO_LEVEL_LOW);
     R_BSP_SoftwareDelay(100, BSP_DELAY_UNITS_MILLISECONDS);

     /* Release Touch chip interrupt pin for control  */
     R_IOPORT_PinCfg(&g_ioport_ctrl, PIN_DISPLAY_INT, IOPORT_CFG_PORT_DIRECTION_INPUT | IOPORT_CFG_EVENT_RISING_EDGE | IOPORT_CFG_IRQ_ENABLE);
     if (pinControlS)
         R_BSP_PinAccessDisable();
}


fsp_err_t mipi_dsi_lcd_backlightOn_focuslcd_e45ra_mw276_c (void)
{
  fsp_err_t err = FSP_SUCCESS ;
  #ifndef STACK_F_TIMER
    if (pinControlS)
      R_BSP_PinAccessEnable();
    err= R_IOPORT_PinWrite(&g_ioport_ctrl, PIN_DISPLAY_BACKLIGHT, BSP_IO_LEVEL_HIGH);
    if (pinControlS)
      R_BSP_PinAccessDisable();
  #else
    err = mipi_dsi_lcd_backlightSetDutyCycle_focuslcd_e45ra_mw276_c(dutyCycleS);
  #endif
  return(err);
}


fsp_err_t mipi_dsi_lcd_backlightOff_focuslcd_e45ra_mw276_c (void)
{
  fsp_err_t err = FSP_SUCCESS ;
  #ifndef STACK_F_TIMER
    if (pinControlS)
      R_BSP_PinAccessEnable();
    err= R_IOPORT_PinWrite(&g_ioport_ctrl, PIN_DISPLAY_BACKLIGHT, BSP_IO_LEVEL_LOW);
    if (pinControlS)
      R_BSP_PinAccessDisable();
  #else
      unsigned char bl = dutyCycleS;
      err = mipi_dsi_lcd_backlightSetDutyCycle_focuslcd_e45ra_mw276_c((unsigned char)0);
      dutyCycleS = bl ;
  #endif
    return(err);
}


#ifdef STACK_F_TIMER
fsp_err_t mipi_dsi_lcd_backlightTimerOpen_focuslcd_e45ra_mw276_c(unsigned char duty_cycle)
{
    fsp_err_t err = FSP_SUCCESS ;

    err= R_GPT_Open(STACK_F_TIMER.p_ctrl,STACK_F_TIMER.p_cfg);
    FSP_ERROR_RETURN(FSP_SUCCESS == err, err);

    err= mipi_dsi_lcd_backlightSetDutyCycle_focuslcd_e45ra_mw276_c(duty_cycle);
    FSP_ERROR_RETURN(FSP_SUCCESS == err, err);

    err= R_GPT_Start(STACK_F_TIMER.p_ctrl);
    FSP_ERROR_RETURN(FSP_SUCCESS == err, err);

    return(err);
}
#endif


/*******************************************************************************************************************//**
 * @brief      Set duty cycle for display back light
 *
 * @param[in]  duty_cycle value 0-100%, 0-off and >0 is on in case no timer is specified
 * @retval     Status
 **********************************************************************************************************************/

fsp_err_t mipi_dsi_lcd_backlightSetDutyCycle_focuslcd_e45ra_mw276_c(unsigned char duty_cycle)
{
  fsp_err_t err = FSP_SUCCESS ;
  #ifdef STACK_F_TIMER
    timer_info_t act;
    R_GPT_InfoGet(STACK_F_TIMER.p_ctrl, &act);
    uint32_t act_period_counts = act.period_counts;
    uint32_t duty_cycle_count = (uint64_t)((uint64_t)(act_period_counts * (100-duty_cycle))/ 100);

    err = R_GPT_DutyCycleSet(STACK_F_TIMER.p_ctrl, duty_cycle_count, (uint32_t)STACK_F_TIMER_PIN_IS_ON);
    if (err == FSP_SUCCESS)
        dutyCycleS= duty_cycle;
    return(err);
  #else
    if (duty_cycle==0)
    {
       err= mipi_dsi_lcd_backlightOff_focuslcd_e45ra_mw276_c();
       dutyCycleS=0;
    }
    else
    {
       err= mipi_dsi_lcd_backlightOn_focuslcd_e45ra_mw276_c();
       dutyCycleS=100;
    }
  #endif
  return(err);
}


/*******************************************************************************************************************//**
 * @brief      Get duty cycle of display back light (stored value)
 *
 * @param[in]  void
 * @retval     value
 **********************************************************************************************************************/

unsigned char mipi_dsi_lcd_backlightGetDutyCycle_focuslcd_e45ra_mw276_c(void)
{
  return(dutyCycleS);
}
