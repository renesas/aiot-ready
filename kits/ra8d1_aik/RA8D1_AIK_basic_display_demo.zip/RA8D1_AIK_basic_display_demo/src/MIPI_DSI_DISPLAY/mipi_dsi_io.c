/*
 * mipi_dsi_io.c
 *
 *  Created on: 29.05.2024
 *      Author: a5050305
 */


#include "mipi_dsi_io.h"
#include "hal_data.h"

volatile bool g_message_sent = false;
volatile mipi_dsi_phy_status_t g_phy_status;
volatile bool g_ulps_flag    = false;

/*******************************************************************************************************************//**
 * @brief      Initialize LCD
 *
 * @param[in]  table  LCD Controller Initialization structure.
 * @retval     None.
 **********************************************************************************************************************/
fsp_err_t mipi_dsi_io_push_table (const lcd_table_setting_t *table)
{
    fsp_err_t err = FSP_SUCCESS;
    const lcd_table_setting_t *p_entry = table;

    while (MIPI_DSI_DISPLAY_CONFIG_DATA_END_OF_TABLE != p_entry->cmd_id)
    {
        mipi_dsi_cmd_t msg =
        {
          .channel = 0,
          .cmd_id = p_entry->cmd_id,
          .flags = p_entry->flags,
          .tx_len = p_entry->size,
          .p_tx_buffer = p_entry->buffer,
        };

        if (MIPI_DSI_DISPLAY_CONFIG_DATA_DELAY_FLAG == msg.cmd_id)
        {
            R_BSP_SoftwareDelay (table->size, BSP_DELAY_UNITS_MILLISECONDS);
        }
        else
        {
            g_message_sent = false;
            /* Send a command to the peripheral device */
            err = R_MIPI_DSI_Command (&g_mipi_dsi0_ctrl, &msg);
            if ( err != FSP_SUCCESS)
               return(err);
            /* Wait */
            while (!g_message_sent);
        }
        p_entry++;
    }
    return(err);
}


/*******************************************************************************************************************//**
 * @brief       This function is used to Wait for mipi dsi event.
 *
 * @param[in]   event   : Expected events
 * @retval      FSP_SUCCESS : Upon successful operation, otherwise: failed
 **********************************************************************************************************************/
static fsp_err_t wait_for_mipi_dsi_event (mipi_dsi_phy_status_t event)
{
    uint32_t timeout = R_FSP_SystemClockHzGet(FSP_PRIV_CLOCK_ICLK) / 10;
    while (timeout-- && ((g_phy_status & event) != event))
    {
        ;
    }
    return timeout ? FSP_SUCCESS : FSP_ERR_TIMEOUT;
}


/*******************************************************************************************************************//**
 * @brief      This function is used to enter Ultra-low Power State (ULPS).
 *
 * @param[in]  none
 * @retval     status
 **********************************************************************************************************************/
fsp_err_t mipi_dsi_ulps_enter(void)
{
    fsp_err_t err = FSP_SUCCESS;
    /* Enter Ultra-low Power State (ULPS) */
    g_phy_status = MIPI_DSI_PHY_STATUS_NONE;
    err = R_MIPI_DSI_UlpsEnter (&g_mipi_dsi0_ctrl, (mipi_dsi_lane_t) MIPI_DSI_LANE_DATA_ALL);
    if (err != FSP_SUCCESS)
        return(err) ;

    /* Wait for a ULPS event */
    err = wait_for_mipi_dsi_event(MIPI_DSI_PHY_STATUS_DATA_LANE_ULPS_ENTER);
    if (err != FSP_SUCCESS)
         return(err) ;
    g_ulps_flag = true;
    return(err);
}

/*******************************************************************************************************************//**
 * @brief      This function is used to exit Ultra-low Power State (ULPS).
 *
 * @param[in]  none
 * @retval     statsu
 **********************************************************************************************************************/
fsp_err_t mipi_dsi_ulps_exit(void)
{
    fsp_err_t err = FSP_SUCCESS;
    /* Exit Ultra-low Power State (ULPS) */
    g_phy_status = MIPI_DSI_PHY_STATUS_NONE;
    err = R_MIPI_DSI_UlpsExit (&g_mipi_dsi0_ctrl, (mipi_dsi_lane_t) (MIPI_DSI_LANE_DATA_ALL));
    if (err != FSP_SUCCESS)
        return(err) ;

    /* Wait for a ULPS event */
    err = wait_for_mipi_dsi_event(MIPI_DSI_PHY_STATUS_DATA_LANE_ULPS_EXIT);
    if (err != FSP_SUCCESS)
          return(err) ;
    g_ulps_flag = false;
    return(err) ;
}


/*******************************************************************************************************************//**
 * @brief      This function is used to exit Ultra-low Power State (ULPS) status.
 *
 * @param[in]  none
 * @retval     statsu
 **********************************************************************************************************************/
bool mipi_dsi_ulps_get_status(void)
{
    return(g_ulps_flag);
}

//
// CALLBACK FUNCTION DEFINITONS
//

/*******************************************************************************************************************//**
 * @brief      Callback functions for MIPI DSI interrupts
 *
 * @param[in]  p_args    Callback arguments
 * @retval     none
 **********************************************************************************************************************/
void mipi_dsi_callback(mipi_dsi_callback_args_t *p_args)
{
    switch (p_args->event)
    {
        case MIPI_DSI_EVENT_SEQUENCE_0:
        {
            if (MIPI_DSI_SEQUENCE_STATUS_DESCRIPTORS_FINISHED == p_args->tx_status)
            {
                g_message_sent = true;
            }
            break;
        }
        case MIPI_DSI_EVENT_PHY:
        {
            g_phy_status |= p_args->phy_status;
            break;
        }
        default:
        {
            break;
        }

    }
}
