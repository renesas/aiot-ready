/*
 * E45RA_MW276_C_io.h
 *
 *  Created on: 29.05.2024
 *      Author: a5050305
 */

#ifndef MIPI_DSI_DISPLAY_E45RA_MW276_C_IO_H_
#define MIPI_DSI_DISPLAY_E45RA_MW276_C_IO_H_

#include "hal_data.h"

void mipi_dsi_lcd_usePinControl_focuslcd_e45ra_mw276_c (bool pinControl);
fsp_err_t mipi_dsi_lcd_init_focuslcd_e45ra_mw276_c (void);
void mipi_dsi_lcd_reset_focuslcd_e45ra_mw276_c (void);
fsp_err_t mipi_dsi_lcd_backlightOn_focuslcd_e45ra_mw276_c (void);
fsp_err_t mipi_dsi_lcd_backlightOff_focuslcd_e45ra_mw276_c (void);
fsp_err_t mipi_dsi_lcd_backlightSetDutyCycle_focuslcd_e45ra_mw276_c(unsigned char duty_cycle);
unsigned char mipi_dsi_lcd_backlightGetDutyCycle_focuslcd_e45ra_mw276_c(void);

#endif /* MIPI_DSI_DISPLAY_E45RA_MW276_C_IO_H_ */
