/*
 * mipi_dsi_io.c
 *
 *  Created on: 29.05.2024
 *      Author: a5050305
 */

#ifndef MIPI_DSI_DISPLAY_MIPI_DSI_IO_C_
#define MIPI_DSI_DISPLAY_MIPI_DSI_IO_C_

#include "hal_data.h"

typedef struct
{
    unsigned char        size;
    unsigned char        buffer[10];
    mipi_dsi_cmd_id_t    cmd_id;
    mipi_dsi_cmd_flag_t  flags;
} lcd_table_setting_t;

#define MIPI_DSI_DISPLAY_CONFIG_DATA_DELAY_FLAG      ((mipi_dsi_cmd_id_t) 0xFE)
#define MIPI_DSI_DISPLAY_CONFIG_DATA_END_OF_TABLE    ((mipi_dsi_cmd_id_t) 0xFD)

fsp_err_t mipi_dsi_io_push_table (const lcd_table_setting_t *table);
fsp_err_t mipi_dsi_ulps_enter(void);
fsp_err_t mipi_dsi_ulps_exit(void);
bool mipi_dsi_ulps_get_status(void);

#endif /* MIPI_DSI_DISPLAY_MIPI_DSI_IO_C_ */
