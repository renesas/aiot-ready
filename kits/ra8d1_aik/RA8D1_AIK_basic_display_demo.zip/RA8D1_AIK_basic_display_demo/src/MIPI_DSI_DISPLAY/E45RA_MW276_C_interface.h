/*
 * E45RA_MW276_C_interface.h
 *
 *  Created on: 29.05.2024
 *      Author: a5050305
 */

#ifndef MIPI_DSI_DISPLAY_E45RA_MW276_C_INTERFACE_H_
#define MIPI_DSI_DISPLAY_E45RA_MW276_C_INTERFACE_H_

#include "hal_data.h"

// Please adapt the settings following your board design and stack settings

// IO Pins for MIPI display control
#define PIN_DISPLAY_INT                              (DISP_INT)
#define PIN_DISPLAY_RST                              (DISP_RST)
#define PIN_DISPLAY_BACKLIGHT                        (DISP_BLEN)

// Name of GPT module (should match in most cases with the following setting)
#define STACK_F_IOPORT g_ioport

// In case the PIN_DISPLAY_BACKLIGHT is on an timer GPIO withPWM the following setting can be enabled
#define STACK_F_TIMER g_timer_pwm_backlight_1
//#define   STACK_F_TIMER_PIN_IS_ON GPT_IO_PIN_GTIOCA
#define   STACK_F_TIMER_PIN_IS_ON GPT_IO_PIN_GTIOCB

#endif /* MIPI_DSI_DISPLAY_E45RA_MW276_C_INTERFACE_H_ */
