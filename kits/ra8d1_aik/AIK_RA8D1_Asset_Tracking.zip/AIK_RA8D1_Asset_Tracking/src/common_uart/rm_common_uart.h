/***********************************************************************************************************************
 * File Name    : rm_uart.h
 * Description  : Contains function declaration of uart_ep.c and Macros.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/

#ifndef UART_EP_H_
#define UART_EP_H_

#define UART_DEVICE_DESCRIPTOR g_uart4_jlob

/***********************************************************************************************************************
 * Includes
 **********************************************************************************************************************/

#include "r_sci_b_uart.h"
#include "hal_data.h"

/* Macro definition */
/** UART communication result */
typedef enum e_uart_comresult
{
    UART_SUCCESS = 0, ///< COMMUNICATE SUCCESSFULLY
    UART_ERROR   = 1, ///< error detected
    UART_TIMEOUT = 2, ///< Timeout
} uart_comresult_t;

#define CARRIAGE_ASCII            (13u)     /* Carriage return */
#define ZERO_ASCII                (48u)     /* ASCII value of zero */
#define NINE_ASCII                (57u)     /* ASCII value for nine */
#define DATA_LENGTH               (64u)     /* Expected Input Data length */
#define UART_ERROR_EVENTS         (UART_EVENT_BREAK_DETECT | UART_EVENT_ERR_OVERFLOW | UART_EVENT_ERR_FRAMING | \
                                   UART_EVENT_ERR_PARITY)    /* UART Error event bits mapped in registers */

// Buffer Sizes
#define UART_BUFFER_SIZE 1024
#define INPUT_BUFFER_SIZE 1024

// Buffers
extern char rm_uart_outputBuffer[UART_BUFFER_SIZE];
extern char rm_uart_inputBuffer[INPUT_BUFFER_SIZE];
extern volatile int rm_uart_inputBufferIndex;

extern volatile bool rm_uart_transmitComplete;
extern volatile bool rm_uart_receiveComplete;

/* Function declaration */
//fsp_err_t uart_ep_demo(void);
//fsp_err_t uart_print_user_msg(uint8_t *p_msg);
//fsp_err_t uart_print_user_data(uint8_t *p_msg);
extern fsp_err_t rm_uart_initialize(void);
extern fsp_err_t rm_deinit_uart(void);

#endif /* UART_EP_H_ */
