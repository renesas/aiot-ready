#ifndef __SPEEX_DATA2_H
#define __SPEEX_DATA2_H

extern unsigned int g_uSpeexData2Begin;
extern unsigned int g_uSpeexData2End;

#endif
