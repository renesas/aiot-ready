#ifndef __SPEEX_DATA_H
#define __SPEEX_DATA_H

extern unsigned int g_uSpeexDataBegin;

#endif
