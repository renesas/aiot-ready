#ifndef __CYB_MODEL_H
#define __CYB_MODEL_H

extern unsigned int uCYModelBegin;

#endif
