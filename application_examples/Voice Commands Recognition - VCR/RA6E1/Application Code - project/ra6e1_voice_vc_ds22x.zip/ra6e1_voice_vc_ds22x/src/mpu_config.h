/*
 * mpu_config.h
 *
 *  Created on: Mar 8, 2023
 *      Author: a5123412
 */

#ifndef MPU_CONFIG_H_
#define MPU_CONFIG_H_

#include "hal_data.h"

void mpu_config_quadspi(void);
void mpu_config_sram_area(uint32_t dwStartAddress, uint32_t dwEndAddress);

#endif /* MPU_CONFIG_H_ */
