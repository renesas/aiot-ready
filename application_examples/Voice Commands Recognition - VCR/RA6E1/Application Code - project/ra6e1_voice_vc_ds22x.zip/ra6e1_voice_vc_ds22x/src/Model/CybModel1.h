#ifndef __CYB_MODEL1_H
#define __CYB_MODEL1_H

extern unsigned int uCYModel1Begin;
extern unsigned int uCYModel1End;

#endif
