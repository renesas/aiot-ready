/*
 * mpu_config.h
 *
 *  Created on: Mar 8, 2023
 *      Author: a5123412
 */

#ifndef MPU_CONFIG_H_
#define MPU_CONFIG_H_

#include "hal_data.h"

void mpu_config_dtc_transfer_info_area(void);

#endif /* MPU_CONFIG_H_ */
