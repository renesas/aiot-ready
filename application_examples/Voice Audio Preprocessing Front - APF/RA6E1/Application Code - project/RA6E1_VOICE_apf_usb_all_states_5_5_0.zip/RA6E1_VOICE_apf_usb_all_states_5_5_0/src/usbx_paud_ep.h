/***********************************************************************************************************************
 * File Name    : usbx_paud_ep.h
 * Description  : Contains macros, data structures and functions used usbx_paud_ep.h
 ***********************************************************************************************************************/
/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/

#ifndef USBX_PAUD_EP_H_
#define USBX_PAUD_EP_H_

/*******************************************************************************************************************//**
 * @addtogroup usbx_paud_ep
 * @{
 **********************************************************************************************************************/

/******************************************************************************
 Macro definitions
 ******************************************************************************/
/* To display EP info on the RTT viewer */
#define EP_INFO        "\r\nThis example project demonstrates the basic functionalities of USBX "\
            "\r\nPeripheral Audio device and Digital Microphone I2S driver on Renesas RA MCUs based on Renesas FSP using Azure RTOS. "\
            "\r\nRA MCU will be connected as USBX peripheral audio to the host PC. The digital microphone samples the audio at 16-bit 16kHz  "\
            "\r\nmono channel and RA MCU collect the data as per I2S protocol. The continuous received data from the digital microphone transfered to the USB peripheral, "\
            "\r\nWhen host PC starts recording the audio using the audio recorder(Audacity), MCU will transmit the "\
            "\r\ndigital microphone continuous stream data to the host PC using the isochronous IN, through USBX PAUD module. "\
            "\r\nThe user will be able to play, listen and verify the recorded audio file data.\r\n"\

/* macros to print info, error and trap the error.*/
#define PRINT_INFO_STR(str)  app_rtt_print_data(RTT_OUTPUT_MESSAGE_APP_INFO_STR, sizeof(str), str);
#define PRINT_ERR_STR(str)   app_rtt_print_data(RTT_OUTPUT_MESSAGE_APP_ERR_STR, sizeof(str), str);
#define ERROR_TRAP(err)      app_rtt_print_data(RTT_OUTPUT_MESSAGE_APP_ERR_TRAP, sizeof(UINT *), &err);

/* USBx device configuration settings */

/******************************************************************************
    Macro definitions
 ******************************************************************************/
#define INDEX_0                     (0)
#define VALUE_0                     (0)
#define VALUE_1                     (1)
#define VALUE_2                     (2)
#define VALUE_4                     (4)
#define VALUE_85                    (85)
#define VALUE_247                   (247)
#define VALUE_275                   (275)
#define VALUE_108                   (108)
#define VALUE_126                   (126)


#define MEMPOOL_SIZE                (18432 * 2)
#define STACK_SIZE                  (1024U)
#define NUM_OF_FRAME                (8U)
#define USB_AUDIO_BUFFER_SIZE        I2SRBUF_SAMPLES * sizeof(short)

#define USB_APL_ON                      (1U)
#define USB_APL_OFF                     (0U)
#define USB_MAX_PACKET_SIZE_IN          (160)
#define USB_PLUG_IN                     (1UL << 0)
#define USB_PLUG_OUT                    (1UL << 1)
#define USB_PLUG_IN_CLEAR               ~(1UL << 0)
#define USB_PLUG_OUT_CLEAR              ~(1UL << 1)
#define USB_DATA_READ_COMPLETE          (1UL << 2)
#define USB_AUDIO_RECORD_START          (1UL << 3)
#define USB_AUDIO_RECORD_START_CLEAR    ~(1UL << 3)
#define USB_AUDIO_RECORD_STOP           (1UL << 4)
#define USB_AUDIO_RECORD_STOP_CLEAR     ~(1UL << 4)



#endif /* USBX_PAUD_EP_H_ */
/*******************************************************************************************************************//**
 * @} (end defgroup usbx_paud_ep)
 **********************************************************************************************************************/
