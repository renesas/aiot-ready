/*------------------------------------------------------------------------------
 *                                                                              
 *                   TTTTTTTT                                                   
 *                   TTTTTTTT  T       TTT      TTT   T    TT     TT      T     
 *                       TT    TT      TT TT   TT T   TT   TT    TT       TT    
 *                       T     TT      TT  TT  TT TT  TT    T   TT        TT    
 *              T        T    TTTT    TTT  TT TT  TT  TTT   TT  T    T   TTTT   
 *      TTTT   TTT       T    TT T    TT   TT TT  TT  TTTT  TT TT TTTT   TT T   
 *    TTTTTT  TTTT       T    T  TT   TT  TT  TT  TT  TT TT TT TT    T   T  TT  
 *      TTTTTTTT         T   TTTTTT   TT TT    T  TT  TT  TTTT  TT   T  TTTTTT  
 *      TTTTTTT          T   TT   TT  TTTT     TT T   TT   TTT  TT   T  TT  TTT 
 *      TTTTTTTT         T   TT   TT  TT TT     TTT   TT    TT   TTT T  TT   TT 
 *  TTTTTTTTTTTTT        T   TT   TTT TT  TT    TT    TT     TT    TTT  TT   TTT
 * TTTTTTTTTTTTTT                                                               
 *     TTTTTTTTTT                                                               
 *     TTTTTTT TT                                                               
 *       TTT   T     TTTTTT                                                     
 *        TT         TTTTTT   TT   T  T  T  T  T    T  TT     T     T  TT     TT
 *        TT            T    T    T   T  T  T  T   T T  T    T T   T    TT   TT 
 *        T             T   TTT  T    T  T  TT T  TT T  T   TT T  T      TT TT  
 *                      T   T    T   TTTTT  TTTT  TT T  T   TT T  T TT     TT   
 *                      T   T    T    TT T  T TTT TT T  T   TT T  T  T     T    
 *                      T   TT    T    T T  T  TT  T T  T    T T  TT T     T    
 *                      T    TTT   T   T T  T   T  TT   TTT  TT    TTT     T    
 *                                                                              
 *                                                                              
 *------------------------------------------------------------------------------
 *
 * Copyright (C) 2023 Taronga Technology Inc. Unpublished work.
 * This computer program includes Confidential, Proprietary Information
 * and is a Trade Secret of Taronga Technology Inc. All use, disclosure, 
 * and/or  reproduction is prohibited unless authorized in writing.  
 * All Rights Reserved.
 *------------------------------------------------------------------------------
 */

#ifndef _helpfunc_h_
#define _helpfunc_h_


///////////////////////////////////////////////////////////////////////////////////////////////////
//// IMPLEMENTATION DISABLE
///////////////////////////////////////////////////////////////////////////////////////////////////
#if (defined __chess__) || (defined __SYNTHESIS__) || (defined __CR16__)
   #define __DO_NOT_WRITE_FILE_REPORTS__  1
   #define __TYPE_EMPTY__                 1
#endif // __SYNTHESIS__



///////////////////////////////////////////////////////////////////////////////////////////////////
/// TYPES and Helper functions
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __DO_NOT_WRITE_FILE_REPORTS__

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
// #include <iostream>
// #include <fstream>

// using namespace std;


/**********************************/
#if defined(__TYPE_EMPTY__) || defined(__DO_NOT_WRITE_FILE_REPORTS__) || defined(FORCE_FLOAT)
  #define DBL(a)   a
  #define DEC(a)   a
  #define DECP(a)   a
  #define BPBIN(a) "--"
  #define BPHEX(a) "--"
  #define PRINTFBIN(var,a,b) 
#elif defined(CTYPES_ONLY)
  #define DBL(a) ((double)a)
  #define DEC(a) ((int)a)
  #define DECP(a) ((long)a)
  #define BPBIN(a) "--"
  #define BPHEX(a) "--"
  #define PRINTFBIN(var,a,b) for(int _indx_=1;_indx_<=b;_indx_++) PRINTF1(var,"%d",(a&(1<<(b-_indx_)))?1:0)
  #define FPRINTFBINF(var,a,b) {int _m=1;for(int _indx_=1;_indx_<=b;_indx_++) {FPRINTF1(var,"%d",(((int)(a*_m))&1)?1:0);_m*=2;}}
  #define FPRINTFBINN(var,a,b) {for(int _indx_=1;_indx_<=b;_indx_++) FPRINTF1(var,"%d",(a&(1<<(b-_indx_)))?1:0);FPRINTF0(var,"\n");}
  #define FPRINTFBINFN(var,a,b) {int _m=1;for(int _indx_=1;_indx_<=b;_indx_++) {FPRINTF1(var,"%d",(((int)(a*_m))&1)?1:0);_m*=2;}FPRINTF0(var,"\n");}
#elif defined(USE_SHORTS)
  #define DBL(a) (a)
  #define DEC(a) ((int)a)
  #define DECP(a) ((long)a)
  #define BPBIN(a) "--"
  #define BPHEX(a) "--"
  #define PRINTFBIN(var,a,b) for(int _indx_=1;_indx_<=b;_indx_++) PRINTF1(var,"%d",(a&(1<<(b-_indx_)))?1:0)
  #define FPRINTFBINF(var,a,b) {int _m=1;for(int _indx_=1;_indx_<=b;_indx_++) {FPRINTF1(var,"%d",(((int)(a*_m))&1)?1:0);_m*=2;}}
  #define FPRINTFBINN(var,a,b) {for(int _indx_=1;_indx_<=b;_indx_++) FPRINTF1(var,"%d",(a&(1<<(b-_indx_)))?1:0);FPRINTF0(var,"\n");}
  #define FPRINTFBINFN(var,a,b) {int _m=1;for(int _indx_=1;_indx_<=b;_indx_++) {FPRINTF1(var,"%d",(((int)(a*_m))&1)?1:0);_m*=2;}FPRINTF0(var,"\n");}
#else     // defined(NATIVE_CHESS)

#ifdef FXP_SYSTEMC
inline const char * hf_2bin(sc_fixed<16,16> a) {return a.to_bin()+2;}
inline const char * hf_2bin(sc_fixed<32,32> a) {return a.to_bin()+2;}
#endif
  #define DEC(a) (a.to_int())
  // #define DEC(a) (to_int(a))
  #define DBL(a) ((float)hf_2dbl(a))
  #define BPBIN(a) (hf_2bin(a).c_str())
  #define BPHEX(a) (a.to_hex().c_str())
  #define HEX(a) (a.to_hex())
#endif



#ifdef HAVE_SYSTEMC
/**
 * Template function to convert a variable to INTEGER.
 * If you have fractional sc_fixed value, then the to_int and to_int64 ONLY return the INTEGER part. 
 * These template functions return the whole variable as an integer. So this allows us to REMAP an sc_fixed to integer, bit by bit.
 * 
 * NOTE:
 * The toDec64 is special, becaus the current SYSTEMC (SystemC 2.3.2-Accellera) contains a BUG:
 * If the 32 bits of the sc_fixed value are ZERO, then the to_int64() returns 0, even if the MSB part is non-zero. 
 * We therefore split the word up in LSB and MSB. 
 */
template <int N,int M> int64_t toDec64(FIXED_SAT(N,M) v)
{
   if (N > 32)
   {
      sc_fixed<N-32,N-32> vMSB;
      sc_ufixed<32,32>    vLSB;
      vLSB.range(31,0)   = v.range(31,0);
      vMSB.range(N-33,0) = v.range(N-1,32);
      int64_t msb = (int64_t)vMSB.to_int();
      int64_t lsb = (int64_t)vLSB.to_uint();
      int64_t vv = (msb << 32) + (lsb & 0x00000000FFFFFFFF);
      // printf("V %s MSB %s LSB %s %8.8x %8.8x %16.16llx\n",v.to_hex().c_str(),vMSB.to_hex().c_str(),vLSB.to_hex().c_str(),(int)msb,(int)lsb,(long long unsigned)vv);
      return vv;
   }
   else
   {
      sc_fixed<N,N> vv;
      vv.range(N-1,0) = v.range(N-1,0);
      return vv.to_int64();
   }
}

template <int N,int M> int32_t toDec(FIXED_SAT(N,M) v)
{
   sc_fixed<N,N> vv;
   vv.range(N-1,0) = v.range(N-1,0);
   return vv.to_int();
}

template <int N,int M> void fromDec(int32_t v, FIXED_SAT(N,M) r)
{
   sc_ufixed<N,N> vv = v;
   r.range(N-1,0) = vv.range(N-1,0);
}

template <int N,int M> void fromDec64(int64_t v, FIXED_SAT(N,M) r)
{
   sc_ufixed<N,N> vv = v;
   r.range(N-1,0) = vv.range(N-1,0);
}

template <int N,int M> FIXED_SAT(N,M) toFix(int32_t v)
{
   UFIXED_WRAP(N,N) vv = v;
   FIXED_SAT(N,M) r;
   r.range(N-1,0) = vv.range(N-1,0);
   return r;
}

template <int N,int M> FIXED_SAT(N,M) toFix(int64_t v)
{
   UFIXED_WRAP(N,N) vv = v;
   FIXED_SAT(N,M) r;
   r.range(N-1,0) = vv.range(N-1,0);
   return r;
}
#endif


#else

  #define DBL(a)   a
  #define DEC(a)   a
  #define BPBIN(a) "--"
  #define BPHEX(a) "--"
  #define PRINTFBIN(var,a,b) 
  #define FPRINTFBIN(var,a,b) 
  #define FPRINTFBINF(var,a,b) 
  #define FPRINTFBINN(var,a,b) 
  #define FPRINTFBINFN(var,a,b)
  #define toDec(a) a
  #define toDec64(a) a
  #define toFix(a) a
  

#endif



///////////////////////////////////////////////////////////////////////////////////////////////////
/// FILE REPORTS //////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifdef __DO_NOT_WRITE_FILE_REPORTS__

#define READ_FROM_FILE( var, name, eofAction ) ;
#define READ_ARRAY_FROM_FILE( var, maxIndx, name, eofAction ) ;
#define REPORT_TO_FILE(var,name) ;
#define REPORT_TO_FILEF(var,name) ;
#define REPORTU_TO_FILE(var,name) ;
#define REPORT_IT_TO_FILE( var ) ;
#define REPORT_ARRAY_TO_FILE_ASARRAY( var, maxIndx, name ) ;
#define REPORT_ARRAY_TO_FILE( var, maxIndx, name ) ;
#define REPORT_FLP_ARRAY_TO_FILE( var, maxIndx, name ) 
#define REPORT_CMPLX_FLP_ARRAY_TO_FILE( var, maxIndx, name ) 
#define REPORT_DEC_TO_FILE( var, name )
#define CREPORT_HEX_TO_FILE(c, var, name )

#define TO_BIN_FILE( var, name, action ) ;
#define TO_WAV_FILE( var, name ) ;
#define FPRINTF0(var,string)           
#define FPRINTF1(var,string,a)         
#define FPRINTF2(var,string,a,b)       
#define FPRINTF3(var,string,a,b,c)     
#define FPRINTF4(var,string,a,b,c,d)   
#define FPRINTF5(var,string,a,b,c,d,e) 
#define FPRINTF6(var,string,a,b,c,d,e,f) 
#define FPRINTF7(var,string,a,b,c,d,e,f,g) 
#define FPRINTF8(var,string,a,b,c,d,e,f,g,h) 
#define FPRINTF9(var,string,a,b,c,d,e,f,g,h,i) 
#define FPRINTF10(var,string,a,b,c,d,e,f,g,h,i,j) 
#define FPRINTF11(var,string,a,b,c,d,e,f,g,h,i,j,k) 
#define CPRINTF0(b,var,string)           

#define DECLFILE(a) 
#define APPENDFILE(a) 
#define FOPEN(filep,filen)
#define FOPENW(filep,filen)
#define FOPENR(filep,filen)
#define FOPENA(filep,filen)
#define FCLOSE(filep)
#define FCLOSE2(filep)
#define FFLUSH(filep)
#define DECLFOPEN(filep,filen) 
#define DDECLFOPEN(dbg,filep,filen) 


/* New macros with debugging variable to turn then on/off */
#define DPRINTF0(dbg,var,string)           
#define DPRINTF1(dbg,var,string,a)         
#define DPRINTF2(dbg,var,string,a,b)       
#define DPRINTF3(dbg,var,string,a,b,c)     
#define DPRINTF4(dbg,var,string,a,b,c,d)   
#define DPRINTF5(dbg,var,string,a,b,c,d,e) 
#define DPRINTF6(dbg,var,string,a,b,c,d,e,f) 
#define DPRINTF7(dbg,var,string,a,b,c,d,e,f,g) 
#define DPRINTF8(dbg,var,string,a,b,c,d,e,f,g,h) 
#define DPRINTF9(dbg,var,string,a,b,c,d,e,f,g,h,i) 
#define DPRINTF10(dbg,var,string,a,b,c,d,e,f,g,h,i,j) 
#define DPRINTF11(dbg,var,string,a,b,c,d,e,f,g,h,i,j,k) 

#define DFOPEN(dbg,filep,filen)
#define DFCLOSE(dbg,filep)
#define SET_VERBOSE(lev)
#define ADD_VERBOSE(lev)


#else // __DO_NOT_WRITE_FILE_REPORTS__

// #define ToBinStr(a) a.bpBin()
#define ToBinStr(a) ((a.to_bin())+2)
#define ToBinStrU(a) ((a.to_bin())+3)



#define READ_FROM_FILE( var, name, eofAction ) { static ifstream theFile( name ); if (!(theFile >> (var))) { eofAction; } }
#define READ_ARRAY_FROM_FILE( var, maxIndx, name, eofAction ) { static ifstream theFile( name ); for ( int _indx_ = 0; _indx_ < maxIndx; _indx_++ ) { if (!(theFile >> (var))) { eofAction; } } }
// #define REPORT_TO_FILE( var, name ) { static ofstream theFile( name ); theFile << BPBIN(var) << "\n"; theFile.flush(); }
#define REPORT_TO_FILE( var, name ) { static FILE *fp=fopen( name ,"w");  PRINTFBIN(fp, var,16); fprintf(fp,"\n"); fflush(fp); }
#define REPORT_TO_FILEF( var, name ) { static FILE *fp=fopen( name ,"w");  FPRINTFBINF(fp, var,16); fprintf(fp,"\n"); fflush(fp); }
#define REPORTU_TO_FILE( var, name ) { static ofstream theFile( name ); theFile << BPBIN(var) << "\n"; theFile.flush(); }
#define REPORT_IT_TO_FILE( var ) REPORT_TO_FILE( var, #var".out" );
#define REPORT_ARRAY_TO_FILE( var, maxIndx, name ) { static ofstream theFile( name ); for ( int _indx_ = 0; _indx_ < maxIndx; _indx_++ ) { theFile << BPBIN(var[_indx_]) << "\n"; theFile.flush(); } }
#define REPORT_ARRAY_TO_FILE_ASARRAY( var, maxIndx, name ) { static ofstream theFile( name ); for ( int _indx_ = 0; _indx_ < maxIndx; _indx_++ ) { theFile << ToBinStr(var) << " "; } theFile << "\n"; theFile.flush(); }
#define REPORT_FLP_ARRAY_TO_FILE( var, maxIndx, name ) { static FILE *fp=fopen( name ,"w"); for ( int _indx_ = 0; _indx_ < maxIndx; _indx_++ ) { fprintf(fp,"%12.8f\n", DBL(var[_indx_])); fflush(fp); } }
#define REPORT_CMPLX_FLP_ARRAY_TO_FILE( var, maxIndx, name ) { static FILE *fp=fopen( name ,"w"); for ( int _indx_ = 0; _indx_ < maxIndx; _indx_++ ) { fprintf(fp,"%12.8f\n", DBL(extract_low(var[_indx_]))); fprintf(fp,"%12.8f\n", DBL(extract_high(var[_indx_])));fflush(fp); } }
#define TO_WAV_FILE( var, name ) { }
#define REPORT_DEC_TO_FILE( var, name ) { static FILE *fp=fopen( name ,"w"); fprintf(fp,"%8d\n",DEC(var)); fflush(fp); }
#define CREPORT_HEX_TO_FILE(a, var, name ) { static FILE *fp=fopen( name ,"w"); static int cnt=0; fprintf(fp,"%8.8X",(var)); if (++cnt >= a) {fprintf(fp,"\n");cnt=0;} fflush(fp); }


#define FPRINTF0(var,string)             fprintf(var,string)
#define FPRINTF1(var,string,a)           fprintf(var,string,a)
#define FPRINTF2(var,string,a,b)         fprintf(var,string,a,b)
#define FPRINTF3(var,string,a,b,c)       fprintf(var,string,a,b,c)
#define FPRINTF4(var,string,a,b,c,d)     fprintf(var,string,a,b,c,d)
#define FPRINTF5(var,string,a,b,c,d,e)   fprintf(var,string,a,b,c,d,e)
#define FPRINTF6(var,string,a,b,c,d,e,f) fprintf(var,string,a,b,c,d,e,f)
#define FPRINTF7(var,string,a,b,c,d,e,f,g) fprintf(var,string,a,b,c,d,e,f,g)
#define FPRINTF8(var,string,a,b,c,d,e,f,g,h) fprintf(var,string,a,b,c,d,e,f,g,h)
#define FPRINTF9(var,string,a,b,c,d,e,f,g,h,i) fprintf(var,string,a,b,c,d,e,f,g,h,i)
#define FPRINTF10(var,string,a,b,c,d,e,f,g,h,i,j) fprintf(var,string,a,b,c,d,e,f,g,h,i,j)
#define FPRINTF11(var,string,a,b,c,d,e,f,g,h,i,j,k) fprintf(var,string,a,b,c,d,e,f,g,h,i,j,k)

#define CPRINTF0(a,var,string)            {static int cnt=0; if (++cnt >= a) {fprintf(var,string);cnt=0;}}


#define DECLFILE(a) static FILE *a = NULL
#define APPENDFILE(filep) filep = (FILE *)-1;
#define FOPEN(filep,filen) if (filep==NULL) filep=fopen(filen,"w") ; else if (filep == (FILE *)-1) filep=fopen(filen,"a")
#define FOPENW(filep,filen) if (filep==NULL) filep=fopen(filen,"w") ; else if (filep == (FILE *)-1) filep=fopen(filen,"a")
#define FOPENA(filep,filen) if ((filep==NULL)||(filep== (FILE *)-1)) filep=fopen(filen,"a")
#define FOPENR(filep,filen) if (filep==NULL) filep=fopen(filen,"r")
#define FCLOSE(filep) fflush(filep); fclose(filep); filep = (FILE *)-1
#define FCLOSE2(filep)fclose(filep); filep = (FILE *)-1
#define FFLUSH(filep) fflush(filep)
#define DECLFOPEN(filep,filen) static FILE *filep = NULL; if (filep==NULL) filep=fopen(filen,"w");


#define DECL_VERBOSE int g_verbose=0
#define SET_VERBOSE(lev) g_verbose=lev
#define ADD_VERBOSE(lev) g_verbose=g_verbose|(lev)
#define DDECLFOPEN(dbg,filep,filen) static FILE *filep = NULL; if ((filep==NULL) && ((g_verbose&dbg) != 0)) {filep=fopen(filen,"w");}
#define DFOPEN(dbg,filep,filen)  if ((g_verbose&dbg) != 0) { if (filep==NULL) filep=fopen(filen,"w") ; else if (filep == (FILE *)-1) filep=fopen(filen,"a");}
#define DFCLOSE(dbg,filep)       if ((g_verbose&dbg) != 0) { fflush(filep); fclose(filep); filep = (FILE *)-1; }

#define DPRINTF0(dbg,var,string)                        if (g_verbose&dbg) fprintf(var,string)
#define DPRINTF1(dbg,var,string,a)                      if (g_verbose&dbg) fprintf(var,string,a)
#define DPRINTF2(dbg,var,string,a,b)                    if ((g_verbose&dbg) != 0) fprintf(var,string,a,b)
#define DPRINTF3(dbg,var,string,a,b,c)                  if (g_verbose&dbg) fprintf(var,string,a,b,c)
#define DPRINTF4(dbg,var,string,a,b,c,d)                if (g_verbose&dbg) fprintf(var,string,a,b,c,d)
#define DPRINTF5(dbg,var,string,a,b,c,d,e)              if (g_verbose&dbg) fprintf(var,string,a,b,c,d,e)
#define DPRINTF6(dbg,var,string,a,b,c,d,e,f)            if (g_verbose&dbg) fprintf(var,string,a,b,c,d,e,f)
#define DPRINTF7(dbg,var,string,a,b,c,d,e,f,g)          if (g_verbose&dbg) fprintf(var,string,a,b,c,d,e,f,g)
#define DPRINTF8(dbg,var,string,a,b,c,d,e,f,g,h)        if (g_verbose&dbg) fprintf(var,string,a,b,c,d,e,f,g,h)
#define DPRINTF9(dbg,var,string,a,b,c,d,e,f,g,h,i)      if (g_verbose&dbg) fprintf(var,string,a,b,c,d,e,f,g,h,i)
#define DPRINTF10(dbg,var,string,a,b,c,d,e,f,g,h,i,j)   if (g_verbose&dbg) fprintf(var,string,a,b,c,d,e,f,g,h,i,j)
#define DPRINTF11(dbg,var,string,a,b,c,d,e,f,g,h,i,j,k) if (g_verbose&dbg) fprintf(var,string,a,b,c,d,e,f,g,h,i,j,k)



#endif  // __DO_NOT_WRITE_FILE_REPORTS__

#define PRINTF0(var,string)             FPRINTF0(var,string)
#define PRINTF1(var,string,a)           FPRINTF1(var,string,a)
#define PRINTF2(var,string,a,b)         FPRINTF2(var,string,a,b)
#define PRINTF3(var,string,a,b,c)       FPRINTF3(var,string,a,b,c)
#define PRINTF4(var,string,a,b,c,d)     FPRINTF4(var,string,a,b,c,d)
#define PRINTF5(var,string,a,b,c,d,e)   FPRINTF5(var,string,a,b,c,d,e)
#define PRINTF6(var,string,a,b,c,d,e,f) FPRINTF6(var,string,a,b,c,d,e,f)
#define PRINTF7(var,string,a,b,c,d,e,f,g) FPRINTF7(var,string,a,b,c,d,e,f,g)
#define PRINTF8(var,string,a,b,c,d,e,f,g,h) FPRINTF8(var,string,a,b,c,d,e,f,g,h)
#define PRINTF9(var,string,a,b,c,d,e,f,g,h,i) FPRINTF9(var,string,a,b,c,d,e,f,g,h,i)
#define PRINTF10(var,string,a,b,c,d,e,f,g,h,i,j) FPRINTF10(var,string,a,b,c,d,e,f,g,h,i,j)
#define PRINTF11(var,string,a,b,c,d,e,f,g,h,i,j,k) FPRINTF11(var,string,a,b,c,d,e,f,g,h,i,j,k)


#endif // _helpfunc_h_
