/*------------------------------------------------------------------------------
 *                                                                              
 *                   TTTTTTTT                                                   
 *                   TTTTTTTT  T       TTT      TTT   T    TT     TT      T     
 *                       TT    TT      TT TT   TT T   TT   TT    TT       TT    
 *                       T     TT      TT  TT  TT TT  TT    T   TT        TT    
 *              T        T    TTTT    TTT  TT TT  TT  TTT   TT  T    T   TTTT   
 *      TTTT   TTT       T    TT T    TT   TT TT  TT  TTTT  TT TT TTTT   TT T   
 *    TTTTTT  TTTT       T    T  TT   TT  TT  TT  TT  TT TT TT TT    T   T  TT  
 *      TTTTTTTT         T   TTTTTT   TT TT    T  TT  TT  TTTT  TT   T  TTTTTT  
 *      TTTTTTT          T   TT   TT  TTTT     TT T   TT   TTT  TT   T  TT  TTT 
 *      TTTTTTTT         T   TT   TT  TT TT     TTT   TT    TT   TTT T  TT   TT 
 *  TTTTTTTTTTTTT        T   TT   TTT TT  TT    TT    TT     TT    TTT  TT   TTT
 * TTTTTTTTTTTTTT                                                               
 *     TTTTTTTTTT                                                               
 *     TTTTTTT TT                                                               
 *       TTT   T     TTTTTT                                                     
 *        TT         TTTTTT   TT   T  T  T  T  T    T  TT     T     T  TT     TT
 *        TT            T    T    T   T  T  T  T   T T  T    T T   T    TT   TT 
 *        T             T   TTT  T    T  T  TT T  TT T  T   TT T  T      TT TT  
 *                      T   T    T   TTTTT  TTTT  TT T  T   TT T  T TT     TT   
 *                      T   T    T    TT T  T TTT TT T  T   TT T  T  T     T    
 *                      T   TT    T    T T  T  TT  T T  T    T T  TT T     T    
 *                      T    TTT   T   T T  T   T  TT   TTT  TT    TTT     T    
 *                                                                              
 *                                                                              
 *------------------------------------------------------------------------------
 *
 * Copyright (C) 2022 Taronga Technology Inc. Unpublished work.
 * This computer program includes Confidential, Proprietary Information
 * and is a Trade Secret of Taronga Technology Inc. All use, disclosure, 
 * and/or  reproduction is prohibited unless authorized in writing.  
 * All Rights Reserved.
 *------------------------------------------------------------------------------
 *
 * Baseop: elementary functions such as add, mult sub, etc. 
 * 
 * 
 *------------------------------------------------------------------------------
 */
#ifndef __BASEOP_H__
#define __BASEOP_H__

#include "common.h"


#define TTINLINE static inline
// #define TTINLINE static

#ifdef SKIP_ROUNDING

#define RNDCNST         0 
#define RNDCNST4        0 

#else

//#define RNDCNST 0x0000000080000000
//#define SATURATE32(a) if (a < -2147483648) a = -2147483648; else if (a > 2147483647.0) a = 2147483647.0;
#define RNDCNST         0x0000000080000000LL
#define RNDCNST4        0x0000000010000000LL

#endif



#define SATURATE32(a)   a
#define ALIGN32(a)      ((a)>>32)
#define ALIGN48TO32(a)  ((a)>>16)
#define ALIGNFIX(a)     ((a)<<1)
#define ALIGNFIX4(a)    ((a)<<1)

#define ALIGN28(a)      ((a)>>28)


/**
 * Addition of two values 
 */
TTINLINE int32_t ac_abs(int32_t a)
{
   int32_t r = (a < 0) ? (-a) : a;
   return r;
}


/**
 * Addition of two values 
 */
TTINLINE int32_t ac_add(int32_t a, int32_t b)
{
   int32_t r = a + b;
   return r;
}

/**
 * Addition of two values, saturate if needed
 */
TTINLINE int32_t ac_addsat(int32_t a, int32_t b)
{
   int64_t r = (int64_t)a + (int64_t)b;
   int32_t rr = (int32_t) r;
   if (r > 2147483647) rr = 2147483647;
   else if (r < -2147483648) rr = -2147483648;
   return rr;
}
/**
 * Addition of two values 
 */
TTINLINE int32_t ac_caddsub(BOOL cnd, int32_t a, int32_t b)
{
   int32_t r = (cnd) ? (a - b) : (a+b);
   return r;
}


/**
 * Addition of two values 
 */
TTINLINE BOOL ac_cmplt(int32_t a, int32_t b)
{
   BOOL r = (BOOL)(a < b);
   return r;
}

/**
 * Addition of two values 
 */
TTINLINE BOOL ac_cmpeq(int32_t a, int32_t b)
{
   BOOL r = (BOOL)(a == b);
   return r;
}


/**
 * Round input and bring back to 32 bits. 
 * NO saturation 
 */
TTINLINE int32_t ac_round(int64_t acc)
{
   int64_t r = acc + RNDCNST;
   return (int32_t)ALIGN32(r);
}

/**
 * Round input and bring back to 32 bits. 
 * NO saturation. Input is Q5.59 -> Q1.31
 */
TTINLINE int32_t ac_round4(int64_t acc)
{
   int64_t r = acc + RNDCNST4;
//   printf("acc %16.16llx %8.8x\n",r,(int32_t)ALIGN28(r));
   return (int32_t)ALIGN28(r);
}

/**
 * Fractional multiplication  Q1.31xQ1.31. Result is Q1.63. 
 */
TTINLINE int64_t ac_mult(int32_t a, int32_t b)
{
   int64_t r = a * (int64_t)b;
   r = ALIGNFIX(r);  // r = r << 1;
   return r;
}

/**
 * Fractional multiplication with CT4, treated as integer mult. Result is 64.
 * Q4.28xQ1.31. Result is Q5.59.
 */
TTINLINE int64_t ac_mult4(int32_t a, int32_t b)
{
   int64_t r = a * (int64_t)b;
   return r;
}

/**
 * Fractional multiplication with CT4, treated as integer mult. Result is 64.
 * Q4.28xQ1.31. Result is Q5.59.
 */
TTINLINE int64_t ac_mult4rnd(int32_t a, int32_t b)
{
   int64_t r = a * (int64_t)b;
   return ac_round4(r);
}

/**
 * Integer multiplication 32x32. Result is 64.
 */
TTINLINE int64_t ac_multint(int32_t a, int32_t b)
{
   int64_t r = a * (int64_t)b;
   r = ALIGNFIX(r);  // r = r << 1;
   return r;
}


/**
 * Fractional multiplication Q1.31xQ1.31 with rounding. Result is Q1.63.
 */
TTINLINE int32_t ac_multrnd(int32_t a, int32_t b)
{
   int64_t r = a * (int64_t)b;
   r = ALIGNFIX(r) + RNDCNST;  // r = r << 1;
   return (int32_t)ALIGN32(r);
}


/**
 * Integer multiplication 32x32. Result is 64.
 */
TTINLINE int32_t ac_multintrnd(int32_t a, int32_t b)
{
   int64_t m = ac_multint(a,b);
   int32_t r = ac_round(m);
   return r;
}


/**
 * Integer mult accumulate 32x32 + 64. Result is 64.
 */
TTINLINE int64_t ac_macint(int32_t a, int32_t b, int64_t acc)
{
   int64_t r = acc + a * (int64_t)b;
   return r;
}

/**
 * mult accumulate 32x32 + 64. Result is 64.
 */
TTINLINE int64_t ac_mac4(int32_t a, int32_t b, int64_t acc)
{
   int64_t r = acc + a * (int64_t)b;
   return r;
}

/**
 * Fractional multiply-accumulate Q1.31xQ1.31 + Q1.63. Result is Q1.63.
 * NO saturation 
 */
TTINLINE int64_t ac_mac(int32_t a, int32_t b, int64_t acc)
{
   int64_t r = acc + ac_mult(a,b);
   return r;
}



/**
 * Integer mult accumulate 32x32 + 64. Round result and bring back to 32.
 */
TTINLINE int32_t ac_macintrnd(int32_t a, int32_t b, int64_t acc)
{
   int64_t r = acc + a * (int64_t)b + RNDCNST;
   return (int32_t)ALIGN32(r);
}

/**
 * Fractional mult accumulate Q1.31xQ1.31 + Q1.63. Round and result and bring back
 * to Q1.31.
 * NO saturation
 */
TTINLINE int32_t ac_macrnd(int32_t a, int32_t b, int64_t acc)
{
   int64_t r = acc + ac_mult(a,b) + RNDCNST;
   return (int32_t)ALIGN32(r);
}

/**
 * Integer mult accumulate 32x32 + 64. Result is 64.
 */
TTINLINE int32_t ac_macrnd4(int32_t a, int32_t b, int64_t acc)
{
   int64_t m = ac_mac4(a, b, acc);
   int32_t r = ac_round4(m);
   // printf(" %8.8x %8.8x  acc %16.16llx %16.16llx  %16.16llx %8.8x\n",a,b,acc,m,r,r);
   return r;
}


/**
 *  maximum 
 */
TTINLINE int32_t ac_max(int32_t a, int32_t b)
{
   int32_t r = (a < b) ? b : a;
   return r;
}


/**
 * minimum
 */
TTINLINE int32_t ac_min(int32_t a, int32_t b)
{
   int32_t r = (a < b) ? a : b;
   return r;
}


/**
 * Integer multiplication 32x32. Result is 64.
 */
TTINLINE int32_t ac_mux(BOOL cnd, int32_t a, int32_t b)
{
   int32_t r = (cnd) ? a : b;
   return r;
}

/**
 * Shift up
 */
TTINLINE int32_t ac_shiftup(int32_t a, int shft)
{
   int32_t r = a  <<  shft;
   return r;
}

/**
 * shift up with saturation
 */
TTINLINE int32_t ac_shiftupsat(int32_t a, int shft)
{
   int32_t max = (int32_t)(0x7FFFFFFF) >> shft;
   int32_t min = (int32_t)(0x80000000) >> shft;
   int32_t r   = a;
   if (r < min) r = min;
   if (r > max) r = max;
   r = r  <<  shft;
   return r;
}

/**
 * Subtraction of two values 
 */
TTINLINE int32_t ac_sub(int32_t a, int32_t b)
{
   int32_t r = a - b;
   return r;
}

/**
 * Subtraction of two 64 bits values 
 */
TTINLINE int64_t ac_sub64(int64_t a, int64_t b)
{
   int64_t r = a - b;
   return r;
}

#endif   // __BASEOP_H__


