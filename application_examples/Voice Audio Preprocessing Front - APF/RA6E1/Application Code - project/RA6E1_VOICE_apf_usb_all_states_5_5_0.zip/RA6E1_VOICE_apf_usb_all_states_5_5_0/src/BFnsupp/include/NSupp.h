/*------------------------------------------------------------------------------
 *                                                                              
 *                   TTTTTTTT                                                   
 *                   TTTTTTTT  T       TTT      TTT   T    TT     TT      T     
 *                       TT    TT      TT TT   TT T   TT   TT    TT       TT    
 *                       T     TT      TT  TT  TT TT  TT    T   TT        TT    
 *              T        T    TTTT    TTT  TT TT  TT  TTT   TT  T    T   TTTT   
 *      TTTT   TTT       T    TT T    TT   TT TT  TT  TTTT  TT TT TTTT   TT T   
 *    TTTTTT  TTTT       T    T  TT   TT  TT  TT  TT  TT TT TT TT    T   T  TT  
 *      TTTTTTTT         T   TTTTTT   TT TT    T  TT  TT  TTTT  TT   T  TTTTTT  
 *      TTTTTTT          T   TT   TT  TTTT     TT T   TT   TTT  TT   T  TT  TTT 
 *      TTTTTTTT         T   TT   TT  TT TT     TTT   TT    TT   TTT T  TT   TT 
 *  TTTTTTTTTTTTT        T   TT   TTT TT  TT    TT    TT     TT    TTT  TT   TTT
 * TTTTTTTTTTTTTT                                                               
 *     TTTTTTTTTT                                                               
 *     TTTTTTT TT                                                               
 *       TTT   T     TTTTTT                                                     
 *        TT         TTTTTT   TT   T  T  T  T  T    T  TT     T     T  TT     TT
 *        TT            T    T    T   T  T  T  T   T T  T    T T   T    TT   TT 
 *        T             T   TTT  T    T  T  TT T  TT T  T   TT T  T      TT TT  
 *                      T   T    T   TTTTT  TTTT  TT T  T   TT T  T TT     TT   
 *                      T   T    T    TT T  T TTT TT T  T   TT T  T  T     T    
 *                      T   TT    T    T T  T  TT  T T  T    T T  TT T     T    
 *                      T    TTT   T   T T  T   T  TT   TTT  TT    TTT     T    
 *                                                                              
 *                                                                              
 *------------------------------------------------------------------------------
 *
 * Copyright (C) 2023 Taronga Technology Inc. Unpublished work.
 * This computer program includes Confidential, Proprietary Information
 * and is a Trade Secret of Taronga Technology Inc. All use, disclosure, 
 * and/or  reproduction is prohibited unless authorized in writing.  
 * All Rights Reserved.
 *------------------------------------------------------------------------------
 */
#ifndef _NSUPP_H_
#define _NSUPP_H_

 
#include "common.h"
#include "BaseOp.h"
#include <helpfunc.h>

#include "PLevDet.h"
#include "CalFilter.h"
#include "Delay.h"
#include "NSuppGain.h"


typedef struct NSupp_s
{
   LT        inp;
   LT        out;

   CalFilter_t calH1;
   CalFilter_t calH2;
   CalFilter_t calB2;
   CalFilter_t calH3;
   CalFilter_t calB3;
   
   PLevDet_t   plev0;
   PLevDet_t   plev1;
   PLevDet_t   plev2;
   PLevDet_t   plev3;
   
   Delay_t     bandDelay0;
   Delay_t     bandDelay1;
   Delay_t     bandDelay2;
   Delay_t     bandDelay3;
   
   NSuppGain_t nsGain0;
   NSuppGain_t nsGain1;
   NSuppGain_t nsGain2;
   NSuppGain_t nsGain3;
   
   CT4       bandPostGain0;
   CT4       bandPostGain1;
   CT4       bandPostGain2;
   CT4       bandPostGain3;
   
   int nsGnCnt;
   int bypassNSupp;
   

   /* Parameters */
   CT m_GainAttack;           // Attack time for gain, speed gain goes to 0 dB, when input above thresh
   CT m_GainDecay;            // Release time for gain, speed gain goes to m_NoiseeGain, when input below thresh
   LT m_NoiseGain;            // Maximum attenuation target
   LT m_TargetGainMax;        // Max target gain, should 0x7FFFFFFF
   CT factNoiseThresh;
   LT m_NoiseThreshold;       // Noise Threshold, atten or release
   LT band0Gain;
   LT band1Gain;
   LT band2Gain;
   LT band3Gain;

   
} NSupp_t;

extern void NSuppInit(NSupp_t *p);
extern void NSuppProcess(NSupp_t *p);



#endif

