/*------------------------------------------------------------------------------
 *                                                                              
 *                   TTTTTTTT                                                   
 *                   TTTTTTTT  T       TTT      TTT   T    TT     TT      T     
 *                       TT    TT      TT TT   TT T   TT   TT    TT       TT    
 *                       T     TT      TT  TT  TT TT  TT    T   TT        TT    
 *              T        T    TTTT    TTT  TT TT  TT  TTT   TT  T    T   TTTT   
 *      TTTT   TTT       T    TT T    TT   TT TT  TT  TTTT  TT TT TTTT   TT T   
 *    TTTTTT  TTTT       T    T  TT   TT  TT  TT  TT  TT TT TT TT    T   T  TT  
 *      TTTTTTTT         T   TTTTTT   TT TT    T  TT  TT  TTTT  TT   T  TTTTTT  
 *      TTTTTTT          T   TT   TT  TTTT     TT T   TT   TTT  TT   T  TT  TTT 
 *      TTTTTTTT         T   TT   TT  TT TT     TTT   TT    TT   TTT T  TT   TT 
 *  TTTTTTTTTTTTT        T   TT   TTT TT  TT    TT    TT     TT    TTT  TT   TTT
 * TTTTTTTTTTTTTT                                                               
 *     TTTTTTTTTT                                                               
 *     TTTTTTT TT                                                               
 *       TTT   T     TTTTTT                                                     
 *        TT         TTTTTT   TT   T  T  T  T  T    T  TT     T     T  TT     TT
 *        TT            T    T    T   T  T  T  T   T T  T    T T   T    TT   TT 
 *        T             T   TTT  T    T  T  TT T  TT T  T   TT T  T      TT TT  
 *                      T   T    T   TTTTT  TTTT  TT T  T   TT T  T TT     TT   
 *                      T   T    T    TT T  T TTT TT T  T   TT T  T  T     T    
 *                      T   TT    T    T T  T  TT  T T  T    T T  TT T     T    
 *                      T    TTT   T   T T  T   T  TT   TTT  TT    TTT     T    
 *                                                                              
 *                                                                              
 *------------------------------------------------------------------------------
 *
 * Copyright (C) 2023 Taronga Technology Inc. Unpublished work.
 * This computer program includes Confidential, Proprietary Information
 * and is a Trade Secret of Taronga Technology Inc. All use, disclosure, 
 * and/or  reproduction is prohibited unless authorized in writing.  
 * All Rights Reserved.
 *------------------------------------------------------------------------------
 */
#ifndef _DSP_LOGGER_HXX_
#define _DSP_LOGGER_HXX_

#ifndef LOGGING_DISABLE
  #define LOGGING_DISABLE 1
#endif

/**
 * Helper MACROs for the Logging. 
 * 
 * You should use these macros, as this allows us to turm all debugging completely off
 * 
 */
#if (defined __SYNTHESIS__) || (LOGGING_DISABLE)

#define LOG(a,b) 
#define LOGC(a,c,b) 
#define LOG_COMMIT()
#define LOG_START()
#define LOG_ENABLE(a,b)
#define LOG_FILE(a) (void)a
#define LOG_RESET() 
#define DECL_LOGGER 

#else

/* The rest of this file will only be used if both __SYNTHESIS__ and LOGGING_DISABLE are NOT defined */




#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <string>

class Logger;                                   /* Forward Declaration */
extern Logger g_Logger;

#define LOG(a,b)         {std::ostringstream oss; oss << b; std::string s = oss.str(); g_Logger.logit(a,s);}
#define LOGC(a,c,b)      if (c) {std::ostringstream oss; oss << b; std::string s = oss.str(); g_Logger.logit(a,s);}
#define LOG_COMMIT()     g_Logger.commit();
#define LOG_ENABLE(a,b)  g_Logger.enable(a,b);
#define LOG_START()      g_Logger.start();
#define LOG_FILE(a)      g_Logger.outFile((char *)a);
#define LOG_RESET()      g_Logger.reset();
#define DECL_LOGGER      Logger g_Logger;

#define LOGDBL32(a)      std::setw(10) << std::fixed  << std::setprecision(7)  << TODBL32(a)
#define LOGDBL24(a)      std::setw(10) << std::fixed  << std::setprecision(7)  << TODBL24(a)
#define LOGDBL20(a)      std::setw(10) << std::fixed  << std::setprecision(7)  << TODBL20(a)
#define LOGHEX32(a)      std::setw(8)  << std::hex << fromLT(a)
#define LOGHEX64(a)      std::setw(16) << std::hex << fromLAT(a)
#define LOGHEX(a)        std::setw(8)  << std::hex << TOINT(a)

/**
 * Logging numbers. The order is important, as it defines order of printout
 */
#define LOG_TOP     0
#define LOG_PSAP    1
#define LOG_NSUPP   2
#define LOG_PLEV    3
#define LOG_NGATE   4
#define LOG_CAL     5
#define LOG_DLY     6
#define LOG_BIQ     7
#define LOG_DCB     8
#define LOG_FRAC    9
#define LOG_FIR    10
#define LOG_BF     11
#define LOG_NSG    12
#define LOG_BFNSP  13



#define LOG_NUM_ENTRIES 14

/* log prefix, make sure they match the defines above */
std::string log_prefix[LOG_NUM_ENTRIES] = {
   "Top",
   "PSAPP",
   "NSUPP",
   "PLEV",
   "NGate",
   "CAL",
   "DLY",
   "BIQ",
   "DCB",
   "FRAC",
   "FIR",
   "BF",
   "NSGAIN",
   "BFNSUPP",
};

// using namespace std;

/** 
 * @brief logger: helper class to (optionally) log for debugging 
 * 
 * This logger class creates an ostringstream for each LOG_ component. The components
 * can be turned on/off dynamically, so you can request more/less debugging. 
 * 
 * NOTE: Do not use these functions directly, but use the MACROS defined above
 * In this way, the logging will not interfere with possibly HDL generation.
 * 
 */
class Logger
{
public:
   bool en[LOG_NUM_ENTRIES];
   int  wl[LOG_NUM_ENTRIES];
   bool log_disable;

   /**
    * Constructor
    */
   Logger() 
   { 
      fout = &std::cout;
      cnt = 0;
   };   
   
   /**
    * reset: restart counter from zero
    */
   void reset()
   {
      cnt = 0;
   };

   /** 
    * @brief enable: enable component for debugging output
    * @param comp:  component number, see defines above
    * @param width: width of the component debug "column"
    */    
   void enable(int comp, int width = 10)
   {
      en[comp] = true;
      wl[comp] = width;
      log_disable = false;
   };

   /** 
    * @brief start: start of logging for debugging output
    * This function checks if one of the debug components is enabled. If none is enabled, logging is disabled.
    */    
   void start()
   {
      log_disable = true;
      for (int i=0;i<LOG_NUM_ENTRIES;i++)
      {
         if (en[i]) 
         {
            log_disable = false;
            break;
         }
      }

   };

   /**
    * @brief logit: Log the string for component comp
    * @param comp: component number, see defines above
    * @param s:    string with the debugging info
    */
   void logit(int comp, std::string& s)
   {
      if (en[comp])  // Check if component debugging is enabled..
      {
         //os[comp] 
         os[comp] << " " << s;
      }
   };

   /**
    * @brief outFile: redirect the logging output to a file
    * 
    * @param: fileName: name of the output file
    */
   void outFile(char *fileName)
   {
      of.open(fileName);
      fout = &of;
   };
   
   /**
    * @brief Commit the debugging to either cout of file
    * The intention is to call this funcion "every cycle"
    */
   void commit()
   {
      if (log_disable) return; // No Logging Enabled
      *fout << std::setw(4) << cnt;
      cnt++;
      for (int i=0;i<LOG_NUM_ENTRIES;i++)
      {
         if (!en[i]) continue; // Check if component debugging is enabled..
         std::string pad = "";
         *fout << " " << log_prefix[i] << std::left << std::setw(wl[i]) << os[i].str();
         // os[i].seekp(0);
         os[i].str("");
         os[i].clear();
      }
      *fout << std::endl;  // Add Newline and flush the buffer
   };

   
private:
   std::ostringstream  os[LOG_NUM_ENTRIES];
   std::ostream        *fout;
   std::ofstream       of;
   int                 cnt;

};


#endif 

#endif   // _DSP_LOGGER_HXX_

