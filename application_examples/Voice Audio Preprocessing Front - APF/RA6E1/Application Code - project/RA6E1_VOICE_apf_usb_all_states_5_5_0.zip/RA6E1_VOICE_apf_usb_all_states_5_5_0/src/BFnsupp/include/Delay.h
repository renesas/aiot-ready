/*------------------------------------------------------------------------------
 *                                                                              
 *                   TTTTTTTT                                                   
 *                   TTTTTTTT  T       TTT      TTT   T    TT     TT      T     
 *                       TT    TT      TT TT   TT T   TT   TT    TT       TT    
 *                       T     TT      TT  TT  TT TT  TT    T   TT        TT    
 *              T        T    TTTT    TTT  TT TT  TT  TTT   TT  T    T   TTTT   
 *      TTTT   TTT       T    TT T    TT   TT TT  TT  TTTT  TT TT TTTT   TT T   
 *    TTTTTT  TTTT       T    T  TT   TT  TT  TT  TT  TT TT TT TT    T   T  TT  
 *      TTTTTTTT         T   TTTTTT   TT TT    T  TT  TT  TTTT  TT   T  TTTTTT  
 *      TTTTTTT          T   TT   TT  TTTT     TT T   TT   TTT  TT   T  TT  TTT 
 *      TTTTTTTT         T   TT   TT  TT TT     TTT   TT    TT   TTT T  TT   TT 
 *  TTTTTTTTTTTTT        T   TT   TTT TT  TT    TT    TT     TT    TTT  TT   TTT
 * TTTTTTTTTTTTTT                                                               
 *     TTTTTTTTTT                                                               
 *     TTTTTTT TT                                                               
 *       TTT   T     TTTTTT                                                     
 *        TT         TTTTTT   TT   T  T  T  T  T    T  TT     T     T  TT     TT
 *        TT            T    T    T   T  T  T  T   T T  T    T T   T    TT   TT 
 *        T             T   TTT  T    T  T  TT T  TT T  T   TT T  T      TT TT  
 *                      T   T    T   TTTTT  TTTT  TT T  T   TT T  T TT     TT   
 *                      T   T    T    TT T  T TTT TT T  T   TT T  T  T     T    
 *                      T   TT    T    T T  T  TT  T T  T    T T  TT T     T    
 *                      T    TTT   T   T T  T   T  TT   TTT  TT    TTT     T    
 *                                                                              
 *                                                                              
 *------------------------------------------------------------------------------
 *
 * Copyright (C) 2023 Taronga Technology Inc. Unpublished work.
 * This computer program includes Confidential, Proprietary Information
 * and is a Trade Secret of Taronga Technology Inc. All use, disclosure, 
 * and/or  reproduction is prohibited unless authorized in writing.  
 * All Rights Reserved.
 *------------------------------------------------------------------------------
 */
#ifndef _DELAY_H_
#define _DELAY_H_

#include "common.h"
#include "helpfunc.h"
#include "BaseOp.h"
#include "logger.hxx"


#define DLY_MAX_DLY_LEN  (50)   // to support max 30 mm

typedef struct Delay_s {
   /* IO */
   int32_t   inp;
   int32_t   out;
   /* Parameters */
   int       m_Integer;             // Integer delay value?
   /* States */
   LT        m_DlyBuf[DLY_MAX_DLY_LEN];   // DelayLine with previous values
   
} Delay_t;

extern void DelayInit(Delay_t *p);
extern void DelayProcess(Delay_t *p);

   
#endif  // _DELAY_H_

