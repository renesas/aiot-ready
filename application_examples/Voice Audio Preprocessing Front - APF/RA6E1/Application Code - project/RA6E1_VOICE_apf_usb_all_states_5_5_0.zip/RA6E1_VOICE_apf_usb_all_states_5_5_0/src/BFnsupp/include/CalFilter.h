/*------------------------------------------------------------------------------
 *                                                                              
 *                   TTTTTTTT                                                   
 *                   TTTTTTTT  T       TTT      TTT   T    TT     TT      T     
 *                       TT    TT      TT TT   TT T   TT   TT    TT       TT    
 *                       T     TT      TT  TT  TT TT  TT    T   TT        TT    
 *              T        T    TTTT    TTT  TT TT  TT  TTT   TT  T    T   TTTT   
 *      TTTT   TTT       T    TT T    TT   TT TT  TT  TTTT  TT TT TTTT   TT T   
 *    TTTTTT  TTTT       T    T  TT   TT  TT  TT  TT  TT TT TT TT    T   T  TT  
 *      TTTTTTTT         T   TTTTTT   TT TT    T  TT  TT  TTTT  TT   T  TTTTTT  
 *      TTTTTTT          T   TT   TT  TTTT     TT T   TT   TTT  TT   T  TT  TTT 
 *      TTTTTTTT         T   TT   TT  TT TT     TTT   TT    TT   TTT T  TT   TT 
 *  TTTTTTTTTTTTT        T   TT   TTT TT  TT    TT    TT     TT    TTT  TT   TTT
 * TTTTTTTTTTTTTT                                                               
 *     TTTTTTTTTT                                                               
 *     TTTTTTT TT                                                               
 *       TTT   T     TTTTTT                                                     
 *        TT         TTTTTT   TT   T  T  T  T  T    T  TT     T     T  TT     TT
 *        TT            T    T    T   T  T  T  T   T T  T    T T   T    TT   TT 
 *        T             T   TTT  T    T  T  TT T  TT T  T   TT T  T      TT TT  
 *                      T   T    T   TTTTT  TTTT  TT T  T   TT T  T TT     TT   
 *                      T   T    T    TT T  T TTT TT T  T   TT T  T  T     T    
 *                      T   TT    T    T T  T  TT  T T  T    T T  TT T     T    
 *                      T    TTT   T   T T  T   T  TT   TTT  TT    TTT     T    
 *                                                                              
 *                                                                              
 *------------------------------------------------------------------------------
 *
 * Copyright (C) 2023 Taronga Technology Inc. Unpublished work.
 * This computer program includes Confidential, Proprietary Information
 * and is a Trade Secret of Taronga Technology Inc. All use, disclosure, 
 * and/or  reproduction is prohibited unless authorized in writing.  
 * All Rights Reserved.
 *------------------------------------------------------------------------------
 */
#ifndef _CALFILTER_H_
#define _CALFILTER_H_


#include <common.h>
#include <BaseOp.h>
 
#include <helpfunc.h>
#include "logger.hxx"


#define CAL_MAX_COEF 5

typedef struct CalFilter_s {
   LT inp;
   LT outLo;
   LT outHi;
   
   /* Parameters */
   int n1;
   int n2;
   CT4 inpScale;
   CT4 outScale;
   CT4 outPosScale;
   CT4 outNegScale;
   CT4 branchInpScale;
   
   /* States */
   LT taps1[CAL_MAX_COEF];
   LT taps2[CAL_MAX_COEF];
   
   CT alpha1[CAL_MAX_COEF];
   CT alpha2[CAL_MAX_COEF];
   
} CalFilter_t;

extern void CalFilterInit(CalFilter_t *p);

extern void CalFilterSetCoef(CalFilter_t *p, int l1, double c1[], int l2, double c2[]);
extern void CalFilterSetGains(CalFilter_t *p, double inpGain, double outGain);


extern void CalFilterProcess(CalFilter_t *p);

extern void CalFilterBranchLo(CalFilter_t *p);

extern void CalFilterBranchHi(CalFilter_t *p);


#endif   // _CALFILTER_H_

