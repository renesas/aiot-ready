/***********************************************************************************************************************
 * File Name    : audio_record_entry.h
 * Description  : Contains macros and functions used in audio_record_entry.h
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/

#ifndef AUDIO_RECORD_ENTRY_H_
#define AUDIO_RECORD_ENTRY_H_

#include <stdbool.h>

#define    BYTE_AUDIO_POOL_SIZE    (ULONG)256
#define    I2SRBUF_SAMPLES         (80)
#define    I2SBUFF_SAMPLE_SIZE     (I2SRBUF_SAMPLES * sizeof(short))


/*******************************************************************************************************************
 * @brief     audio record thread entry function .
 **********************************************************************************************************************/
void audio_record_entry(void);

/*******************************************************************************************************************
* @brief     This function used for initialize ring buffer and open I2S/SPI, timer... peripheral devices for recording.
* @param[IN] void
* @retval    Any Other Error code apart from TX_SUCCESS on Unsuccessful operation.
**********************************************************************************************************************/
unsigned int AudioRecordInit(void);

/*******************************************************************************************************************
 * @brief     This function used for release ring buffer and close I2S/SPI, timer... peripheral devices.
 * @param[IN] void
 * @retval    FSP_SUCCESS
 **********************************************************************************************************************/
int AudioRecordRelease(void);

/*******************************************************************************************************************
 * @brief     This function used to start record, the audio system will start to callback audio data.
 *            the audio data will put into ring buffer when get it from callback..
 * @param[IN] void
 * @retval    FSP_SUCCESS
 **********************************************************************************************************************/
int AudioRecordStart(void);

/*******************************************************************************************************************
 * @brief     This function used to stop record, the audio system will stop to callback audio data.
 * @param[IN] void
 * @retval    FSP_SUCCESS
 **********************************************************************************************************************/
int AudioRecordStop(void);

/*******************************************************************************************************************
 * @brief     This function used to check if the audio recording is running.
 * @param[IN] void
 * @retval    true if recording InProgress, false if the recording in off state.
 **********************************************************************************************************************/
bool IsAudioRecordRunning(void);

#endif /* AUDIO_RECORD_ENTRY_H_ */
