/***********************************************************************************************************************
 * File Name    : audio_record_entry.c
 * Description  : Contains macros and functions used in pcdc_audio_record_entry.c
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2020 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/

#include "audio_record_entry.h"
#include "hal_data.h"
#include "common_utils.h"
#include "usbx_paud_ep.h"
#include "BfNSupp.h"

/******************************************************************************
 Private global variables and functions
 ******************************************************************************/
static volatile int g_nUnderRunCount            = 0;
static volatile int g_nUnderRunCount2           = 0;
static volatile bool g_bRecording               = false;
static volatile bool g_bRecording2              = false;
static volatile bool g_record_complete          = false;
static volatile bool g_record_complete2         = false; // DMIC2
static uint8_t dmic_index                       = 0;
static uint8_t dmic2_index                      = 0;     // DMIC2
static int g_i2s_buffer[2][I2SRBUF_SAMPLES];
static int g_i2s_buffer2[2][I2SRBUF_SAMPLES];            // DMIC2
static short g_i2s_audio_buffer[I2SRBUF_SAMPLES];

#define MIC_SCALE (2) // was using 5 in one of the demo sets

volatile int bfnsupp_buf[I2SRBUF_SAMPLES]; // 80 samples

volatile BfNSupp_t bfNSuppData;

static bool bfnsupp_disabled = false; // initial condition
static int bfnsupp_state = 0;

#define RED_LED_OFF (1)
#define RED_LED_ON (0)
#define S1_DEBOUNCE_TIME (60)
static int debounce_ctr=0;
static int init_count=0;

/*memory allocation*/
static audio_msg_t *p_audio_data                       = NULL;
TX_BYTE_POOL byte_audio_pool;
static CHAR byte_audio_memory[BYTE_AUDIO_POOL_SIZE]         = {'\0'};
static CHAR *byte_pool_audio_name                           = "audio_processing_block";

/*******************************************************************************************************************
 * @brief     This function allocate memory for message transfer through queue.
 * @param[IN] pool        pointer to byte memory pool
 * @param[IN] p_buf       pointer to user display data.
 * @param[IN] size        total size
 * @retval    Any Other Error code apart from FSP_SUCCESS on Unsuccessful operation.
 **********************************************************************************************************************/
static UINT memory_allocate_audio(TX_BYTE_POOL *pool, audio_msg_t **p_buf, uint32_t size);

/*******************************************************************************************************************
 * @brief     audio record thread entry function .
 **********************************************************************************************************************/

// higher values => more attenuation
void NsSetmaxGain(BfNSupp_t *p, double val)
{
   if(p->init!=1)return;

   p->nsupp.nsGain0.p_factmaxGain = DBL2CT(val);
   p->nsupp.nsGain1.p_factmaxGain = DBL2CT(val);
   p->nsupp.nsGain2.p_factmaxGain = DBL2CT(val);
   p->nsupp.nsGain3.p_factmaxGain = DBL2CT(val);

}
/// latest version
// lower values => more attenuation
void NsSetNoiseThresh(BfNSupp_t *p, double val)
{
   if(p->init!=1)return;

   p->nsupp.nsGain0.p_factNoiseThresh = DBL2CT(val);
   p->nsupp.nsGain1.p_factNoiseThresh = DBL2CT(val);
   p->nsupp.nsGain2.p_factNoiseThresh = DBL2CT(val);
   p->nsupp.nsGain3.p_factNoiseThresh = DBL2CT(val);
}

void BfSetEndfire(BfNSupp_t *p)
{
    if(p->init!=1)return;
    p->beamForm.bypassBeamForming = 0; // Endfire BF
    p->out = p->beamForm.out;          // bypass NS, output BF
}
void BfSetBroadside(BfNSupp_t *p)
{
    if(p->init!=1)return;
    p->beamForm.bypassBeamForming = 5; // Broadside BF
    p->out = p->beamForm.out;          // bypass NS, output BF
}

void BfProcBlock(BfNSupp_t *p, int32_t *iPtr1, int32_t *iPtr2, int32_t *oPtr, int32_t len)
{
    int i;

    for (i = 0; i< len; i++)
    {
        /* Fetch inputs */
        p->beamForm.frontInp = iPtr1[i];
        p->beamForm.backInp  = iPtr2[i];

        /* Process one sample */
        BeamFormingProcess(&p->beamForm);//BfNSuppProcess(p);

        /* write output */
        oPtr[i] = p->beamForm.out;

    }
}


void audio_record_entry(void)
{
    /* TODO: add your own code here */
    UINT status = FSP_SUCCESS;
    ULONG  actual_f         = RESET_VALUE;

    status = AudioRecordInit();
    if (FSP_SUCCESS != status)
    {
        PRINT_ERR_STR("AudioRecordInit api failed.");
        ERROR_TRAP(status);
    }

    status = memory_allocate_audio(&byte_audio_pool, &p_audio_data, sizeof(audio_msg_t));
    if (TX_SUCCESS != status)
    {
        APP_PRINT("Error in processing, please check again\r\n");
        tx_byte_pool_delete(&byte_audio_pool);
    }

    BfNSuppInit((BfNSupp_t*)&bfNSuppData);
    FracDelaySetDelay((FracDelay_t*)&bfNSuppData.beamForm.fracDelay, 2, 0.3323);
    BfNSuppSetMode((BfNSupp_t*)&bfNSuppData, 5); // DCBlocking+NSUPP w/out BF
    NSuppSetNoiseGainTrgt((BfNSupp_t*)&bfNSuppData, 0.25);

    while (1)
    {
        /*Check for Audio Start or Stop Event*/
        tx_event_flags_get (&usb_data_event, (USB_AUDIO_RECORD_START | USB_AUDIO_RECORD_STOP), TX_OR_CLEAR, &actual_f, TX_NO_WAIT);
        if(USB_AUDIO_RECORD_START == (actual_f & USB_AUDIO_RECORD_START) )
        {
            AudioRecordStart();
        }
        else if(USB_AUDIO_RECORD_STOP == (actual_f & USB_AUDIO_RECORD_STOP)  )
        {
            AudioRecordStop();
        }
        actual_f = RESET_VALUE;

        init_count++;

        if (g_record_complete == true && g_bRecording == true && g_record_complete2 == true && g_bRecording2 == true )
        {
            g_record_complete = false;
            g_record_complete2 = false;

            /* S1, user mode button check */
            bsp_io_level_t level;

            R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_04_PIN_02, &level);

            if(level==0)
            {
               debounce_ctr++;
            }
            if(debounce_ctr==S1_DEBOUNCE_TIME)
            {
               debounce_ctr=0;
               bfnsupp_state++;
            }

            if(bfnsupp_state==0)
            {
                BfNSuppSetMode((BfNSupp_t*)&bfNSuppData, 5); // BF does DC blocking only
                R_IOPORT_PinWrite(&g_ioport_ctrl, LED_R, ON);
                R_IOPORT_PinWrite(&g_ioport_ctrl, LED_B, OFF);
            }
            else if(bfnsupp_state==1)
            {
                BfNSuppSetMode((BfNSupp_t*)&bfNSuppData, 4); // BF enabled, broadside
                R_IOPORT_PinWrite(&g_ioport_ctrl, LED_R, OFF);
                R_IOPORT_PinWrite(&g_ioport_ctrl, LED_B, ON);
            }
            else if(bfnsupp_state==2)
            {
                BfNSuppSetMode((BfNSupp_t*)&bfNSuppData, 3); // BF enabled, end-fire//4); // BF enabled, broadside
                R_IOPORT_PinWrite(&g_ioport_ctrl, LED_R, ON);
                R_IOPORT_PinWrite(&g_ioport_ctrl, LED_B, ON);
            }
			
			// state0: 7a with nsupp
			// state1: 7a with bfnsupp
			if( (bfnsupp_state==0) || (bfnsupp_state==1) || (bfnsupp_state==2))
			{
				NsSetmaxGain((BfNSupp_t*)&bfNSuppData, 0.99);
				NsSetNoiseThresh((BfNSupp_t*)&bfNSuppData, 0.50);
				NSuppSetNoiseGainTrgt((BfNSupp_t*)&bfNSuppData, 0.25);
				bfnsupp_disabled = false;
			}
			else if(bfnsupp_state==3)
			{
				bfnsupp_disabled = true;
	            R_IOPORT_PinWrite(&g_ioport_ctrl, LED_R, OFF);
	            R_IOPORT_PinWrite(&g_ioport_ctrl, LED_G, OFF);
	            R_IOPORT_PinWrite(&g_ioport_ctrl, LED_B, OFF);
			}
			else
			{
				bfnsupp_state = 0; // reset
				bfnsupp_disabled = false;
			}
            
			//R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_13, bfnsupp_state&1);
            
			// fix the sign bit on mic2
            for (int i = 0; i < I2SRBUF_SAMPLES; i++)
            {
               g_i2s_buffer2[dmic2_index ^ 1][i] = (g_i2s_buffer2[dmic2_index ^ 1][i]) ^ (1 << 31);
               g_i2s_buffer[dmic_index ^ 1][i]   = (g_i2s_buffer[dmic_index ^ 1][i])   >> MIC_SCALE;
               g_i2s_buffer2[dmic2_index ^ 1][i] = (g_i2s_buffer2[dmic2_index ^ 1][i]) >> MIC_SCALE;
            }

            int32_t *iPtr1 = (int32_t*)&g_i2s_buffer[dmic_index ^ 1][0];
            int32_t *iPtr2 = (int32_t*)&g_i2s_buffer2[dmic2_index ^ 1][0];
            int32_t *oPtr  = (int32_t*)&bfnsupp_buf[0];

            BfNSuppProcBlock((BfNSupp_t*)&bfNSuppData, iPtr1, iPtr2, oPtr, I2SRBUF_SAMPLES);

            if(bfnsupp_disabled)
            {
               R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_05_PIN_00, RED_LED_OFF);

                // Bfnsupp off, send raw mic to USB
               for (int i = 0; i < I2SRBUF_SAMPLES; i++)
               {
                //g_i2s_audio_buffer[i] = (short)((g_i2s_buffer2[dmic2_index ^1][i] >> 14) & 0xFFFF);  // DMIC_R
                g_i2s_audio_buffer[i] = (short)((g_i2s_buffer[dmic_index ^1][i] >> 14) & 0xFFFF);  // DMIC_L
               }
            }
            else
            {
                R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_05_PIN_00, RED_LED_ON);

                // Bfnsupp on, send NSUPP output to USB

                for (int i = 0; i < I2SRBUF_SAMPLES; i++)
                {
                  g_i2s_audio_buffer[i] = (short)((bfnsupp_buf[i] >> 15) & 0xFFFF);
                }
            }


            /* send data to USB thread */
            p_audio_data->audio_msg_id = AUDIO_EVENT_DATA_SEND;
            p_audio_data->audio_msg_data_size = I2SBUFF_SAMPLE_SIZE;
            memcpy(p_audio_data->audio_p_msg,(uint8_t *)g_i2s_audio_buffer,p_audio_data->audio_msg_data_size);

#if (BSP_CFG_RTOS == 1)
            tx_queue_send(&audio_data_queue,(audio_msg_t *)&p_audio_data , TX_NO_WAIT);
#endif
        }
        tx_thread_sleep (1);
    }
}

/*******************************************************************************************************************
* @brief     This function used for initialize ring buffer and open I2S/SPI, timer... peripheral devices for recording.
* @param[IN] void
* @retval    Any Other Error code apart from TX_SUCCESS on Unsuccessful operation.
**********************************************************************************************************************/
UINT AudioRecordInit(void)
{
    fsp_err_t  err = FSP_SUCCESS;

    /* block allocation will be done and address based message exchange happens */
    err = tx_byte_pool_create(&byte_audio_pool,byte_pool_audio_name,(VOID *)&byte_audio_memory[0],BYTE_AUDIO_POOL_SIZE);
    if (TX_SUCCESS != err)
    {
        return err;
    }
    
    err = R_ELC_Open(&g_elc_ctrl, &g_elc_cfg);
    if (FSP_SUCCESS != err)
    {
        __BKPT(0);
    }

    err = R_ELC_Enable(&g_elc_ctrl);
    if (FSP_SUCCESS != err)
    {
        __BKPT(0);
    }

    /** SW I2S */
    err = R_GPT_Open(&g_timer_sck_ctrl, &g_timer_sck_cfg);
    if(FSP_SUCCESS != err)
    {
        PRINT_ERR_STR("\r\n[Error] R_GPT_Open: SCK\r\n");
        __BKPT(0);
    }

    err = R_GPT_Open(&g_timer_ws_ctrl, &g_timer_ws_cfg);

    /* Set initial counter value to supplement the missing clock of 32 times count-up in first cycle */
    err = R_GPT_CounterSet(&g_timer_ws_ctrl, g_timer_ws_cfg.period_counts - 1);
    if(FSP_SUCCESS != err)
    {
        PRINT_ERR_STR("\r\n[Error] R_GPT_Open: WS\r\n");
        __BKPT(0);
    }

    g_bRecording = false;
    g_bRecording2 = false;

    return err;
}

/*******************************************************************************************************************
 * @brief     This function used for release ring buffer and close I2S/SPI, timer... peripheral devices.
 * @param[IN] void
 * @retval    FSP_SUCCESS
 **********************************************************************************************************************/
int AudioRecordRelease(void)
{
    tx_byte_pool_delete(&byte_audio_pool);
    R_SPI_Close(&g_spi_i2s_ctrl);
    R_SPI_Close(&g_spi1_ctrl);

    R_ELC_Disable(&g_elc_ctrl);
    R_ELC_Close(&g_elc_ctrl);
    R_GPT_Reset(&g_timer_ws_ctrl);
    R_GPT_Stop(&g_timer_ws_ctrl);
    R_GPT_Close(&g_timer_ws_ctrl);
    R_GPT_Stop(&g_timer_sck_ctrl);
    R_GPT_Close(&g_timer_sck_ctrl);
    return FSP_SUCCESS;
}

/*******************************************************************************************************************
 * @brief     This function used to stop record, the audio system will stop to callback audio data.
 * @param[IN] void
 * @retval    FSP_SUCCESS
 **********************************************************************************************************************/
int AudioRecordStop(void)
{
    g_bRecording = false;
    g_bRecording2 = false;

    R_GPT_Reset(&g_timer_ws_ctrl);
    R_GPT_Stop(&g_timer_ws_ctrl);

    R_GPT_Reset(&g_timer_sck_ctrl);
    R_GPT_Stop(&g_timer_sck_ctrl);

    R_SPI_Close(&g_spi_i2s_ctrl);
    R_SPI_Close(&g_spi1_ctrl);

    return FSP_SUCCESS;
}

/*******************************************************************************************************************
 * @brief     This function used to start record, the audio system will start to callback audio data.
 *            the audio data will put into ring buffer when get it from callback..
 * @param[IN] void
 * @retval    FSP_SUCCESS
 **********************************************************************************************************************/
int AudioRecordStart(void)
{
    fsp_err_t  err;

    err = R_GPT_Start(&g_timer_ws_ctrl);
    if(FSP_SUCCESS != err)
    {
        PRINT_ERR_STR("\r\n[Error] R_GPT_Start: WS\r\n");
        __BKPT(0);
    }

     err = R_GPT_Start(&g_timer_sck_ctrl);
    if(FSP_SUCCESS != err)
    {
        PRINT_ERR_STR("\r\n[Error] R_GPT_Start: SCK\r\n");
        __BKPT(0);
    }

    err = R_SPI_Open(&g_spi_i2s_ctrl, &g_spi_i2s_cfg);
    if(FSP_SUCCESS != err)
    {
        PRINT_ERR_STR("\r\n[Error] R_SPI_Open: I2S\r\n");
        __BKPT(0);
    }

    if (g_bRecording == false)
    {
        g_bRecording = true;

        err = R_SPI_Read(&g_spi_i2s_ctrl, g_i2s_buffer[dmic_index], I2SRBUF_SAMPLES, SPI_BIT_WIDTH_32_BITS);
        if (FSP_SUCCESS != err)
        {
            PRINT_ERR_STR("\r\n[Error] R_SPI_Read\r\n");
            g_bRecording = false;
        }
    }

    err = R_SPI_Open(&g_spi1_ctrl, &g_spi1_cfg);
    if(FSP_SUCCESS != err)
    {
        PRINT_ERR_STR("\r\n[Error] R_SPI_Open: DMIC2\r\n");
        __BKPT(0);
    }

    if (g_bRecording2 == false)
    {
        g_bRecording2 = true;

        err = R_SPI_Read(&g_spi1_ctrl, g_i2s_buffer2[dmic2_index], I2SRBUF_SAMPLES, SPI_BIT_WIDTH_32_BITS);
        if (FSP_SUCCESS != err)
        {
            PRINT_ERR_STR("\r\n[Error] R_SPI_Read DMIC2\r\n");
            g_bRecording2 = false;
        }
    }

    return err;
}

/*******************************************************************************************************************
 * @brief     This function used to check if the audio recording is running.
 * @param[IN] void
 * @retval    true if recording InProgress, false if the recording in off state.
 **********************************************************************************************************************/
bool IsAudioRecordRunning(void)
{
   return (g_bRecording && g_bRecording2);
}

/*******************************************************************************************************************//**
 * @brief     This function allocate memory for message transfer through queue.
 * @param[IN] pool        pointer to byte memory pool
 * @param[IN] p_buf       pointer to user display data.
 * @param[IN] size        total size
 * @retval    Any Other Error code apart from TX_SUCCESS on Unsuccessful operation.
 **********************************************************************************************************************/
static UINT memory_allocate_audio(TX_BYTE_POOL *pool, audio_msg_t **p_buf, uint32_t size)
{
#if (BSP_CFG_RTOS == 1)
    UINT err = TX_SUCCESS;

    audio_msg_t *buf = NULL;

    /* block allocate for user input */
    err = tx_byte_allocate(pool, (VOID **)&buf, size, TX_WAIT_FOREVER);
    if (TX_SUCCESS ==err)
    {
        /* assign buffer address */
        *p_buf = buf;
    }
    return err;
#endif
}


/*******************************************************************************************************************
 * @brief     This function SPI_I2S callback which handles the SPI Event transfer complete or UnderRun scenario.
 * @param[IN] p_args        pointer to spi_callback_args_t parameter
 * @retval    void
 **********************************************************************************************************************/
void g_spi_cb(spi_callback_args_t *p_args)
{
    if( NULL != p_args)
    {
        /* capture callback event for validating the i2s transfer event*/
        if (p_args->event == SPI_EVENT_TRANSFER_COMPLETE)
        {
            g_record_complete = true;

            /* Change index of the active write buffer */
            dmic_index ^= 1;
            if (g_bRecording)
                R_SPI_Read(&g_spi_i2s_ctrl, g_i2s_buffer[dmic_index], I2SRBUF_SAMPLES, SPI_BIT_WIDTH_32_BITS);
        }
        else if (p_args->event == SPI_EVENT_ERR_MODE_UNDERRUN)
        {
            if (g_bRecording)
            {
                g_nUnderRunCount++;
                R_SPI_Close(&g_spi_i2s_ctrl);
                R_SPI_Open(&g_spi_i2s_ctrl, &g_spi_i2s_cfg);
                R_SPI_Read(&g_spi_i2s_ctrl, g_i2s_buffer[dmic_index], I2SRBUF_SAMPLES, SPI_BIT_WIDTH_32_BITS);
            }
        }
        else
        {
            __NOP();
        }
    }
    return;
}

void g_spi1_cb(spi_callback_args_t *p_args)
{
    if( NULL != p_args)
    {
        /* capture callback event for validating the i2s transfer event*/
        if (p_args->event == SPI_EVENT_TRANSFER_COMPLETE)
        {
            g_record_complete2 = true;

            /* Change index of the active write buffer */
            dmic2_index ^= 1;
            if (g_bRecording2)
                R_SPI_Read(&g_spi1_ctrl, g_i2s_buffer2[dmic2_index], I2SRBUF_SAMPLES, SPI_BIT_WIDTH_32_BITS);
        }
        else if (p_args->event == SPI_EVENT_ERR_MODE_UNDERRUN)
        {
            if (g_bRecording2)
            {
                g_nUnderRunCount2++;
                R_SPI_Close(&g_spi1_ctrl);
                R_SPI_Open(&g_spi1_ctrl, &g_spi1_cfg);
                R_SPI_Read(&g_spi1_ctrl, g_i2s_buffer2[dmic2_index], I2SRBUF_SAMPLES, SPI_BIT_WIDTH_32_BITS);
            }
        }
        else
        {
            __NOP();
        }
    }
    return;
}
