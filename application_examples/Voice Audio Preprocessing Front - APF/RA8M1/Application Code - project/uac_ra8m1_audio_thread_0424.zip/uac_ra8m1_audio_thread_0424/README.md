# Azure RTOS USBX for UAC on VOICE-RA8M1

## Overview
A Proof-Of-Concept project for USB composite devices including USB audio class and human interface devices on USB full-speed peripheral interface.
    - USB audio class : Stereo 16bit 16Khz PCM with I2S digital microphone.
    
### Hardware
- VUI-RA8M1

### Development Tools and Software
- FSP 5.2.0
- IDE: e2-studio 2024-01 (windows)

