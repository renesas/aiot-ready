/* generated configuration header file - do not edit */
#ifndef BSP_PIN_CFG_H_
#define BSP_PIN_CFG_H_
#include "r_ioport.h"

/* Common macro for FSP header files. There is also a corresponding FSP_FOOTER macro at the end of this file. */
FSP_HEADER

#define LED_RED (BSP_IO_PORT_04_PIN_04)
#define LED_GREEN (BSP_IO_PORT_04_PIN_05)
#define LED_BLUE (BSP_IO_PORT_04_PIN_06)
#define DA7218_EN (BSP_IO_PORT_06_PIN_00) /* DA7218# */

extern const ioport_cfg_t g_bsp_pin_cfg; /* RA8M1 VUI */

void BSP_PinConfigSecurityInit();

/* Common macro for FSP header files. There is also a corresponding FSP_HEADER macro at the top of this file. */
FSP_FOOTER
#endif /* BSP_PIN_CFG_H_ */
