/* generated configuration header file - do not edit */
#ifndef R_SSI_CFG_H_
#define R_SSI_CFG_H_
#ifdef __cplusplus
            extern "C" {
            #endif

#define SSI_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#define SSI_CFG_DTC_ENABLE (1)

#ifdef __cplusplus
            }
            #endif
#endif /* R_SSI_CFG_H_ */
