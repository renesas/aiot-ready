#ifndef __SPEEX_DATA1_H
#define __SPEEX_DATA1_H

extern unsigned int g_uSpeexData1Begin;
extern unsigned int g_uSpeexData1End;

#endif
