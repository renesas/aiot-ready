/*
 * mpu_config.c
 *
 *  Created on: Mar 8, 2023
 *      Author: a5123412
 */
#include "mpu_config.h"

#define CTRL_PV 1

#define CTRL_HN 1

#define ARM_MPU_CTRL(PV, HN) (((PV) << MPU_CTRL_PRIVDEFENA_Pos) | ((HN) << MPU_CTRL_HFNMIENA_Pos))

#define START_ADDRESS_OF_DTC_VECTOR_TABLE_SECTION   (0x22000000UL)
#define END_ADDRESS_OF_DTC_TRANSFER_INFO		    (0x22000197UL)

void mpu_config_dtc_transfer_info_area(void)
{
    ARM_MPU_Disable();

    // Set Region 0 using Attr 0
    ARM_MPU_SetMemAttr(0UL, ARM_MPU_ATTR(       /* Normal memory */
      ARM_MPU_ATTR_MEMORY_(0UL, 1UL, 1UL, 1UL), /* Outer Write-Back transient with read and write allocate */
      ARM_MPU_ATTR_MEMORY_(0UL, 0UL, 1UL, 0UL)  /* Inner Write-Through transient with read and no write allocate */
    ));

    ARM_MPU_SetRegion(0UL,
      ARM_MPU_RBAR(START_ADDRESS_OF_DTC_VECTOR_TABLE_SECTION, ARM_MPU_SH_NON, 0UL, 1UL, 1UL),  /* Non-shareable, read/write, non-privileged, execute-never */
      ARM_MPU_RLAR(END_ADDRESS_OF_DTC_TRANSFER_INFO, 0UL)                  /* 1MB memory block using Attr 0 */
    );

	ARM_MPU_Enable(ARM_MPU_CTRL(CTRL_PV, CTRL_HN));
}




