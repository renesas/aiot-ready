/*
 *-----------------------------------------------------------------------------
 * Copyright� 2025 Renesas Electronics Corporation and/or its affiliates.  
 * All rights reserved. Confidential Information.
 *
 * This software ("Software") is supplied by Renesas Electronics Corporation and/or its
 * affiliates ("Renesas"). Renesas grants you a personal, non-exclusive, non-transferable,
 * revocable, non-sub-licensable right and license to use the Software, solely if used in
 * or together with Renesas products. You may make copies of this Software, provided this
 * copyright notice and disclaimer ("Notice") is included in all such copies. Renesas
 * reserves the right to change or discontinue the Software at any time without notice.
 *
 * THE SOFTWARE IS PROVIDED "AS IS". RENESAS DISCLAIMS ALL WARRANTIES OF ANY KIND,
 * WHETHER EXPRESS, IMPLIED, OR STATUTORY, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. TO THE
 * MAXIMUM EXTENT PERMITTED UNDER LAW, IN NO EVENT SHALL RENESAS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE, EVEN IF RENESAS HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGES. USE OF THIS SOFTWARE MAY BE SUBJECT TO TERMS AND CONDITIONS CONTAINED IN
 * AN ADDITIONAL AGREEMENT BETWEEN YOU AND RENESAS. IN CASE OF CONFLICT BETWEEN THE TERMS
 * OF THIS NOTICE AND ANY SUCH ADDITIONAL LICENSE AGREEMENT, THE TERMS OF THE AGREEMENT
 * SHALL TAKE PRECEDENCE. BY CONTINUING TO USE THIS SOFTWARE, YOU AGREE TO THE TERMS OF
 * THIS NOTICE. IF YOU DO NOT AGREE TO THESE TERMS, YOU ARE NOT PERMITTED TO USE THIS
 * SOFTWARE.
 *
 *-----------------------------------------------------------------------------
 */

#include "stdio.h"
#include "nsupp.h"
#include <math.h>
#include <string.h>

/* 
** audio params
*/
#define NSUPP_INIT      (-250)    /* use negative value to force aggressive startup behavior, -N frames */ 
#define NSUPP_MINTIME   (1.0f)    /* noisefloor stats update interval sec */ 
#define NSUPP_NESTGAIN  (3.0f)    /* gain applied on the noiseest before it is used */
#define NSUPP_NOISEEST1 (20.0f)   /* attack time constant for noise estimation typ 20.0 sec, ctrl update speed of noiseest during active speech */            
#define NSUPP_NOISEEST2 (0.5f)    /* release time constant for noise estimation typ 0.5  sec, ctrl update speed of noiseest during pauses */       
#define NSUPP_ATTLIMIT  (-24)     /* attenuation, dB */                

/*
** size params
*/
#define NSUPP_SAMPLERATE (16000)
#define NSUPP_FRAMESIZE  (64)
#define NSUPP_WINSIZE    (128)
#define NSUPP_FFTSIZE    (128)
#define NSUPP_MAXPART    (16)


/*
** derived from above
*/
#define NSUPP_SPCSIZE    (NSUPP_FFTSIZE/2 + 1)
#define NSUPP_BAND_SIZE  (6*NSUPP_MAXPART)     
#define NSUPP_IBUF_SIZE  (2*NSUPP_FRAMESIZE)
#define NSUPP_OBUF_SIZE  (2*NSUPP_FRAMESIZE)

/* critical bands */ 
#define FIRSTBAND (220)
#define MINPARTBINS (2)
#define PWIDTH   (2.0f)

/* limits */ 
#define MINFIX (1e-20) 
#define MAXFIX (1e20f)

/*
** Buffers
*/
static int   fftscr[NSUPP_FFTSIZE];
static float fftwin[NSUPP_FFTSIZE];  
static float fftcos[2*NSUPP_FFTSIZE]; 
static float fftbuf[2*NSUPP_SPCSIZE];  
static float spec_buffer[2*NSUPP_SPCSIZE];
static float ypow_buffer[NSUPP_MAXPART];
static float band_buffer[NSUPP_BAND_SIZE];
float nsupp_ibuf[NSUPP_IBUF_SIZE];
float nsupp_obuf[NSUPP_OBUF_SIZE];

/*
** math support
*/

float const PI     = 3.14159265358979323846f;
float const TWOPI  = 6.28318530717958623200f;
float const PIDIV2 = 1.57079632679489655800f;
float const PIDIV4 = 0.78539816339744827900f;
float const INVPI  = 0.31830988618379069122f;

#define SIN(A) sin((A))
#define COS(A) cos((A))
#define ATAN(A) atan((A))
#define POW(A,B) pow((A),(B))
#define SQRT(A) sqrt((A))
#define LOG10(A) log10((A))

#define MIN(a,b) (((a) < (b)) ? (a) : (b))
#define MAX(a,b) (((a) > (b)) ? (a) : (b))

static inline int ROUND_NEAR(float x)
{
  return x >= 0.0f ? (int)(x + 0.5f) : (int)(x - 0.5f);
}

static inline void MOVE_32F(const float* pSrc, float* pDst, int len)
{
  memmove(pDst, pSrc, len * sizeof(float));
}

int brvr(int, int);

void init_fft(
  int   size,   /* Transform size. MUST be radix-2 */
  float w[][2], /* Complex FFT constants of size nsiz */
  int   br[]    /* Bit reversal index array of size nsiz */
)
{
  register int k;
  float p,pk;

  p = (float)(8.*ATAN(1.)/size);

  for(pk=0., k=0; k < size; k++, pk += p) {
    w[k][0]  = (float)(  COS(pk) );
    w[k][1]  = (float)( -SIN(pk) );
    }

  for(k=0; k < size; k++) br[k] = brvr(k,size);
}

int brvr(int n, int ndim)
{
  int j,m,k;

  m=0;
  j=1;
  for(k = ndim >> 1; k > 0; j<<=1,k>>=1) if(j & n) m = m | k;
  return(m);
}

void rff2(
  const float x[],        /* Real input data of size nsiz */
  float       y[][2],     /* Complex output data (FFT of x) of size nsiz/2 + 1 */
  int         nsiz,       /* Transform size */
  const float cosin[][2],
  const int   bitrev[]
)
{
  register int k,kw,kww,n2,n4,n42;
  float pn;
  float t0,t1,u0,u1,w0,w1;
  int nsizh;

  nsizh = nsiz>>1;

  /* Make the full-size real input an half-size complex
  *****************************************************/
  for(k=0,kw=0; kw < nsiz; k++, kw += 2) {
    n2 = bitrev[k];
    y[k][0] = x[n2];
    y[k][1] = x[n2+1];
    }

  /* Half-size complex FTT
  ************************
  ************************/

  /* 1st stage nsizh/2 simple butterflies
  *************************************/
  for(n2 = 0, n4=1; n4 < nsizh; n2 += 2, n4 += 2) {
    t0 = y[n2][0]; t1 = y[n2][1];
    u0 = y[n4][0]; u1 = y[n4][1];
    y[n2][0] = t0 + u0;
    y[n2][1] = t1 + u1;
    y[n4][0] = t0 - u0;
    y[n4][1] = t1 - u1;
    }

  /* Next stages
  **************/
  for(n2 = 2, kw = nsizh>>1; n2 < nsizh; n2 <<= 1, kw >>= 1) {
    for(n4 = 0; n4 < nsizh; n4 += n2<<1) {

      /* for k = n4 */
      t0 = y[n4][0]; t1 = y[n4][1];
      n42 = n4+n2;
      u0 = y[n42][0]; u1 = y[n42][1];
      y[n4][0] = t0 + u0;
      y[n4][1] = t1 + u1;
      y[n42][0] = t0 - u0;
      y[n42][1] = t1 - u1;

      /* for k > n4 */
      for(k = n4+1, kww = kw; k < n4+n2; k++, kww += kw) {
        n42 = k + n2;
        u0 = y[n42][0]; u1 = y[n42][1];
        w0 = cosin[kww][0]; w1 = cosin[kww][1];
        t0 = u0;
        u0 = w0*u0 - w1*u1;
        u1 = w0*u1 + w1*t0;
        t0 = y[k][0]; t1 = y[k][1];
        y[k][0] = t0 + u0;
        y[k][1] = t1 + u1;
        y[n42][0] = t0 - u0;
        y[n42][1] = t1 - u1;
      }
    }
}

  /* Convert the y[][] to the final spectrum
  *******************************************
  *******************************************/

  /* For 0 , nsizh/2 , nsizh terms :
  *********************************/
  t0 = y[0][0]; t1 = y[0][1];
  y[0][0] = t0 + t1;
  y[0][1] = 0.;
  y[nsizh][0] = t0 - t1;
  y[nsizh][1] = 0.;
  n4 = nsizh>>1;
  y[n4][1] = -y[n4][1];

  /*Other terms
  *************/
  for(k=1,kw=nsizh-1; k < n4; k++, kw--) {
    w0 = y[k][0]; w1 = y[kw][0];
    t0 = w0 + w1;
    u0 = w1 - w0;
    w0 = y[k][1]; w1 = y[kw][1];
    t1 = w0 - w1;
    u1 = w0 + w1;
    w0 = cosin[k][0]; w1 = cosin[k][1];
    pn = u0;
    u0 = w0*u1 - w1*u0;
    u1 = w0*pn + w1*u1;

    y[k][0] = 0.5f * (t0 + u0);
    y[k][1] = 0.5f * (t1 + u1);

    y[kw][0] = 0.5f * (t0 - u0);
    y[kw][1] = 0.5f * (u1 - t1);
  }
}

void irff2(
  const float x[][2],     /* Complex input data of size nsiz/2 + 1 */
  float       y[],        /* Real output data (IFFT of x) of size nsiz */
  int         nsiz,       /* Transform size */
  const float cosin[][2],
  const int   bitrev[]
)
{
  register int k,kw,kww,n2,n4,n42;
  float pn;
  float t0,t1,u0,u1,w0,w1;
  static float s;
  int nsizh;

  nsizh = nsiz>>1;
  s = 1.0f/(float)nsiz;

  /*Convert input FFT to a spectrum of a half-size complex decimated
    time sequence
    ****************************************************************
    ****************************************************************/

  /*DC and nsiz/4 terms (and bit reversal)
  ****************************************/
  t0 = x[0][0]; t1 = x[nsizh][0];
  y[0] = t0 + t1; y[1] = t0 - t1;
  n4 = nsizh>>1;
  n2 = bitrev[n4];
  y[n2] = 2.0f*x[n4][0];
  y[n2+1] = -2.0f*x[n4][1];

  /* Other terms (and bit reversal)
  ********************************/
  for(k=1, kw=nsizh-1; k < n4; k++, kw--) {
    w0 = x[kw][0]; w1 = x[k][0];
    t0 = w0 + w1; u0 = w1 - w0;
    w0 = x[kw][1]; w1 = x[k][1];
    t1 = w1 - w0; u1 = w1 + w0;
    w0 = cosin[k][0]; w1 = -cosin[k][1];
    pn = u0;
    u0 = w1*pn + w0*u1;
    u1 = w0*pn - w1*u1;
    n2 = bitrev[k];
    kww = bitrev[kw];
    y[n2] = t0 - u0;
    y[n2+1] = t1 + u1;
    y[kww] = t0 + u0;
    y[kww+1] = u1 - t1;
    }

  /* Half-size inverse FFT
  ************************
  ************************/

  /* Do nsizh/2 simple butterflies
  *******************************/
  for(k = 0; k < nsiz; k+=2) {
    t0 = y[k]; u0 = y[k+2];
    t1 = y[k+1]; u1 = y[k+3];
    y[k] = t0 + u0;
    y[k+1] = t1 + u1;
    k+=2;
    y[k] = t0 - u0;
    y[k+1] = t1 - u1;
    }

  /* Next stages
  **************/
  for(n2 = 4, kw = nsizh>>1; n2 < nsiz; n2 <<= 1, kw >>= 1) {

    for(n4 = 0; n4 < nsiz; n4 += n2<<1) {

      /* for k = n4 */
      t0 = y[n4]; t1 = y[n4+1];
      n42 = n4+n2;
      u0 = y[n42]; u1 = y[n42+1];
      y[n4] = t0 + u0;
      y[n4+1] = t1 + u1;
      y[n42] = t0 - u0;
      y[n42+1] = t1 - u1;

      /* for k > n4 */
      for(k = n4+2, kww = kw; k < n4+n2; k+=2, kww += kw) {
        n42 = k + n2;
        u0 = y[n42]; u1 = y[n42+1];
        w0 = cosin[kww][0]; w1 = -cosin[kww][1];
        t0 = u0;
        u0 = w0*u0 - w1*u1;
        u1 = w0*u1 + w1*t0;
        t0 = y[k]; t1 = y[k+1];
        y[k] = t0 + u0;
        y[k+1] = t1 + u1;
        y[n42] = t0 - u0;
        y[n42+1] = t1 - u1;
        }
       }
     }

  /*Scale it
  **********/
  for(k=0; k < nsiz; k++) y[k] *= s;
}

void nsupp_fft(
       float*   input,     
       float*   spec, 
       float*   buf,       
       int      fftsize,
       int      framesize,                        
       int      winsize
)
{
   int j = 0;

   for (int i = 0 ; i < winsize; i++)
   {
      buf[j] = fftwin[i]*input[i];
      j++;
   }

   // this has no effect when i=j=128=fftsize
   for ( ; j < fftsize; j++)
     buf[j] = 0.0f;

   rff2(buf,(float(*)[2])spec,fftsize,(float(*)[2])fftcos,fftscr);
}

void nsupp_ifft(
       float*   spec,
       float*   output,   
       float*   buf,      
       int      fftsize,
       int      framesize,
       int      winsize
)
{
   int j;
  
   irff2((float(*)[2])spec,buf,fftsize,(float(*)[2])fftcos,fftscr);
    
   /* overlap add */
   
   for (j = 0; j < winsize-framesize; j++)
      output[j] += fftwin[j]*buf[j];
      
   /* non-overlapping part */
    
   for (; j < winsize; j++)
      output[j] = fftwin[j]*buf[j];
}

int nsupp_makebands(
       int    sfreq,    /* in:  sampling frequency */
       int    fftsize,  /* in:  FFT size */
       float  cbwidth,  /* in:  partition width [ERB] */
       int*   npart,    /* out: number of partitions */
       int*   part,     /* out: partition boundaries */
       int    firstpart,/* bandwidth of first partition [Hz] */
       int    minpart   /* minimum partition width in lines */
)
{
  int   n, prevn, p, lastpartsize, freqboundn;
  int   specsize, pwidth_prev;
  float nerb, erbfirstpart, freqbound;

  specsize    = fftsize/2 + 1;
  pwidth_prev = 0;

  /* init boundaries for critical bands (cbwidth ERB bandwidth) */
  
  erbfirstpart = 21.4f * LOG10(.00437f * firstpart + 1.0f);
  if (erbfirstpart < cbwidth)
    erbfirstpart = cbwidth;

  nerb         = erbfirstpart;
  p            = 0;
  n            = 0;
  prevn        = 0;
  lastpartsize = 0;
  while (n < specsize) {
    freqbound = (POW(10.0f, nerb / 21.4f) - 1.0f) / 0.00437f;
    n++;
    while ( (freqbound > (float)(n * sfreq) / (float)fftsize) ||
            (n-prevn < minpart) ||
            (n-prevn < lastpartsize) )
      n++;

    lastpartsize = n - prevn;
    if (p == 0) {
      freqbound = (POW(10.0f, cbwidth / 21.4f) - 1.0f) / 0.00437f;
      freqboundn = ROUND_NEAR(freqbound/sfreq*fftsize);
      lastpartsize = freqboundn - prevn;
    }
    prevn = n;
    part[p] = MIN(n, specsize);
    p++;
    nerb += cbwidth;

  }
  *npart = p;

  return 0;
}

void nsupp_scalebands(t_NSUPPdata *pNSUPPdata)
{
   t_nsuppband *pband;
   pband = (t_nsuppband *)(pNSUPPdata->band_ptr);
   
   int npart = pNSUPPdata->npart;


   float *spec = pNSUPPdata->spec_ptr;

   int i = 0;
   for (int j=0;j<npart;j++)
   {
      int stop = pband[j].part;
      float gain = pband[j].noisegainfilter;

      for (;i<stop;i++)
      {
         spec[2*i] = spec[2*i]*gain;
         spec[2*i+1] = spec[2*i+1]*gain;
      }
   }
}

void nsupp_bandcombinepow(t_NSUPPdata *pNSUPPdata)
{
   int   i, p;
   float a, b, sum;
   
   /* compute the power in each partition */

   i = 0;
   int npart = pNSUPPdata->npart;
   t_nsuppband *pband;
   pband = (t_nsuppband *)(pNSUPPdata->band_ptr);

   float* spec = pNSUPPdata->spec_ptr;  
   float* pow  = pNSUPPdata->ypow_ptr;
         
   for (p = 0; p < npart; p++)
   {
      sum = 0;
      
      int part = pband[p].part;
      
      //psize = part[p] - i; /* size of the partition */
      
      for( ; i < part; i++)
      {
         /* sum power of all bins in partition */
    
         a  = spec[2*i];
         b  = spec[2*i+1];
 
         sum += a*a + b*b;
      }
      
      /*pow[p] = sum/psize;*/  // ToDo: try this
      pow[p] = sum;
   }
}

void nsupp_init(t_NSUPPdata *pNSUPPdata)  
{
   int   j, nfade;
   float a, q;
   
   int npart;
   int parts[NSUPP_MAXPART];
      
   memset(&fftscr,0,sizeof(fftscr));
   memset(&fftwin,0,sizeof(fftwin));
   memset(&fftcos,0,sizeof(fftcos));
   memset(&fftbuf,0,sizeof(fftbuf));
   
   memset(spec_buffer,0,sizeof(spec_buffer));
   memset(ypow_buffer,0,sizeof(ypow_buffer));   
   memset(band_buffer,0,sizeof(band_buffer));   
   memset(parts,0,sizeof(parts)); // local 
   
   int framesize  = NSUPP_FRAMESIZE;
   int winsize    = NSUPP_WINSIZE;
   int fftsize    = NSUPP_FFTSIZE;
   int samplerate = NSUPP_SAMPLERATE;
   
   nsupp_makebands(samplerate, fftsize, PWIDTH, &npart, parts, FIRSTBAND, MINPARTBINS);

   a = 2.0f*framesize/winsize;
  
   nfade = winsize - framesize;
  
   q = PI / 2.0f / (float)nfade;
  
   for (j = 0; j < nfade; j++)
   {
      fftwin[j] = SIN(q*(j + 0.5f));
      fftwin[winsize-j-1] = SIN(q*(j + 0.5f));
   }
  
   for (j = nfade; j < winsize-nfade; j++)
   {
      fftwin[j] = 1.f;
   }  
  
   init_fft(128, (float(*)[2])fftcos, fftscr); 
   
   
   pNSUPPdata->spec_ptr = spec_buffer;
   pNSUPPdata->band_ptr = band_buffer;                       
   pNSUPPdata->ypow_ptr = ypow_buffer;                        
   
   pNSUPPdata->npart    = npart;      // calculated by nsupp_makebands
   
   // ToDo: not used anymore, fast tc at startup to avoid ~1 sec convergence time
   pNSUPPdata->init     = NSUPP_INIT;                           
   pNSUPPdata->mincount = 0;                       
   pNSUPPdata->minframe = NSUPP_MINTIME*samplerate/framesize;                       
   pNSUPPdata->noiseestgain = (float) POW(10.f, NSUPP_NESTGAIN/10.f);
   pNSUPPdata->noiseest1 = framesize/(float)(NSUPP_NOISEEST1*samplerate);                   
   pNSUPPdata->noiseest2 = framesize/(float)(NSUPP_NOISEEST2*samplerate);
   pNSUPPdata->noiseattlimit = (float) POW(10.f, NSUPP_ATTLIMIT/20.f);                 

   t_nsuppband *pband = (t_nsuppband *)(band_buffer);

   for(int i=0;i<pNSUPPdata->npart;i++)
   {
      pband->part = parts[i]; 
      pband->noisegainfilter = MINFIX;
      pband->nsstate         = MINFIX;
      pband->noisefloor      = MINFIX;
      pband->noisemin        = MAXFIX; 
      pband->noiseest        = MINFIX;
      pband++;
   }

#ifdef VERBOSE   
   printf("makbands: npart = %d\n", npart);
   for(int i=0;i<NSUPP_MAXPART;i++)
   {
      printf("part[%3d] = %6d\n", i, parts[i]);
   }  
#endif
   
}

void nsupp_process(t_NSUPPdata *pNSUPPdata)
{
   int     i, j;
   float   a, b, c;
   float   nsgain, nssmooth, ratio;
   float   mse1, mse2; 
   
   int npart = pNSUPPdata->npart;
  
   for (j = 0; j < pNSUPPdata->npart; j++){
      pNSUPPdata->ypow_ptr[j] = MINFIX;
   }
   
   nsupp_fft(nsupp_ibuf,pNSUPPdata->spec_ptr,fftbuf,128,64,128);  // ToDo: these should be params
        
   nsupp_bandcombinepow(pNSUPPdata);
  
   /* convert from power to magnitude 
   *************************************/
    
   for (i = 0; i < npart; i++){
      pNSUPPdata->ypow_ptr[i] = SQRT(pNSUPPdata->ypow_ptr[i]);
   }

   /* noise suppression processing
   ******************************/
  
   /* noise estimation */
   
   t_nsuppband *pband = (t_nsuppband *)(pNSUPPdata->band_ptr);
   
   float noiseest1sm = pNSUPPdata->noiseest1;
   float noiseest2sm = pNSUPPdata->noiseest2;
   
   for (j = 0; j < npart; j++) {

      a = pNSUPPdata->ypow_ptr[j]; // ypwr

      b = pband->noiseest;         // nest
    
      /* compute minimum statistic buffer */

      pband->noisemin = MIN(pband->noisemin, a);
      
      if(pNSUPPdata->mincount == 0)
         pband->noisefloor = pband->noisemin;

      if(b < 1e0f*pband->noisefloor)
         b = 1e0f*pband->noisefloor;
      if(a > 1e2f*pband->noisefloor)
         a = 1e2f*pband->noisefloor;
    
  
      /* two sided smoothing for noise power estimation */
      if (a > 2.f*b)
      { 
         pband->noiseest = b*(1-noiseest1sm) + a*noiseest1sm;
      }
      else
      {
         pband->noiseest = b*(1-noiseest2sm) + a*noiseest2sm;
      }
      
      pband++;
   }

   pband = (t_nsuppband *)(pNSUPPdata->band_ptr);
    
   for (j = 0; j < npart; j++)
   {
      a = pNSUPPdata->ypow_ptr[j];

      b = pband->noiseest;
      
      /* compute SNR */

      c = pband->noisegainfilter;
      ratio = b/(c*a + MINFIX);
      
      mse1 = c*ratio;
      mse2 = ratio;

      /* compute beta parameter */
      c = MIN(1.f, 0.1f*mse1 + 0.9f*mse2);
      nsgain = pNSUPPdata->noiseestgain - ( pNSUPPdata->noiseestgain - 1.f ) * ( 1.f - c );

      /* compute smoothing parameter */
      
      c = MIN(1.f, 0.75f*mse1 + 0.25f*mse2);
      nssmooth = ( 1.f - c )*( 1.f - c );

      /* compute gain filter */
      
      b = nsgain*b;
      if(b > a)
        b = a;
      a = (a - b + 1e-20f)/(a+MINFIX);  
      
      /* time smoothing */ 
         
      c = nssmooth*a + (1.f - nssmooth)*pband->nsstate;
      
      pband->nsstate = a;
        
      if (c < pNSUPPdata->noiseattlimit) c = pNSUPPdata->noiseattlimit;
      if (c > 1.f) c = 1.f;
        
      pband->noisegainfilter = c;   

      pband++;      
   }
   
   /* apply gain filter to microphone spectrum */

   nsupp_scalebands(pNSUPPdata);   

   nsupp_ifft(pNSUPPdata->spec_ptr, nsupp_obuf, fftbuf, 128,64,128);


   /* increase minimum statistic buffer and reset minimum buffer */

   pNSUPPdata->mincount++;
   if(pNSUPPdata->mincount == pNSUPPdata->minframe)pNSUPPdata->mincount = 0;
   

   if(pNSUPPdata->mincount == 1)
   {
      t_nsuppband* pband = (t_nsuppband *)(pNSUPPdata->band_ptr);
      for (j = 0; j < npart; j++)
      {
         pband->noisemin = MAXFIX;
         pband++;
      }
   }

} //end-nsupp

