/***********************************************************************************************************************
 ***********************************************************************************************************************/
#include "da7218.h"
#include "DbgTrace.h"
#include "UartMgr.h"

static volatile i2c_master_event_t i2c_event = I2C_MASTER_EVENT_ABORTED;
static fsp_err_t get_da7218_id(uint8_t *dev_id);
static fsp_err_t validate_i2c_event(void);
static fsp_err_t write_da7218_data(uint8_t reg, uint8_t dat);

unsigned char lr_channel_hp[] = {
    0x09, 0x80,	//RESET
    0x00, 0x01, //Enable ACTIVE mode
    0x01, 0x01, //Enable repeat mode register access (register address and data is sent for each write)
    0xDC, 0x08, //Enable Master BIAS and VMID (VMID and Bandgap enabled on BIAS_EN)
    0x98, 0x80,
    0x91, 0x82, //PLL SRM mode, PLL INDIV= 10-20MHz
    0x92, 0x07,
    0x93, 0xEA,
    0x94, 0x1E,
    0xE0, 0x01, //IO Level 1.5-2.5V
    0xE1, 0x80, //Digital LDO Enabled, 1.05V
    0x0B, 0x55, //16kHz sample rate for ADC and DAC
    0x8C, 0xC0, //DAI Enabled, DAI Channel 1L,1R, 2L, 2R enabled, 16bit, I2S
    0x90, 0x00, //Slave Mode Mode DAI, 64xFS BCLK
    0x8E, 0x00, //No Offset on DAI (lower)
    0x8F, 0x00, //No Offset on DAI (upper)
    0xF0, 0xC0, //DMIC1 Enabled
    0xF1, 0xC0, //DMIC2 Enabled
    0xFC, 0x66, 
    0xFD, 0x11, //MICBIAS 1 Enabled
    0x18, 0xA0, //INFILT_1_L Enabled
    0x19, 0xA0, //INFILT_1_R Enabled
    0x1A, 0xA0, //INFILT_2_L Enabled
    0x1B, 0xA0, //INFILT_2_R Enabled
    0x5C, 0x01, //INFILT_1_L & to DAI_1_L
    0x64, 0x02, //INFILT_1_R & to DAI_1_R
    0xAC, 0xF0, //CP Enabled, Signal Magnitude tracking mode
    0xAD, 0x35, //CP Delay 64ms
    0xAE, 0x36, //CP Volume threshold = 0x36
    0x6C, 0x20, //OUTFILT_1L_SOURCE = DAI_1_L
    0x73, 0x1C, //DAI INPUT L GAIN = 0dB
    0xF8, 0x6F, //OUT_1L_DIGITAL_GAIN GAIN = 0dB
    0xCC, 0x01, //MIXOUT_L Enable
    0xCD, 0x03, //MIXOUT_L GAIN = 0dB
    0x20, 0x80, //Enable OUT_1L_FILTER
    0x74, 0x40, //OUTFILT_1R_SOURCE = DAI_1_R
    0x7B, 0x1C, //DAI INPUT L GAIN = 0dB
    0xF9, 0x6F, //OUT_1R_DIGITAL_GAIN GAIN = 0dB
    0xCE, 0x01, //MIXOUT_R Enable
    0xCF, 0x03, //MIXOUT_R GAIN = 0dB
    0x21, 0x80, //Enable OUT_1R_FILTER
    0xCC, 0x80, //MIXOUT_L Enable
    0xD0, 0xE8, //HP_L Enable, Muted, Ramped
    0x5A, 0x00, //DGS SIGNAL and ANTICLIP level to 0dB
    0x54, 0x27, //Enable DGS
    0xCE, 0x80, //MIXOUT_R Enable
    0xD2, 0xE8, //HP_R Enable, Muted, Ramped
    0x5A, 0x00, //DGS SIGNAL and ANTICLIP level to 0dB
    0x54, 0x27, //Enable DGS
    0xFE, 0xFE, //use mcu DELAY 50
    0xD0, 0xA8, //HP_L Enable, Un-muted, Ramped
    0xD2, 0xA8, //HP_R Enable, Un-muted, Ramped
    0xB4, 0x80,
    0xFF, 0xFF, //END
};

fsp_err_t init_da7218(void)
{
    uint8_t device_id, index, i;
    int table_len = sizeof(lr_channel_hp)/sizeof(short);
    fsp_err_t err = FSP_SUCCESS;

    err = R_IIC_MASTER_Open(&g_i2c_da7218_ctrl, &g_i2c_da7218_cfg);
    if (FSP_SUCCESS != err) {
        DBG_UART_TRACE("** R_IIC_MASTER_Open API failed ** \r\n");
        return err;
    }

    err = get_da7218_id(&device_id);
    if (FSP_SUCCESS == err)
        DBG_UART_TRACE("DA7218 Device ID 0x%x\r\n", device_id);
#if defined(ENABLE_DA7218_DBG)
    else
        DBG_UART_TRACE("Error in reading Device ID\r\n");
#endif

    index = 0;
    for (i = 0; i < table_len; i++) {
        if (lr_channel_hp[index] == 0xFE)
            R_BSP_SoftwareDelay(100U, BSP_DELAY_UNITS_MICROSECONDS);
        else if (lr_channel_hp[index] == 0xFF)
            goto exit;
        else
            write_da7218_data(lr_channel_hp[index], lr_channel_hp[index + 1]);

        index += 2;
    }

exit:
    return err;
}


void deinit_da7218(void)
{
    fsp_err_t err     = FSP_SUCCESS;

    /* close open modules */
    err =  R_IIC_MASTER_Close ((i2c_master_ctrl_t *) &g_i2c_da7218);

    if (FSP_SUCCESS != err)
        DBG_UART_TRACE("R_IIC_MASTER_Close API failed\r\n");
}

uint8_t enable_da7218()
{
    bsp_io_level_t pin_status;
    uint8_t enable;

    R_IOPORT_PinRead(&g_ioport_ctrl, DA7218_EN_PIN, &pin_status);

    enable = pin_status == 0 ? true : false;

    return enable;
}

static fsp_err_t write_da7218_data(uint8_t reg, uint8_t dat)
{
    fsp_err_t err = FSP_SUCCESS;
    uint8_t write_data[2];


    write_data[0] = reg;
    write_data[1] = dat;
    err = R_IIC_MASTER_Write(&g_i2c_da7218_ctrl, write_data, 2, true);
    if (FSP_SUCCESS != err) {
        DBG_UART_TRACE("R_IIC_MASTER_Write API failed\r\n");
        return err;
    }

    err = validate_i2c_event();
    if (FSP_SUCCESS != err) {
        DBG_UART_TRACE("I2C write failed\r\n");
        return err;
    }

    return err;
}

static fsp_err_t get_da7218_id(uint8_t *dev_id)
{
    #define DEVICE_ID_REG1 0x04
    #define DEVICE_ID_REG2 0x05
    fsp_err_t err         = FSP_SUCCESS;
    uint8_t reg_address   = DEVICE_ID_REG1;

    if (NULL == dev_id) {
        err = FSP_ERR_INVALID_POINTER;
        DBG_UART_TRACE("** NULL Pointer check fail ** \r\n");
        return err;
    }

    err = R_IIC_MASTER_Write(&g_i2c_da7218_ctrl, &reg_address, 1, true);
    if (FSP_SUCCESS != err) {
        DBG_UART_TRACE("R_IIC_MASTER_Write API failed\r\n");
        return err;
    }

    err = validate_i2c_event();
    if (FSP_ERR_TRANSFER_ABORTED == err) {
        DBG_UART_TRACE("** Device ID reg, I2C write failed ** \r\n");
        return err;
    }

    err  = R_IIC_MASTER_Read(&g_i2c_da7218_ctrl, dev_id, 1, false);
    if (FSP_SUCCESS != err){
        DBG_UART_TRACE("R_IIC_MASTER_Read API failed\r\n");
        return err;
    }

    err = validate_i2c_event();
    if (FSP_ERR_TRANSFER_ABORTED == err) {
        DBG_UART_TRACE("** Device ID read,  I2C read failed ** \r\n");
    }

    return err;
}

void i2c_master_callback(i2c_master_callback_args_t *p_args)
{
    if (NULL != p_args)
    {
        /* capture callback event for validating the i2c transfer event*/
        i2c_event = p_args->event;
    }
}

static fsp_err_t validate_i2c_event(void)
{
    uint16_t local_time_out = UINT16_MAX;

    /* resetting call back event capture variable */
    i2c_event = (i2c_master_event_t)RESET_VALUE;

    do
    {
        /* This is to avoid infinite loop */
        --local_time_out;

        if(RESET_VALUE == local_time_out)
        {
            return FSP_ERR_TRANSFER_ABORTED;
        }

    }while(i2c_event == RESET_VALUE);

    if(i2c_event != I2C_MASTER_EVENT_ABORTED)
    {
        i2c_event = (i2c_master_event_t)RESET_VALUE;  // Make sure this is always Reset before return
        return FSP_SUCCESS;
    }

    i2c_event = (i2c_master_event_t)RESET_VALUE; // Make sure this is always Reset before return
    return FSP_ERR_TRANSFER_ABORTED;
}

uint8_t get_da7218_reg(uint8_t dev_reg)
{
    fsp_err_t err         = FSP_SUCCESS;
    uint8_t reg_address   = dev_reg;
    uint8_t reg_val;

    err = R_IIC_MASTER_Write(&g_i2c_da7218_ctrl, &reg_address, 1, true);
    if (FSP_SUCCESS != err) {
        DBG_UART_TRACE("R_IIC_MASTER_Write API failed\r\n");
        return err;
    }

    err = validate_i2c_event();
    if (FSP_ERR_TRANSFER_ABORTED == err) {
        DBG_UART_TRACE("** Device ID reg, I2C write failed ** \r\n");
        return err;
    }

    err  = R_IIC_MASTER_Read(&g_i2c_da7218_ctrl, &reg_val, 1, false);
    if (FSP_SUCCESS != err){
        DBG_UART_TRACE("R_IIC_MASTER_Read API failed\r\n");
        return err;
    }

    err = validate_i2c_event();
    if (FSP_ERR_TRANSFER_ABORTED == err) {
        DBG_UART_TRACE("** Device ID read,  I2C read failed ** \r\n");
    }

    return reg_val;
}
