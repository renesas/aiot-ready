If you didin't change source code but the program crash after you do some setting change, please do following steps:

1. Check the size of stack and heap.
2. Project property >> Debug Configurations >> "Connection Settings" page >> "Set TrustZone secure/non-secure boundaries" => No
   or
   voice_main.c declare: BSP_PLACE_IN_SECTION(".data_flash") const uint8_t CybLicense[FLASH_DF_SIZE];
   Modify script/fsp.ld: ".data_flash :" => ".data_flash (NOLOAD):". 
3. Reset to factory defaults:
    Top menu of e2studio >> Run >> Renesas Debug Tools >> Renesas Device Partition Manager >> Check "Initialize device back to factory default" checkbox >> Run