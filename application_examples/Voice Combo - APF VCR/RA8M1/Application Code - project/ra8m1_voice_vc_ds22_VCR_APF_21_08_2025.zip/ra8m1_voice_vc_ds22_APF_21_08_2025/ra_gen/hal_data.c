/* generated HAL source file - do not edit */
#include "hal_data.h"

iic_master_instance_ctrl_t g_i2c_da7218_ctrl;
const iic_master_extended_cfg_t g_i2c_da7218_extend =
		{ .timeout_mode = IIC_MASTER_TIMEOUT_MODE_SHORT, .timeout_scl_low =
				IIC_MASTER_TIMEOUT_SCL_LOW_DISABLED, .smbus_operation = 0,
				/* Actual calculated bitrate: 98945. Actual calculated duty cycle: 51%. */.clock_settings.brl_value =
						15, .clock_settings.brh_value = 16,
				.clock_settings.cks_value = 4, .clock_settings.sddl_value = 0,
				.clock_settings.dlcs_value = 0, };
const i2c_master_cfg_t g_i2c_da7218_cfg = { .channel = 1, .rate =
		I2C_MASTER_RATE_STANDARD, .slave = 0x1A, .addr_mode =
		I2C_MASTER_ADDR_MODE_7BIT,
#define RA_NOT_DEFINED (1)
#if (RA_NOT_DEFINED == RA_NOT_DEFINED)
		.p_transfer_tx = NULL,
#else
                .p_transfer_tx       = &RA_NOT_DEFINED,
#endif
#if (RA_NOT_DEFINED == RA_NOT_DEFINED)
		.p_transfer_rx = NULL,
#else
                .p_transfer_rx       = &RA_NOT_DEFINED,
#endif
#undef RA_NOT_DEFINED
		.p_callback = i2c_master_callback, .p_context = NULL,
#if defined(VECTOR_NUMBER_IIC1_RXI)
    .rxi_irq             = VECTOR_NUMBER_IIC1_RXI,
#else
		.rxi_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_IIC1_TXI)
    .txi_irq             = VECTOR_NUMBER_IIC1_TXI,
#else
		.txi_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_IIC1_TEI)
    .tei_irq             = VECTOR_NUMBER_IIC1_TEI,
#else
		.tei_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_IIC1_ERI)
    .eri_irq             = VECTOR_NUMBER_IIC1_ERI,
#else
		.eri_irq = FSP_INVALID_VECTOR,
#endif
		.ipl = (12), .p_extend = &g_i2c_da7218_extend, };
/* Instance structure to use this module. */
const i2c_master_instance_t g_i2c_da7218 = { .p_ctrl = &g_i2c_da7218_ctrl,
		.p_cfg = &g_i2c_da7218_cfg, .p_api = &g_i2c_master_on_iic };
dtc_instance_ctrl_t g_transfer_unused_instance_ctrl;

#if (1 == 1)
transfer_info_t g_transfer_unused_instance_info DTC_TRANSFER_INFO_ALIGNMENT = {
		.transfer_settings_word_b.dest_addr_mode = TRANSFER_ADDR_MODE_FIXED,
		.transfer_settings_word_b.repeat_area = TRANSFER_REPEAT_AREA_SOURCE,
		.transfer_settings_word_b.irq = TRANSFER_IRQ_END,
		.transfer_settings_word_b.chain_mode = TRANSFER_CHAIN_MODE_DISABLED,
		.transfer_settings_word_b.src_addr_mode = TRANSFER_ADDR_MODE_FIXED,
		.transfer_settings_word_b.size = TRANSFER_SIZE_2_BYTE,
		.transfer_settings_word_b.mode = TRANSFER_MODE_NORMAL, .p_dest =
				(void*) NULL, .p_src = (void const*) NULL, .num_blocks = 0,
		.length = 0, };

#elif (1 > 1)
/* User is responsible to initialize the array. */
transfer_info_t g_transfer_unused_instance_info[1] DTC_TRANSFER_INFO_ALIGNMENT;
#else
/* User must call api::reconfigure before enable DTC transfer. */
#endif

const dtc_extended_cfg_t g_transfer_unused_instance_cfg_extend = {
		.activation_source = VECTOR_NUMBER_ADC0_SCAN_END, };

const transfer_cfg_t g_transfer_unused_instance_cfg = {
#if (1 == 1)
		.p_info = &g_transfer_unused_instance_info,
#elif (1 > 1)
    .p_info              = g_transfer_unused_instance_info,
#else
    .p_info = NULL,
#endif
		.p_extend = &g_transfer_unused_instance_cfg_extend, };

/* Instance structure to use this module. */
const transfer_instance_t g_transfer_unused_instance = { .p_ctrl =
		&g_transfer_unused_instance_ctrl, .p_cfg =
		&g_transfer_unused_instance_cfg, .p_api = &g_transfer_on_dtc };
adc_instance_ctrl_t g_adc_amic_ctrl;
const adc_extended_cfg_t g_adc_amic_cfg_extend = { .add_average_count =
		ADC_ADD_OFF, .clearing = ADC_CLEAR_AFTER_READ_ON, .trigger =
		ADC_START_SOURCE_ELC_AD0 /* AD0 for Group A. AD1 for Group B */,
		.trigger_group_b = ADC_START_SOURCE_DISABLED, .double_trigger_mode =
				ADC_DOUBLE_TRIGGER_DISABLED, .adc_vref_control =
				ADC_VREF_CONTROL_VREFH, .enable_adbuf = 0,
#if defined(VECTOR_NUMBER_ADC0_WINDOW_A)
    .window_a_irq        = VECTOR_NUMBER_ADC0_WINDOW_A,
#else
		.window_a_irq = FSP_INVALID_VECTOR,
#endif
		.window_a_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_ADC0_WINDOW_B)
    .window_b_irq      = VECTOR_NUMBER_ADC0_WINDOW_B,
#else
		.window_b_irq = FSP_INVALID_VECTOR,
#endif
		.window_b_ipl = (BSP_IRQ_DISABLED), };
const adc_cfg_t g_adc_amic_cfg = { .unit = 0, .mode = ADC_MODE_SINGLE_SCAN,
		.resolution = ADC_RESOLUTION_12_BIT, .alignment =
				(adc_alignment_t) ADC_ALIGNMENT_RIGHT, .trigger =
				(adc_trigger_t) 0xF, // Not used
		.p_callback = adc_cb,
		/** If NULL then do not add & */
#if defined(NULL)
    .p_context           = NULL,
#else
		.p_context = &NULL,
#endif
		.p_extend = &g_adc_amic_cfg_extend,
#if defined(VECTOR_NUMBER_ADC0_SCAN_END)
    .scan_end_irq        = VECTOR_NUMBER_ADC0_SCAN_END,
#else
		.scan_end_irq = FSP_INVALID_VECTOR,
#endif
		.scan_end_ipl = (2),
#if defined(VECTOR_NUMBER_ADC0_SCAN_END_B)
    .scan_end_b_irq      = VECTOR_NUMBER_ADC0_SCAN_END_B,
#else
		.scan_end_b_irq = FSP_INVALID_VECTOR,
#endif
		.scan_end_b_ipl = (BSP_IRQ_DISABLED), };
#if ((0) | (0))
const adc_window_cfg_t g_adc_amic_window_cfg =
{
    .compare_mask        =  0,
    .compare_mode_mask   =  0,
    .compare_cfg         = (adc_compare_cfg_t) ((0) | (0) | (0) | (ADC_COMPARE_CFG_EVENT_OUTPUT_OR)),
    .compare_ref_low     = 0,
    .compare_ref_high    = 0,
    .compare_b_channel   = (ADC_WINDOW_B_CHANNEL_0),
    .compare_b_mode      = (ADC_WINDOW_B_MODE_LESS_THAN_OR_OUTSIDE),
    .compare_b_ref_low   = 0,
    .compare_b_ref_high  = 0,
};
#endif
const adc_channel_cfg_t g_adc_amic_channel_cfg = { .scan_mask =
		ADC_MASK_CHANNEL_0 | 0, .scan_mask_group_b = 0, .priority_group_a =
		ADC_GROUP_A_PRIORITY_OFF, .add_mask = 0, .sample_hold_mask = 0,
		.sample_hold_states = 24,
#if ((0) | (0))
    .p_window_cfg        = (adc_window_cfg_t *) &g_adc_amic_window_cfg,
#else
		.p_window_cfg = NULL,
#endif
		};
/* Instance structure to use this module. */
const adc_instance_t g_adc_amic = { .p_ctrl = &g_adc_amic_ctrl, .p_cfg =
		&g_adc_amic_cfg, .p_channel_cfg = &g_adc_amic_channel_cfg, .p_api =
		&g_adc_on_adc };
agt_instance_ctrl_t g_timer_amic_ctrl;
const agt_extended_cfg_t g_timer_amic_extend = {
		.count_source = AGT_CLOCK_PCLKB, .agto = AGT_PIN_CFG_DISABLED,
		.agtoab_settings_b.agtoa = AGT_PIN_CFG_DISABLED,
		.agtoab_settings_b.agtob = AGT_PIN_CFG_DISABLED, .measurement_mode =
				AGT_MEASURE_DISABLED, .agtio_filter = AGT_AGTIO_FILTER_NONE,
		.enable_pin = AGT_ENABLE_PIN_NOT_USED, .trigger_edge =
				AGT_TRIGGER_EDGE_RISING, .counter_bit_width =
				AGT_COUNTER_BIT_WIDTH_16, };
const timer_cfg_t g_timer_amic_cfg = { .mode = TIMER_MODE_PERIODIC,
/* Actual period: 0.0000625 seconds. Actual duty: 50%. */.period_counts =
		(uint32_t) 0xea6, .duty_cycle_counts = 0x753, .source_div =
		(timer_source_div_t) 0, .channel = 0, .p_callback = NULL,
/** If NULL then do not add & */
#if defined(NULL)
    .p_context           = NULL,
#else
		.p_context = &NULL,
#endif
		.p_extend = &g_timer_amic_extend, .cycle_end_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_AGT0_INT)
    .cycle_end_irq       = VECTOR_NUMBER_AGT0_INT,
#else
		.cycle_end_irq = FSP_INVALID_VECTOR,
#endif
		};
/* Instance structure to use this module. */
const timer_instance_t g_timer_amic = { .p_ctrl = &g_timer_amic_ctrl, .p_cfg =
		&g_timer_amic_cfg, .p_api = &g_timer_on_agt };
gpt_instance_ctrl_t g_timer_playback_ctrl;
#if 0
const gpt_extended_pwm_cfg_t g_timer_playback_pwm_extend =
{
    .trough_ipl          = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT0_COUNTER_UNDERFLOW)
    .trough_irq          = VECTOR_NUMBER_GPT0_COUNTER_UNDERFLOW,
#else
    .trough_irq          = FSP_INVALID_VECTOR,
#endif
    .poeg_link           = GPT_POEG_LINK_POEG0,
    .output_disable      = (gpt_output_disable_t) ( GPT_OUTPUT_DISABLE_NONE),
    .adc_trigger         = (gpt_adc_trigger_t) ( GPT_ADC_TRIGGER_NONE),
    .dead_time_count_up  = 0,
    .dead_time_count_down = 0,
    .adc_a_compare_match = 0,
    .adc_b_compare_match = 0,
    .interrupt_skip_source = GPT_INTERRUPT_SKIP_SOURCE_NONE,
    .interrupt_skip_count  = GPT_INTERRUPT_SKIP_COUNT_0,
    .interrupt_skip_adc    = GPT_INTERRUPT_SKIP_ADC_NONE,
    .gtioca_disable_setting = GPT_GTIOC_DISABLE_PROHIBITED,
    .gtiocb_disable_setting = GPT_GTIOC_DISABLE_PROHIBITED,
};
#endif
const gpt_extended_cfg_t g_timer_playback_extend =
		{
				.gtioca = { .output_enabled = false, .stop_level =
						GPT_PIN_LEVEL_LOW }, .gtiocb =
						{ .output_enabled = false, .stop_level =
								GPT_PIN_LEVEL_LOW }, .start_source =
						(gpt_source_t)(GPT_SOURCE_NONE), .stop_source =
						(gpt_source_t)(GPT_SOURCE_NONE), .clear_source =
						(gpt_source_t)(GPT_SOURCE_NONE), .count_up_source =
						(gpt_source_t)(GPT_SOURCE_NONE), .count_down_source =
						(gpt_source_t)(GPT_SOURCE_NONE), .capture_a_source =
						(gpt_source_t)(GPT_SOURCE_NONE), .capture_b_source =
						(gpt_source_t)(GPT_SOURCE_NONE), .capture_a_ipl =
						(BSP_IRQ_DISABLED), .capture_b_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT0_CAPTURE_COMPARE_A)
    .capture_a_irq       = VECTOR_NUMBER_GPT0_CAPTURE_COMPARE_A,
#else
				.capture_a_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT0_CAPTURE_COMPARE_B)
    .capture_b_irq       = VECTOR_NUMBER_GPT0_CAPTURE_COMPARE_B,
#else
				.capture_b_irq = FSP_INVALID_VECTOR,
#endif
				.compare_match_value = { /* CMP_A */0x0, /* CMP_B */0x0 },
				.compare_match_status = (0U << 1U) | 0U,
				.capture_filter_gtioca = GPT_CAPTURE_FILTER_NONE,
				.capture_filter_gtiocb = GPT_CAPTURE_FILTER_NONE,
#if 0
    .p_pwm_cfg                   = &g_timer_playback_pwm_extend,
#else
				.p_pwm_cfg = NULL,
#endif
#if 0
    .gtior_setting.gtior_b.gtioa  = (0U << 4U) | (0U << 2U) | (0U << 0U),
    .gtior_setting.gtior_b.oadflt = (uint32_t) GPT_PIN_LEVEL_LOW,
    .gtior_setting.gtior_b.oahld  = 0U,
    .gtior_setting.gtior_b.oae    = (uint32_t) false,
    .gtior_setting.gtior_b.oadf   = (uint32_t) GPT_GTIOC_DISABLE_PROHIBITED,
    .gtior_setting.gtior_b.nfaen  = ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
    .gtior_setting.gtior_b.nfcsa  = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U),
    .gtior_setting.gtior_b.gtiob  = (0U << 4U) | (0U << 2U) | (0U << 0U),
    .gtior_setting.gtior_b.obdflt = (uint32_t) GPT_PIN_LEVEL_LOW,
    .gtior_setting.gtior_b.obhld  = 0U,
    .gtior_setting.gtior_b.obe    = (uint32_t) false,
    .gtior_setting.gtior_b.obdf   = (uint32_t) GPT_GTIOC_DISABLE_PROHIBITED,
    .gtior_setting.gtior_b.nfben  = ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
    .gtior_setting.gtior_b.nfcsb  = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U),
#else
				.gtior_setting.gtior = 0U,
#endif
		};

const timer_cfg_t g_timer_playback_cfg = { .mode = TIMER_MODE_PERIODIC,
/* Actual period: 0.0000625 seconds. Actual duty: 50%. */.period_counts =
		(uint32_t) 0x1d4c, .duty_cycle_counts = 0xea6, .source_div =
		(timer_source_div_t) 0, .channel = 0, .p_callback =
		g_timer_playback_callback,
/** If NULL then do not add & */
#if defined(NULL)
    .p_context           = NULL,
#else
		.p_context = &NULL,
#endif
		.p_extend = &g_timer_playback_extend, .cycle_end_ipl = (12),
#if defined(VECTOR_NUMBER_GPT0_COUNTER_OVERFLOW)
    .cycle_end_irq       = VECTOR_NUMBER_GPT0_COUNTER_OVERFLOW,
#else
		.cycle_end_irq = FSP_INVALID_VECTOR,
#endif
		};
/* Instance structure to use this module. */
const timer_instance_t g_timer_playback = { .p_ctrl = &g_timer_playback_ctrl,
		.p_cfg = &g_timer_playback_cfg, .p_api = &g_timer_on_gpt };
dac_instance_ctrl_t g_dac_playback_ctrl;
const dac_extended_cfg_t g_dac_playback_ext_cfg = { .enable_charge_pump = 0,
		.data_format = DAC_DATA_FORMAT_FLUSH_RIGHT, .output_amplifier_enabled =
				0, .internal_output_enabled = false, .ref_volt_sel =
				(dac_ref_volt_sel_t)(0) };
const dac_cfg_t g_dac_playback_cfg = { .channel = 0,
		.ad_da_synchronized = false, .p_extend = &g_dac_playback_ext_cfg };
/* Instance structure to use this module. */
const dac_instance_t g_dac_playback = { .p_ctrl = &g_dac_playback_ctrl, .p_cfg =
		&g_dac_playback_cfg, .p_api = &g_dac_on_dac };
flash_hp_instance_ctrl_t g_flash0_ctrl;
const flash_cfg_t g_flash0_cfg = { .data_flash_bgo = true, .p_callback =
		flash0_bgo_callback, .p_context = NULL,
#if defined(VECTOR_NUMBER_FCU_FRDYI)
    .irq                 = VECTOR_NUMBER_FCU_FRDYI,
#else
		.irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_FCU_FIFERR)
    .err_irq             = VECTOR_NUMBER_FCU_FIFERR,
#else
		.err_irq = FSP_INVALID_VECTOR,
#endif
		.err_ipl = (8), .ipl = (8), };
/* Instance structure to use this module. */
const flash_instance_t g_flash0 = { .p_ctrl = &g_flash0_ctrl, .p_cfg =
		&g_flash0_cfg, .p_api = &g_flash_on_flash_hp };
gpt_instance_ctrl_t g_i2s_clock_ctrl;
#if 0
const gpt_extended_pwm_cfg_t g_i2s_clock_pwm_extend =
{
    .trough_ipl          = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT2_COUNTER_UNDERFLOW)
    .trough_irq          = VECTOR_NUMBER_GPT2_COUNTER_UNDERFLOW,
#else
    .trough_irq          = FSP_INVALID_VECTOR,
#endif
    .poeg_link           = GPT_POEG_LINK_POEG0,
    .output_disable      = (gpt_output_disable_t) ( GPT_OUTPUT_DISABLE_NONE),
    .adc_trigger         = (gpt_adc_trigger_t) ( GPT_ADC_TRIGGER_NONE),
    .dead_time_count_up  = 0,
    .dead_time_count_down = 0,
    .adc_a_compare_match = 0,
    .adc_b_compare_match = 0,
    .interrupt_skip_source = GPT_INTERRUPT_SKIP_SOURCE_NONE,
    .interrupt_skip_count  = GPT_INTERRUPT_SKIP_COUNT_0,
    .interrupt_skip_adc    = GPT_INTERRUPT_SKIP_ADC_NONE,
    .gtioca_disable_setting = GPT_GTIOC_DISABLE_PROHIBITED,
    .gtiocb_disable_setting = GPT_GTIOC_DISABLE_PROHIBITED,
};
#endif
const gpt_extended_cfg_t g_i2s_clock_extend =
		{ .gtioca = { .output_enabled = true, .stop_level = GPT_PIN_LEVEL_LOW },
				.gtiocb = { .output_enabled = false, .stop_level =
						GPT_PIN_LEVEL_LOW }, .start_source = (gpt_source_t)(
						GPT_SOURCE_NONE), .stop_source = (gpt_source_t)(
						GPT_SOURCE_NONE), .clear_source = (gpt_source_t)(
						GPT_SOURCE_NONE), .count_up_source = (gpt_source_t)(
						GPT_SOURCE_NONE), .count_down_source = (gpt_source_t)(
						GPT_SOURCE_NONE), .capture_a_source = (gpt_source_t)(
						GPT_SOURCE_NONE), .capture_b_source = (gpt_source_t)(
						GPT_SOURCE_NONE), .capture_a_ipl = (BSP_IRQ_DISABLED),
				.capture_b_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT2_CAPTURE_COMPARE_A)
    .capture_a_irq       = VECTOR_NUMBER_GPT2_CAPTURE_COMPARE_A,
#else
				.capture_a_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT2_CAPTURE_COMPARE_B)
    .capture_b_irq       = VECTOR_NUMBER_GPT2_CAPTURE_COMPARE_B,
#else
				.capture_b_irq = FSP_INVALID_VECTOR,
#endif
				.compare_match_value = { /* CMP_A */0x0, /* CMP_B */0x0 },
				.compare_match_status = (0U << 1U) | 0U,
				.capture_filter_gtioca = GPT_CAPTURE_FILTER_NONE,
				.capture_filter_gtiocb = GPT_CAPTURE_FILTER_NONE,
#if 0
    .p_pwm_cfg                   = &g_i2s_clock_pwm_extend,
#else
				.p_pwm_cfg = NULL,
#endif
#if 0
    .gtior_setting.gtior_b.gtioa  = (0U << 4U) | (0U << 2U) | (0U << 0U),
    .gtior_setting.gtior_b.oadflt = (uint32_t) GPT_PIN_LEVEL_LOW,
    .gtior_setting.gtior_b.oahld  = 0U,
    .gtior_setting.gtior_b.oae    = (uint32_t) true,
    .gtior_setting.gtior_b.oadf   = (uint32_t) GPT_GTIOC_DISABLE_PROHIBITED,
    .gtior_setting.gtior_b.nfaen  = ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
    .gtior_setting.gtior_b.nfcsa  = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U),
    .gtior_setting.gtior_b.gtiob  = (0U << 4U) | (0U << 2U) | (0U << 0U),
    .gtior_setting.gtior_b.obdflt = (uint32_t) GPT_PIN_LEVEL_LOW,
    .gtior_setting.gtior_b.obhld  = 0U,
    .gtior_setting.gtior_b.obe    = (uint32_t) false,
    .gtior_setting.gtior_b.obdf   = (uint32_t) GPT_GTIOC_DISABLE_PROHIBITED,
    .gtior_setting.gtior_b.nfben  = ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
    .gtior_setting.gtior_b.nfcsb  = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U),
#else
				.gtior_setting.gtior = 0U,
#endif
		};

const timer_cfg_t g_i2s_clock_cfg =
		{ .mode = TIMER_MODE_PERIODIC,
				/* Actual period: 9.75e-7 seconds. Actual duty: 49.572649572649574%. */.period_counts =
						(uint32_t) 0x75, .duty_cycle_counts = 0x3a,
				.source_div = (timer_source_div_t) 0, .channel = 2,
				.p_callback = NULL,
				/** If NULL then do not add & */
#if defined(NULL)
    .p_context           = NULL,
#else
				.p_context = &NULL,
#endif
				.p_extend = &g_i2s_clock_extend, .cycle_end_ipl =
						(BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT2_COUNTER_OVERFLOW)
    .cycle_end_irq       = VECTOR_NUMBER_GPT2_COUNTER_OVERFLOW,
#else
				.cycle_end_irq = FSP_INVALID_VECTOR,
#endif
		};
/* Instance structure to use this module. */
const timer_instance_t g_i2s_clock = { .p_ctrl = &g_i2s_clock_ctrl, .p_cfg =
		&g_i2s_clock_cfg, .p_api = &g_timer_on_gpt };
dtc_instance_ctrl_t g_transfer0_ctrl;

#if (1 == 1)
transfer_info_t g_transfer0_info DTC_TRANSFER_INFO_ALIGNMENT =
		{ .transfer_settings_word_b.dest_addr_mode =
				TRANSFER_ADDR_MODE_INCREMENTED,
				.transfer_settings_word_b.repeat_area =
						TRANSFER_REPEAT_AREA_DESTINATION,
				.transfer_settings_word_b.irq = TRANSFER_IRQ_END,
				.transfer_settings_word_b.chain_mode =
						TRANSFER_CHAIN_MODE_DISABLED,
				.transfer_settings_word_b.src_addr_mode =
						TRANSFER_ADDR_MODE_FIXED,
				.transfer_settings_word_b.size = TRANSFER_SIZE_4_BYTE,
				.transfer_settings_word_b.mode = TRANSFER_MODE_BLOCK, .p_dest =
						(void*) NULL, .p_src = (void const*) NULL, .num_blocks =
						0, .length = 0, };

#elif (1 > 1)
/* User is responsible to initialize the array. */
transfer_info_t g_transfer0_info[1] DTC_TRANSFER_INFO_ALIGNMENT;
#else
/* User must call api::reconfigure before enable DTC transfer. */
#endif

const dtc_extended_cfg_t g_transfer0_cfg_extend = { .activation_source =
		VECTOR_NUMBER_SSI0_RXI, };

const transfer_cfg_t g_transfer0_cfg = {
#if (1 == 1)
		.p_info = &g_transfer0_info,
#elif (1 > 1)
    .p_info              = g_transfer0_info,
#else
    .p_info = NULL,
#endif
		.p_extend = &g_transfer0_cfg_extend, };

/* Instance structure to use this module. */
const transfer_instance_t g_transfer0 = { .p_ctrl = &g_transfer0_ctrl, .p_cfg =
		&g_transfer0_cfg, .p_api = &g_transfer_on_dtc };
ssi_instance_ctrl_t g_i2s0_ctrl;

/** SSI instance configuration */
const ssi_extended_cfg_t g_i2s0_cfg_extend = { .audio_clock =
		(ssi_audio_clock_t) SSI_AUDIO_CLOCK_INTERNAL, .bit_clock_div =
		SSI_CLOCK_DIV_1, };

/** I2S interface configuration */
const i2s_cfg_t g_i2s0_cfg = { .channel = 0, .pcm_width = I2S_PCM_WIDTH_16_BITS,
		.operating_mode = I2S_MODE_MASTER, .word_length =
				I2S_WORD_LENGTH_32_BITS, .ws_continue = I2S_WS_CONTINUE_OFF,
		.p_callback = g_audio_cb, .p_context = NULL, .p_extend =
				&g_i2s0_cfg_extend,
#if (BSP_IRQ_DISABLED) != BSP_IRQ_DISABLED
                .txi_irq                 = VECTOR_NUMBER_SSI0_TXI,
#else
		.txi_irq = FSP_INVALID_VECTOR,
#endif
#if (2) != BSP_IRQ_DISABLED
		.rxi_irq = VECTOR_NUMBER_SSI0_RXI,
#else
                .rxi_irq                 = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_SSI0_INT)
                .int_irq                 = VECTOR_NUMBER_SSI0_INT,
#else
		.int_irq = FSP_INVALID_VECTOR,
#endif
		.txi_ipl = (BSP_IRQ_DISABLED), .rxi_ipl = (2), .idle_err_ipl = (2),
#define RA_NOT_DEFINED (1)
#if (RA_NOT_DEFINED == RA_NOT_DEFINED)
		.p_transfer_tx = NULL,
#else
                .p_transfer_tx       = &RA_NOT_DEFINED,
#endif
#if (RA_NOT_DEFINED == g_transfer0)
                .p_transfer_rx       = NULL,
#else
		.p_transfer_rx = &g_transfer0,
#endif
#undef RA_NOT_DEFINED
		};

/* Instance structure to use this module. */
const i2s_instance_t g_i2s0 = { .p_ctrl = &g_i2s0_ctrl, .p_cfg = &g_i2s0_cfg,
		.p_api = &g_i2s_on_ssi };
sci_b_uart_instance_ctrl_t g_uart_ds_ctrl;

sci_b_baud_setting_t g_uart_ds_baud_setting = {
/* Baud rate calculated with 0.009% error. */.baudrate_bits_b.abcse = 0,
		.baudrate_bits_b.abcs = 0, .baudrate_bits_b.bgdm = 1,
		.baudrate_bits_b.cks = 0, .baudrate_bits_b.brr = 10,
		.baudrate_bits_b.mddr = (uint8_t) 173, .baudrate_bits_b.brme = true };

/** UART extended configuration for UARTonSCI HAL driver */
const sci_b_uart_extended_cfg_t g_uart_ds_cfg_extend = { .clock =
		SCI_B_UART_CLOCK_INT,
		.rx_edge_start = SCI_B_UART_START_BIT_FALLING_EDGE, .noise_cancel =
				SCI_B_UART_NOISE_CANCELLATION_DISABLE, .rx_fifo_trigger =
				SCI_B_UART_RX_FIFO_TRIGGER_MAX, .p_baud_setting =
				&g_uart_ds_baud_setting, .flow_control =
				SCI_B_UART_FLOW_CONTROL_RTS,
#if 0xFF != 0xFF
                .flow_control_pin       = BSP_IO_PORT_FF_PIN_0xFF,
                #else
		.flow_control_pin = (bsp_io_port_pin_t) UINT16_MAX,
#endif
		.rs485_setting = { .enable = SCI_B_UART_RS485_DISABLE, .polarity =
				SCI_B_UART_RS485_DE_POLARITY_HIGH, .assertion_time = 1,
				.negation_time = 1, } };

/** UART interface configuration */
const uart_cfg_t g_uart_ds_cfg = { .channel = 0, .data_bits = UART_DATA_BITS_8,
		.parity = UART_PARITY_OFF, .stop_bits = UART_STOP_BITS_1, .p_callback =
				user_uart_callback, .p_context = NULL, .p_extend =
				&g_uart_ds_cfg_extend,
#define RA_NOT_DEFINED (1)
#if (RA_NOT_DEFINED == RA_NOT_DEFINED)
		.p_transfer_tx = NULL,
#else
                .p_transfer_tx       = &RA_NOT_DEFINED,
#endif
#if (RA_NOT_DEFINED == RA_NOT_DEFINED)
		.p_transfer_rx = NULL,
#else
                .p_transfer_rx       = &RA_NOT_DEFINED,
#endif
#undef RA_NOT_DEFINED
		.rxi_ipl = (12), .txi_ipl = (12), .tei_ipl = (12), .eri_ipl = (12),
#if defined(VECTOR_NUMBER_SCI0_RXI)
                .rxi_irq             = VECTOR_NUMBER_SCI0_RXI,
#else
		.rxi_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_SCI0_TXI)
                .txi_irq             = VECTOR_NUMBER_SCI0_TXI,
#else
		.txi_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_SCI0_TEI)
                .tei_irq             = VECTOR_NUMBER_SCI0_TEI,
#else
		.tei_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_SCI0_ERI)
                .eri_irq             = VECTOR_NUMBER_SCI0_ERI,
#else
		.eri_irq = FSP_INVALID_VECTOR,
#endif
		};

/* Instance structure to use this module. */
const uart_instance_t g_uart_ds = { .p_ctrl = &g_uart_ds_ctrl, .p_cfg =
		&g_uart_ds_cfg, .p_api = &g_uart_on_sci_b };
void g_hal_init(void) {
	g_common_init();
}
