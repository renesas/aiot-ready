/* generated vector source file - do not edit */
#include "bsp_api.h"
/* Do not build these data structures if no interrupts are currently allocated because IAR will have build errors. */
#if VECTOR_DATA_IRQ_COUNT > 0
        BSP_DONT_REMOVE const fsp_vector_t g_vector_table[BSP_ICU_VECTOR_MAX_ENTRIES] BSP_PLACE_IN_SECTION(BSP_SECTION_APPLICATION_VECTORS) =
        {
                        [0] = sci_b_uart_rxi_isr, /* SCI0 RXI (Receive data full) */
            [1] = sci_b_uart_txi_isr, /* SCI0 TXI (Transmit data empty) */
            [2] = sci_b_uart_tei_isr, /* SCI0 TEI (Transmit end) */
            [3] = sci_b_uart_eri_isr, /* SCI0 ERI (Receive error) */
            [4] = ssi_rxi_isr, /* SSI0 RXI (Receive data full) */
            [5] = ssi_int_isr, /* SSI0 INT (Error interrupt) */
            [6] = fcu_frdyi_isr, /* FCU FRDYI (Flash ready interrupt) */
            [7] = fcu_fiferr_isr, /* FCU FIFERR (Flash access error interrupt) */
            [8] = r_icu_isr, /* ICU IRQ0 (External pin interrupt 0) */
            [9] = gpt_counter_overflow_isr, /* GPT0 COUNTER OVERFLOW (Overflow) */
            [10] = adc_scan_end_isr, /* ADC0 SCAN END (End of A/D scanning operation) */
            [11] = iic_master_rxi_isr, /* IIC1 RXI (Receive data full) */
            [12] = iic_master_txi_isr, /* IIC1 TXI (Transmit data empty) */
            [13] = iic_master_tei_isr, /* IIC1 TEI (Transmit end) */
            [14] = iic_master_eri_isr, /* IIC1 ERI (Transfer error) */
        };
        #if BSP_FEATURE_ICU_HAS_IELSR
        const bsp_interrupt_event_t g_interrupt_event_link_select[BSP_ICU_VECTOR_MAX_ENTRIES] =
        {
            [0] = BSP_PRV_VECT_ENUM(EVENT_SCI0_RXI,GROUP0), /* SCI0 RXI (Receive data full) */
            [1] = BSP_PRV_VECT_ENUM(EVENT_SCI0_TXI,GROUP1), /* SCI0 TXI (Transmit data empty) */
            [2] = BSP_PRV_VECT_ENUM(EVENT_SCI0_TEI,GROUP2), /* SCI0 TEI (Transmit end) */
            [3] = BSP_PRV_VECT_ENUM(EVENT_SCI0_ERI,GROUP3), /* SCI0 ERI (Receive error) */
            [4] = BSP_PRV_VECT_ENUM(EVENT_SSI0_RXI,GROUP4), /* SSI0 RXI (Receive data full) */
            [5] = BSP_PRV_VECT_ENUM(EVENT_SSI0_INT,GROUP5), /* SSI0 INT (Error interrupt) */
            [6] = BSP_PRV_VECT_ENUM(EVENT_FCU_FRDYI,GROUP6), /* FCU FRDYI (Flash ready interrupt) */
            [7] = BSP_PRV_VECT_ENUM(EVENT_FCU_FIFERR,GROUP7), /* FCU FIFERR (Flash access error interrupt) */
            [8] = BSP_PRV_VECT_ENUM(EVENT_ICU_IRQ0,GROUP0), /* ICU IRQ0 (External pin interrupt 0) */
            [9] = BSP_PRV_VECT_ENUM(EVENT_GPT0_COUNTER_OVERFLOW,GROUP1), /* GPT0 COUNTER OVERFLOW (Overflow) */
            [10] = BSP_PRV_VECT_ENUM(EVENT_ADC0_SCAN_END,GROUP2), /* ADC0 SCAN END (End of A/D scanning operation) */
            [11] = BSP_PRV_VECT_ENUM(EVENT_IIC1_RXI,GROUP3), /* IIC1 RXI (Receive data full) */
            [12] = BSP_PRV_VECT_ENUM(EVENT_IIC1_TXI,GROUP4), /* IIC1 TXI (Transmit data empty) */
            [13] = BSP_PRV_VECT_ENUM(EVENT_IIC1_TEI,GROUP5), /* IIC1 TEI (Transmit end) */
            [14] = BSP_PRV_VECT_ENUM(EVENT_IIC1_ERI,GROUP6), /* IIC1 ERI (Transfer error) */
        };
        #endif
        #endif
