/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer *
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

#ifndef VOICE_MAIN_H
#define VOICE_MAIN_H

#include "bsp_api.h"

/*******************************************************************************
 Include
*******************************************************************************/

/*******************************************************************************
 Macro definitions
*******************************************************************************/

#define UART_LOG

// Definition for support function
#define SUPPORT_UART_DUMP_RECORD                         // Transfer record data through UART(460800 bps) to PC CybSerialRecorder.

#define NOT_SHOW_MULTI_PRONUNCIATION                     // Don't display the command string that include '^' character.

// Definition for group index
#define GROUP_INDEX_TRIGGER      0                       // The group index of trigger.

#if defined(BOARD_RA4E1_VOICE)
    #define MCU_BOARD_STRING                        "VOICE-RA4E1"

    /** Data flash */
    #define FLASH_DF_SIZE                           (8192)

    /** LED for VOICE-RA4E1 */
    #define LED_R                                   BSP_IO_PORT_05_PIN_00
    #define LED_G                                   BSP_IO_PORT_02_PIN_13
    #define LED_B                                   BSP_IO_PORT_02_PIN_12
    #define LED_Y                                   BSP_IO_PORT_00_PIN_00
    #define OFF                                     (BSP_IO_LEVEL_HIGH)
    #define ON                                      (BSP_IO_LEVEL_LOW)
#elif defined(BOARD_RA6E1_VOICE)
    #define MCU_BOARD_STRING                        "VOICE-RA6E1"

    /** Data flash */
    #define FLASH_DF_SIZE                           (8192)

    /** LED for VOICE-RA6E1 */
    #define LED_R                                   BSP_IO_PORT_05_PIN_00
    #define LED_G                                   BSP_IO_PORT_04_PIN_00
    #define LED_B                                   BSP_IO_PORT_01_PIN_13
    #define LED_Y                                   BSP_IO_PORT_00_PIN_00
    #define OFF                                     (1U)
    #define ON                                      (0U)
#endif

#define FLASH_DF_BLOCK_SIZE                         ((signed) BSP_FEATURE_FLASH_HP_DF_BLOCK_SIZE)
#define FLASH_DF_BLOCK_BASE_ADDRESS                 (BSP_FEATURE_FLASH_DATA_FLASH_START)

#define SAMPLE_CODE_BUILD_BUM                       "210312"

/*******************************************************************************
 Exported global variables
*******************************************************************************/
typedef enum e_group_index
{
    GROUP_INDEX_ZERO = 0,
    GROUP_INDEX_ONE,
    GROUP_INDEX_TWO,
    GROUP_INDEX_THREE,
    GROUP_INDEX_FOUR,
    GROUP_INDEX_FIVE,
    GROUP_INDEX_SIX,
    GROUP_INDEX_SEVEN,
    GROUP_INDEX_EIGHT,
    GROUP_INDEX_NINE,
    GROUP_INDEX_TEN
}group_index_t;

typedef enum e_cmd_num
{
    ZERO = 0,
    ONE,
    TWO,
    THREE,
    FOUR,
    FIVE,
    SIX,
    SEVEN,
    EIGHT,
    NINE,
    TEN,
    ELEVEN,
    TWELVE,
    THIRTEEN,
    FOURTEEN,
    FIFTEEN,
    SIXTEEN,
    SEVENTEEN,
    EIGHTEEN,
    NINETEEN,
    TWENTY,
    TWENTY_ONE,
    TWENTY_TWO,
    TWENTY_THREE,
    TWENTY_FOUR,
    TWENTY_FIVE,
    TWENTY_SIX,
    TWENTY_SEVEN,
    TWENTY_EIGHT,
    TWENTY_NINE,
    THIRTY,
    THIRTY_ONE,
    THIRTY_TWO,
    THIRTY_THREE,
    THIRTY_FOUR,
    THIRTY_FIVE,
    THIRTY_SIX,
    THIRTY_SEVEN,
    THIRTY_EIGHT,
    THIRTY_NINE,
    FOURTY,
    FOURTY_ONE,
    FOURTY_TWO,
    FOURTY_THREE,
    FOURTY_FOUR,
    FOURTY_FIVE
}cmd_num_t;
typedef enum e_voc_cmd
{
    VOC_INVALID_CMD = 0,
    VOC_AC_START = 11,
    VOC_AC_STOP = 12,

    VOC_SET_TEMP_16 = 21,
    VOC_SET_TEMP_17 = 22,
    VOC_SET_TEMP_18 = 23,
    VOC_SET_TEMP_19 = 24,
    VOC_SET_TEMP_20 = 25,
    VOC_SET_TEMP_21 = 26,
    VOC_SET_TEMP_22 = 27,
    VOC_SET_TEMP_23 = 28,
    VOC_SET_TEMP_24 = 29,
    VOC_SET_TEMP_25 = 30,
    VOC_SET_TEMP_26 = 31,
    VOC_SET_TEMP_27 = 32,
    VOC_SET_TEMP_28 = 33,
    VOC_SET_TEMP_29 = 34,
    VOC_SET_TEMP_30 = 35,
    VOC_SET_TEMP_31 = 36,
    VOC_SET_TEMP_32 = 37,
    VOC_SET_TEMP_UP = 38,
    VOC_SET_TEMP_DW = 39,

    VOC_TMR_ON_HALF_HOUR = 41,
    VOC_TMR_ON_HOUR_1 = 42,
    VOC_TMR_ON_HOUR_2 = 43,
    VOC_TMR_ON_HOUR_3 = 44,
    VOC_TMR_ON_HOUR_4 = 45,
    VOC_TMR_ON_HOUR_5 = 46,
    VOC_TMR_ON_CANCEL = 47,

    VOC_TMR_OFF_HALF_HOUR = 51,
    VOC_TMR_OFF_HOUR_1 = 52,
    VOC_TMR_OFF_HOUR_2 = 53,
    VOC_TMR_OFF_HOUR_3 = 54,
    VOC_TMR_OFF_HOUR_4 = 55,
    VOC_TMR_OFF_HOUR_5 = 56,
    VOC_TMR_OFF_CANCEL = 57,

    VOC_FAN_SPD_SILENT = 61,
    VOC_FAN_SPD_LOW    = 62,
    VOC_FAN_SPD_MED    = 63,
    VOC_FAN_SPD_HIGH   = 64,
    VOC_FAN_SPD_ULTRA  = 65,
    VOC_FAN_SPD_AUTO   = 66,

    VOC_SWING_LR_START = 71,
    VOC_SWING_LR_STOP  = 72,
    VOC_SWING_UD_START = 73,
    VOC_SWING_UD_STOP  = 74,

    VOC_MODE_COOL = 81,
    VOC_MODE_DRY = 82,
    VOC_MODE_HEAT = 83,
    VOC_MODE_AUTO = 84,
    VOC_MODE_FAN = 85
}voc_cmd_t;



/*******************************************************************************
 Exported global functions
*******************************************************************************/

void voice_main(void);
void build_voice_command(voc_cmd_t cmdId, unsigned char *cmdBuf);
void send_cmd_2_IDU(unsigned char* cmd_buf);
void *my_memset(void *src_buf, int c,  unsigned int len);
unsigned char HexToASCII(unsigned char u8Value);
#endif /* VOICE_MAIN_H */

/*******************************************************************************
 End Of File
*******************************************************************************/
