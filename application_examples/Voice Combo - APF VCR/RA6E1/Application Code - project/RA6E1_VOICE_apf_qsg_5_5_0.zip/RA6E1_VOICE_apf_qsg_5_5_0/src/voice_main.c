/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer *
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/*******************************************************************************
 Include
*******************************************************************************/

#include "voice_main.h"
#include "hal_data.h"

#include "DSpotter/include/base_types.h"
#include "DSpotter/include/Convert2TransferBuffer.h"
#include "DSpotter/include/DSpotterSDKApi_Const.h"
#include "DSpotter/include/DSpotterSDKApi.h"
#include "DSpotter/include/DSpotterSDTrainApi.h"
#include "DSpotter/include/R48Kto16K.h"
#include "DSpotter/include/RingBuffer.h"
#include "DSpotter/include/AGCApi.h"
#include "DSpotter/include/CybVADApi.h"

#include "DSpotter/DbgTrace.h"
#include "DSpotter/UartMgr.h"
#include "DSpotter/FlashMgr.h"
#include "DSpotter/CybModelInfor.h"

#include "AudioRecord.h"
#include "BfNSupp.h"

/*******************************************************************************
 Macro definitions
*******************************************************************************/

/** Data flash */
#define FLASH_DF_BLOCK_ADDRESS(nBlockIndex)     (BYTE*)(FLASH_DF_BLOCK_BASE_ADDRESS + nBlockIndex*FLASH_DF_BLOCK_SIZE)
#define FLASH_DF_TOTAL_BLOCKS                   (FLASH_DF_SIZE/FLASH_DF_BLOCK_SIZE)

#define DSPOTTER_LICENSE_MAX_SIZE               256
#define FLASH_DSPOTTER_ADDRESS_OFFSET           0
#define FLASH_DSPOTTER_BLOCK_INDEX              ((FLASH_DSPOTTER_ADDRESS_OFFSET + FLASH_DF_BLOCK_SIZE - 1)/FLASH_DF_BLOCK_SIZE)
#define FLASH_DSPOTTER_BLOCK_COUNT              ((DSPOTTER_LICENSE_MAX_SIZE + FLASH_DF_BLOCK_SIZE - 1)/FLASH_DF_BLOCK_SIZE)

/** DSpotter */
#define DSPOTTER_MEM_SIZE_1      50000                   // Please modify this number by the return value of DSpotter_GetMemoryUsage_XXX().
#define MAX_COMMAND_TIME         (8000/10)               // Trigger and command must be spoke in 8000 ms (800 frames).
#define DSPOTTER_FRAME_SIZE      960                     // DSpotter compute every 30 ms.
#define RECORD_FRAME_SIZE        320                     // Must be multiple times of 4, 320 is equal to 10 ms data. Must be 320 for VAD.
#define RECORD_FRAME_SAMPLES     (RECORD_FRAME_SIZE/2)
#define UART_FRAME_TRANSFER_SIZE (RECORD_FRAME_SIZE*5/4) // Every 4-bytes data add one checksum byte
#define RBUF_SIZE_CACHE          (320*VAD_CACHE_FRAME_COUNT)  // Cache ring buffer size 10*VAD_CACHE_FRAME_COUNT ms).
#define VOLUME_SCALE_RECONG      3200                    // The AGC volume scale percentage for recognition. It depends on original microphone data.
#define VOLUME_SCALE_VOICE_TAG   800                     // The AGC volume scale percentage for record voice tag (near field).
#define COMMAND_STAGE_TIME_MIN   6000                    // When no result at command recognition stage, the minimum recording time in ms.
#define COMMAND_STAGE_TIME_MAX   8000                    // When no result at command recognition stage, the maximum recording time in ms.
#define AGC_MEM_SIZE             64                      // AGC memory size.

int voice_result_cb(int nCmdID, int nActiveGroupIndex) __attribute__ ((weak, alias("voice_result_cb_weak")));

void audio_record_main(void);

/*******************************************************************************
 Private global functions
*******************************************************************************/

static bool     voice_loop(void);
static void     voice_init(void);
static void     voice_release(void);
static bool     ds_decode_init(void);
static int      TestByteOrder();
static void     SetDSpotter(HANDLE hCyModel, int nGroupIndex, BYTE *pbyaDSpotterMem, int nMemSize, HANDLE *phDSpotter);

extern unsigned int uCYModel1Begin;
extern unsigned int uCYModel1End;


/*******************************************************************************
 Private global variables
*******************************************************************************/

static HANDLE   g_hDSpotter1 = NULL;
static BYTE     g_byaDSpotterMem1[DSPOTTER_MEM_SIZE_1];     // The memory for DSpotter engine.
static HANDLE   g_hCybModel1 = NULL;
static BYTE     g_byaCybModelMem1[CYBMODEL_GET_MEM_USAGE()];// The memory for g_hCybModel1 engine.
static volatile int g_nActiveGroupIndex;
static HANDLE   g_hAGC = NULL;
static BYTE     g_byaAGCMem[AGC_MEM_SIZE];

static int      g_nGroupCount;

#ifdef SUPPORT_UART_DUMP_RECORD
static volatile bool g_bUartSendRecord = false;
static BYTE     g_byaTxBuffer[UART_FRAME_TRANSFER_SIZE];
static BYTE     g_byaUartRxBuffer[1];
static void     OnDataReadCompleteCallback(void);
#endif

static int bfnsupp_obuf[RECORD_FRAME_SAMPLES];
static int bfnsupp_ibuf[RECORD_FRAME_SAMPLES];

static BfNSupp_t bfNSuppData;
//BfNSupp_t bfNSuppData;

extern bool bfnsupp_disabled;
extern int bfnsupp_state;

#define LED_OFF (1)
#define LED_ON (0)


// higher values => more attenuation
void NsSetmaxGain(BfNSupp_t *p, double val)
{
   if(p->init!=1)return;

   p->nsupp.nsGain0.p_factmaxGain = DBL2CT(val);
   p->nsupp.nsGain1.p_factmaxGain = DBL2CT(val);
   p->nsupp.nsGain2.p_factmaxGain = DBL2CT(val);
   p->nsupp.nsGain3.p_factmaxGain = DBL2CT(val);

}

// lower values => more attenuation
void NsSetNoiseThresh(BfNSupp_t *p, double val)
{
   if(p->init!=1)return;

   p->nsupp.nsGain0.p_factNoiseThresh = DBL2CT(val);
   p->nsupp.nsGain1.p_factNoiseThresh = DBL2CT(val);
   p->nsupp.nsGain2.p_factNoiseThresh = DBL2CT(val);
   p->nsupp.nsGain3.p_factNoiseThresh = DBL2CT(val);
}


/*******************************************************************************
* Function Name   : voice_main
* Description     : Voice application main process
* Arguments       : none
* Return value    : none
*******************************************************************************/
void voice_main(void)
{
    int nRet = true;
    voice_init();

    while (true == nRet)
    {
        nRet = voice_loop();
        audio_record_main();
    }

    //Go to here when DSPOTTER_ERR_Expired (over trial limit).
    voice_release();
}
/*******************************************************************************
 End of function voice_main
*******************************************************************************/

/*******************************************************************************
* Function Name: voice_init
* Description  : Initialize
* Arguments    : none
* Return Value : none
*******************************************************************************/
static void voice_init(void)
{
    fsp_err_t   err = FSP_SUCCESS;

    /** UART for DSpotter */
    err = UartOpen(&g_uart_ds, g_uart_ds.p_cfg->channel, -1);   //baud rate: use configuration.xml setting
    if (FSP_SUCCESS != err)
        DBGTRACE("Failed to open UART %d! error: %d\r\n", g_uart_ds.p_cfg->channel, err);

//    /** LED */
//    R_IOPORT_PinWrite(&g_ioport_ctrl, LED_R, OFF);     //Red     = OFF
//    R_IOPORT_PinWrite(&g_ioport_ctrl, LED_G, OFF);     //Green   = OFF
//    R_IOPORT_PinWrite(&g_ioport_ctrl, LED_Y, OFF);     //Yellow  = OFF

    //DBG_UART_TRACE("voice_init() Start\r\n");

    /** Cyberon DSpotter */
    ds_decode_init();

    err = AudioRecordInit();
    if (FSP_SUCCESS != err)
        __asm("BKPT #0\n");

    err = AudioRecordStart();
    if (FSP_SUCCESS != err)
        __asm("BKPT #0\n");

    // BFNsupp Inits
    BfNSuppInit((BfNSupp_t*)&bfNSuppData);
    FracDelaySetDelay((FracDelay_t*)&bfNSuppData.beamForm.fracDelay, 2, 0.3323);

    //DBG_UART_TRACE("voice_init() End\r\n");
}
/*******************************************************************************
 End of function voice_init
*******************************************************************************/

/*******************************************************************************
* Function Name   : voice_loop
* Description     : Voice application process
* Arguments       : none
* Return value    : none
*******************************************************************************/
static bool voice_loop(void)
{
    short   saRecordSample[RECORD_FRAME_SAMPLES];
    int     nRet1 = DSPOTTER_ERR_NeedMoreSample;
    static  int s_nRBufLostCount = 0;
    static  int s_nCommandRecordSample = 0;
    static  int s_nCommandRecognizeLimit = COMMAND_STAGE_TIME_MIN;

#ifdef SUPPORT_UART_DUMP_RECORD
    // Process UART read.
    if (!UartIsReading())
    {
    	UartAsyncRead(g_byaUartRxBuffer, 1, OnDataReadCompleteCallback);
    }

#endif

    if (AudioRecordGetDataSize() < RECORD_FRAME_SIZE)
    {
        return true;
    }

    if (s_nRBufLostCount != AudioRecordGetLostCount())
    {
        s_nRBufLostCount = AudioRecordGetLostCount();
        DBG_UART_TRACE("Lost = %d.\r\n", s_nRBufLostCount);
    }

    // Get recognize data from recognize ring buffer.
    if (AudioRecordGetData((void*)saRecordSample, RECORD_FRAME_SIZE) != 0)
        DBG_UART_TRACE("AudioRecordGetData() problem \r\n");

    AGC_Do(g_hAGC, saRecordSample, RECORD_FRAME_SAMPLES, saRecordSample);

    // state0: 7a with nsupp
    // state1: 7a with bfnsupp
    if( (bfnsupp_state==0) || (bfnsupp_state==1))
	{
		BfNSuppSetMode((BfNSupp_t*)&bfNSuppData, 5); // BF done before AGC, disabled during 2nd call
		NsSetmaxGain((BfNSupp_t*)&bfNSuppData, 0.99);
		NsSetNoiseThresh((BfNSupp_t*)&bfNSuppData, 0.50);
		NSuppSetNoiseGainTrgt((BfNSupp_t*)&bfNSuppData, 0.25);
		bfnsupp_disabled = false;
	}
	else if(bfnsupp_state==2)
	{
		bfnsupp_disabled = true;
	}
	else
	{
		bfnsupp_state = 0; // reset
		bfnsupp_disabled = false;
	}
	
	R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_13, bfnsupp_state&1);
	
    if(!bfnsupp_disabled)
    {
        for(int i=0;i<RECORD_FRAME_SAMPLES;i++)
        {
            bfnsupp_ibuf[i] = saRecordSample[i];
            bfnsupp_ibuf[i] = bfnsupp_ibuf[i]<<16; // MSB Align data
        }

        int32_t *iPtr1 = (int32_t*)&bfnsupp_ibuf[0];
        int32_t *oPtr  = (int32_t*)&bfnsupp_obuf[0];

        // split up the Bf and Nsupp processing around the AGC
        // Bf needs to run before AGC to assure mic level differences are not introduced by AGC
        // Nsupp needs to run after AGC to prevent that AGC re-amplifies noise

        //BfNSuppProcBlock((BfNSupp_t*)&bfNSuppData, iPtr1, iPtr1, oPtr, RECORD_FRAME_SAMPLES);

        NSuppProcBlock((BfNSupp_t*)&bfNSuppData, iPtr1, oPtr, RECORD_FRAME_SAMPLES);

        for(int i=0;i<RECORD_FRAME_SAMPLES;i++)
        {
            saRecordSample[i] = (short)(bfnsupp_obuf[i]>>16);
        }
    }//bfnsupp_disabled

#ifdef SUPPORT_UART_DUMP_RECORD
    if (g_bUartSendRecord)
    {
        int nTransferSize;
        UartWaitWriteReady();
        nTransferSize = Convert2TransferBuffer((BYTE *)saRecordSample, RECORD_FRAME_SIZE, g_byaTxBuffer, sizeof(g_byaTxBuffer), eFourByteDataOneChecksum);
        UartAsyncWrite(g_byaTxBuffer, (uint32_t)nTransferSize);
    }
#endif

    if (0 == g_nGroupCount)
        return true;

    // DSpotter AddSample
    nRet1 = DSpotter_AddSample(g_hDSpotter1, saRecordSample, RECORD_FRAME_SAMPLES);
    if (nRet1 == DSPOTTER_SUCCESS)
    {
        int  nCmdIndex, nCmdScore, nCmdSGDiff, nCmdEnergy, nMapID = -1;
        char szCommand[32];

        if (nRet1 == DSPOTTER_SUCCESS)
        {
            DSpotter_GetResultScore(g_hDSpotter1, &nCmdScore, &nCmdSGDiff, NULL);
            nCmdIndex = DSpotter_GetResult(g_hDSpotter1);
            nCmdEnergy = DSpotter_GetCmdEnergy(g_hDSpotter1);

            CybModelGetCommandInfo(g_hCybModel1, g_nActiveGroupIndex, nCmdIndex, szCommand, sizeof(szCommand), &nMapID, NULL);
            #ifdef NOT_SHOW_MULTI_PRONUNCIATION
            if (strchr(szCommand, '^') != NULL)
                strchr(szCommand, '^')[0] = '\0';
            #endif
            DBG_UART_TRACE("Get command(%d) : %s, Score=%d, SG_Diff=%d, Energy=%d, MapID=%d\r\n",
                    nCmdIndex, szCommand, nCmdScore, nCmdSGDiff, nCmdEnergy, nMapID);
        }

        DSpotter_Reset(g_hDSpotter1);
        DBG_UART_TRACE("\r\n");

        int nNextGroup = voice_result_cb(nMapID, g_nActiveGroupIndex);
        
        if (nNextGroup != g_nActiveGroupIndex)
        {
            if (nNextGroup >= g_nGroupCount)
            {
                nNextGroup = 0;
            }

            s_nCommandRecordSample = 0;
            s_nCommandRecognizeLimit = COMMAND_STAGE_TIME_MIN;

            SetDSpotter(g_hCybModel1, nNextGroup, g_byaDSpotterMem1, sizeof(g_byaDSpotterMem1), &g_hDSpotter1);
        }
    }
    else if (nRet1 == DSPOTTER_ERR_NeedMoreSample && g_nActiveGroupIndex > GROUP_INDEX_TRIGGER)
    {
        // Check timeout for command recognition mode
        s_nCommandRecordSample += (int)(RECORD_FRAME_SIZE/sizeof(short));
        if (s_nCommandRecordSample > 16000 / 1000 * s_nCommandRecognizeLimit)
        {
            if (DSpotter_IsKeywordAlive(g_hDSpotter1))
            {
                if (s_nCommandRecognizeLimit < COMMAND_STAGE_TIME_MAX)
                {
                    s_nCommandRecognizeLimit += 500;
                    return true;
                }
            }
            DBG_UART_TRACE("Timeout for command stage, switch to trigger stage.\r\n");
            s_nCommandRecognizeLimit = COMMAND_STAGE_TIME_MIN;

            SetDSpotter(g_hCybModel1, GROUP_INDEX_TRIGGER, g_byaDSpotterMem1, sizeof(g_byaDSpotterMem1), &g_hDSpotter1);
        }
    }
    else if (nRet1 == DSPOTTER_ERR_Expired)
    {
//        DBG_UART_TRACE("The trial version DSpotter reach the max trial usage count, please reset system.\r\n");
//        R_IOPORT_PinWrite(&g_ioport_ctrl, LED_G, OFF);     //Green   = OFF
//        R_IOPORT_PinWrite(&g_ioport_ctrl, LED_R, OFF);     //Red     = OFF
//        R_IOPORT_PinWrite(&g_ioport_ctrl, LED_Y, OFF);     //Yellow  = OFF

        return false;
    }
    else
    {}

    return true;
}
/*******************************************************************************
 End of function voice_loop
*******************************************************************************/

/*******************************************************************************
* Function Name: voice_release
* Description  : Release resource
* Arguments    : none
* Return Value : none
*******************************************************************************/
static void voice_release(void)
{
    AudioRecordRelease();

    DSpotter_Release(g_hDSpotter1);
    g_hDSpotter1 = NULL;
    CybModelRelease(g_hCybModel1);
    g_hCybModel1 = NULL;

    AGC_Release(g_hAGC);
    g_hAGC = NULL;

    UartClose();
}
/*******************************************************************************
 End of function voice_release
*******************************************************************************/

static int TestByteOrder()
{
    short nTestWord = 0x0001;      //Little endian memory is 0x01 0x00, big endian memory is 0x00 0x01.
    char *b = (char *)&nTestWord;  //Little endian b[0] is 0x01, big endian memory b[0] is 0x00.
    return (int)b[0];              //Return 1/0 for little/big endian.
}

static void SetDSpotter(HANDLE hCybModel, int nGroupIndex, BYTE *pbyaDSpotterMem, int nMemSize, HANDLE *phDSpotter)
{
    int nRet = DSPOTTER_ERR_IllegalParam;
    BYTE *lppbyModel[2];
    int nModelCount = 1;

    if (phDSpotter != NULL)
    {
        DSpotter_Release(*phDSpotter);
        *phDSpotter = NULL;
    }

    /*
     * For official version of DSpotter, DSpotter_Init_Multi() will use the data flash API and
     * its instance to check license. In configuration.xml, please:
     *   1. Add r_flash_hp component.
     *   2. Add Flash Driver stack, named "g_flash0" and set callback as "flash0_bgo_callback".
     * For RA6M1, The data flash address start at 0x40100000U, total 128 blocks, each block has
     * 64 bytes, total 8K bytes. DSpotter need 256 bytes(4 blocks) to save license information.
     * So, the valid flash address is FLASH_DF_BLOCK_ADDRESS(0) ~ FLASH_DF_BLOCK_ADDRESS(123).
    */
    if (FLASH_DSPOTTER_BLOCK_INDEX + FLASH_DSPOTTER_BLOCK_COUNT > FLASH_DF_TOTAL_BLOCKS)
    {
        DBG_UART_TRACE("FLASH_DSPOTTER_BLOCK_INDEX error!\r\n");
        __asm("BKPT #0\n");
    }

    lppbyModel[0] = (BYTE*)CybModelGetGroup(hCybModel, nGroupIndex);
    *phDSpotter = DSpotter_Init_Multi((BYTE *)CybModelGetBase(hCybModel), lppbyModel, nModelCount, MAX_COMMAND_TIME,
                                      pbyaDSpotterMem, nMemSize, FLASH_DF_BLOCK_ADDRESS(FLASH_DSPOTTER_BLOCK_INDEX), FLASH_DF_BLOCK_SIZE, &nRet);

    if (*phDSpotter == NULL)
    {
        DBG_UART_TRACE("DSpotter_Init_XXX() fail, error = %d!\r\n", nRet);
        __asm("BKPT #0\n");
    }
    else
    {
        DBG_UART_TRACE("%s group active.\r\n", nGroupIndex == 0 ? "Wake-up" : "Command");

        char szCommand[32];
        int  nMapID;
        for (int i = 0; i < CybModelGetCommandCount(hCybModel, nGroupIndex); i++)
        {
            CybModelGetCommandInfo(hCybModel, nGroupIndex, i, szCommand, sizeof(szCommand), &nMapID, NULL);
            if (strlen(szCommand) > 0)
            {
                #ifdef NOT_SHOW_MULTI_PRONUNCIATION
                if (strchr(szCommand, '^') != NULL)
                    continue;
                #endif
                DBG_UART_TRACE("    %s, Map ID = %d\r\n", szCommand, nMapID);
            }
        }
        DBG_UART_TRACE("\r\n");
    }
    g_nActiveGroupIndex = nGroupIndex;
}

static bool ds_decode_init(void)
{
    const bsp_unique_id_t   *devi_uniq_id;
    BYTE *lppbyModel[1];
//    int  nGroupCount;
    char szCommand[32];
    int  nMapID;
    int  nMemSize;
//    int  nRecogGroupIndex;

    //DBG_UART_TRACE("ds_decode_init() Begin\r\n");
    /** Memory size check, device authentication and ring buffer initialization */
    // Get unique ID
    devi_uniq_id = R_BSP_UniqueIdGet();

    int nByteOrder = TestByteOrder();
    DBG_UART_TRACE("%s\r\n", nByteOrder == 1 ? "Little Endian" : "Big Endian");
    DBG_UART_TRACE("MCU board: %s\r\n", MCU_BOARD_STRING);
    DBG_UART_TRACE("FSP version: %d.%d\r\n", FSP_VERSION_MAJOR, FSP_VERSION_MINOR);
    DBG_UART_TRACE("DSpotter version: %s", DSpotter_VerInfo());
    DBG_UART_TRACE("Sample code build: %s\r\n", SAMPLE_CODE_BUILD_BUM);
    DBG_UART_TRACE("Unique ID: 0x%04X-%04X-%04X-%04X\r\n", devi_uniq_id->unique_id_words[0],
            devi_uniq_id->unique_id_words[1], devi_uniq_id->unique_id_words[2], devi_uniq_id->unique_id_words[3]);

    if (nByteOrder == 0)
    {
        DBG_UART_TRACE("The DSpotter use Renesas RA default compile setting: CM4/HardFPU/little endian, not big endian!\r\n");
        return false;
    }

    if (&uCYModel1Begin == &uCYModel1End)
    {
        DBG_UART_TRACE("No DSpotter model found!\r\n\r\n");
        return true;
    }

    g_hCybModel1 = CybModelInit((const BYTE*)&uCYModel1Begin, g_byaCybModelMem1, sizeof(g_byaCybModelMem1), NULL);

    // Check memory for every group and show their commands.
    HANDLE hCybModel = g_hCybModel1;
    int nDSpotterMem = (int)sizeof(g_byaDSpotterMem1);

    DBG_UART_TRACE("This DSpotter model declares memory buffer size = %d\r\n", nDSpotterMem);
    g_nGroupCount = CybModelGetGroupCount(hCybModel);
    for (int nGroup = 0; nGroup < g_nGroupCount; nGroup++)
    {
        lppbyModel[0] = (BYTE*)CybModelGetGroup(hCybModel, nGroup);
        nMemSize = DSpotter_GetMemoryUsage_Multi((BYTE *)CybModelGetBase(hCybModel), lppbyModel, 1, MAX_COMMAND_TIME);
        DBG_UART_TRACE("The DSpotter model, group %d needs working memory size = %d\r\n", nGroup, nMemSize);
        if (nDSpotterMem < nMemSize)
        {
            DBG_UART_TRACE("The DSpotter model requires more memory than available in the buffer!\r\n");
            __asm("BKPT #0\n");
        }

        DBG_UART_TRACE("Command list for group index %d: \r\n", nGroup);
        for (int i = 0; i < CybModelGetCommandCount(hCybModel, nGroup); i++)
        {
            CybModelGetCommandInfo(hCybModel, nGroup, i, szCommand, sizeof(szCommand), &nMapID, NULL);
            if (strlen(szCommand) > 0)
            {
                #ifdef NOT_SHOW_MULTI_PRONUNCIATION
                if (strchr(szCommand, '^') != NULL)
                    continue;
                #endif
                DBG_UART_TRACE("    %s, Map ID = %d\r\n", szCommand, nMapID);
            }
        }
        DBG_UART_TRACE("\r\n");
    }
    DBG_UART_TRACE("\r\n");

    SetDSpotter(g_hCybModel1, GROUP_INDEX_TRIGGER, g_byaDSpotterMem1, sizeof(g_byaDSpotterMem1), &g_hDSpotter1);

    g_hAGC = AGC_Init(g_byaAGCMem, sizeof(g_byaAGCMem), NULL);
    if (g_hAGC == NULL)
    {
        DBG_UART_TRACE("AGC initial fail!\r\n");
        __asm("BKPT #0\n");
    }
    AGC_SetMaxGain(g_hAGC, VOLUME_SCALE_RECONG/100.0F);

    //DBG_UART_TRACE("ds_decode_init() End\r\n");

    return true;
}

#ifdef SUPPORT_UART_DUMP_RECORD
void OnDataReadCompleteCallback(void)
{
    DBGTRACE("R:%c\r\n", g_byaUartRxBuffer[0]);

    if (g_byaUartRxBuffer[0] == 0x31)
    {
        if (!g_bUartSendRecord)
        {
            g_bUartSendRecord = true;
            DBGTRACE("Start send recording data.\r\n");
        }
    }
    else if (g_byaUartRxBuffer[0] == 0x32)
    {
        if (g_bUartSendRecord)
        {
            g_bUartSendRecord = false;
            DBGTRACE("Stop send recording data.\r\n");
        }
    }

    //Continue to read next byte.
    UartAsyncRead(g_byaUartRxBuffer, 1, OnDataReadCompleteCallback);
}

#endif

int voice_result_cb_weak(int nCmdID, int nActiveGroupIndex);
int voice_result_cb_weak(int nCmdID, int nActiveGroupIndex)
{
    FSP_PARAMETER_NOT_USED(nCmdID);
    FSP_PARAMETER_NOT_USED(nActiveGroupIndex);

    return 0;
}

/*******************************************************************************
 End Of File
*******************************************************************************/
