#include <stdlib.h>
#include "voice_main.h"
#include "hal_data.h"
#include "PortFunction.h"

void SoftwareDelayMillSec(uint32_t delay_in_ms)
{
    R_BSP_SoftwareDelay(delay_in_ms, BSP_DELAY_UNITS_MILLISECONDS);
}

#ifdef INC_FREERTOS_H

void *PortMalloc(size_t size)
{
    void *p;

    p = pvPortMalloc(size);
    if(p==NULL)
    {
        __asm("BKPT #0\n");
    }
    return p;
}

void *PortCalloc(size_t num, size_t size)
{
    void *p;

    /* allocate 'count' objects of size 'size' */
    p = pvPortMalloc(num * size);
    if (p) {
      /* zero the memory */
      memset(p, 0, num * size);
    }
    else
    {
        __asm("BKPT #0\n");
    }
    return p;
}

void *PortRealloc(void *ptr, size_t size)
{
    if (size == 0)
    {
        vPortFree(ptr);
        return NULL;
    }

    void *p;
    p = pvPortMalloc(size);
    if (p) {
        /* zero the memory */
        if (ptr != NULL) {
            memcpy(p, ptr, size);
            vPortFree(ptr);
        }
    }

    return p;
}

void  PortFree(void *ptr)
{
    vPortFree(ptr);
}

#else

void *PortMalloc(size_t size)
{
    return malloc(size);
}

void *PortCalloc(size_t num, size_t size)
{
    return calloc(num, size);
}

void *PortRealloc(void *ptr, size_t size)
{
    return realloc(ptr, size);
}

void  PortFree(void *ptr)
{
    free(ptr);
}

#endif
