/*------------------------------------------------------------------------------
 *                                                                              
 *                   TTTTTTTT                                                   
 *                   TTTTTTTT  T       TTT      TTT   T    TT     TT      T     
 *                       TT    TT      TT TT   TT T   TT   TT    TT       TT    
 *                       T     TT      TT  TT  TT TT  TT    T   TT        TT    
 *              T        T    TTTT    TTT  TT TT  TT  TTT   TT  T    T   TTTT   
 *      TTTT   TTT       T    TT T    TT   TT TT  TT  TTTT  TT TT TTTT   TT T   
 *    TTTTTT  TTTT       T    T  TT   TT  TT  TT  TT  TT TT TT TT    T   T  TT  
 *      TTTTTTTT         T   TTTTTT   TT TT    T  TT  TT  TTTT  TT   T  TTTTTT  
 *      TTTTTTT          T   TT   TT  TTTT     TT T   TT   TTT  TT   T  TT  TTT 
 *      TTTTTTTT         T   TT   TT  TT TT     TTT   TT    TT   TTT T  TT   TT 
 *  TTTTTTTTTTTTT        T   TT   TTT TT  TT    TT    TT     TT    TTT  TT   TTT
 * TTTTTTTTTTTTTT                                                               
 *     TTTTTTTTTT                                                               
 *     TTTTTTT TT                                                               
 *       TTT   T     TTTTTT                                                     
 *        TT         TTTTTT   TT   T  T  T  T  T    T  TT     T     T  TT     TT
 *        TT            T    T    T   T  T  T  T   T T  T    T T   T    TT   TT 
 *        T             T   TTT  T    T  T  TT T  TT T  T   TT T  T      TT TT  
 *                      T   T    T   TTTTT  TTTT  TT T  T   TT T  T TT     TT   
 *                      T   T    T    TT T  T TTT TT T  T   TT T  T  T     T    
 *                      T   TT    T    T T  T  TT  T T  T    T T  TT T     T    
 *                      T    TTT   T   T T  T   T  TT   TTT  TT    TTT     T    
 *                                                                              
 *                                                                              
 *------------------------------------------------------------------------------
 *
 * Copyright (C) 2023 Taronga Technology Inc. Unpublished work.
 * This computer program includes Confidential, Proprietary Information
 * and is a Trade Secret of Taronga Technology Inc. All use, disclosure, 
 * and/or  reproduction is prohibited unless authorized in writing.  
 * All Rights Reserved.
 *------------------------------------------------------------------------------
 */
#ifndef _BIQUADS_H_
#define _BIQUADS_H_


#include "common.h"
#include "logger.hxx"

#define BIQUADS_NR_MAX 12

#define SCALE 1048576

typedef struct BiquadSection_s 
{
    LT      inp;
    LT      out;
    CT4     b0;
    CT4     b1;
    CT4     b2;
    CT4     a1;
    CT4     a2;
    LT      tapFwd[2];
    LT      tapRvs[2];
    LT      fraction;
} BiquadSection_t;


typedef struct BiquadFilter_s 
{
    LT      inp;
    LT      out;
    
    int               nrSections;
    BiquadSection_t   biquad[BIQUADS_NR_MAX];
    CT4               biquadOutGain;           // Extra Gain for biquad output of biquad Path. Type is actualy Q4.28 !!. 
} BiquadFilter_t;



extern void BiquadFilterInit(BiquadFilter_t *p);

extern void BiquadFilterProcess(BiquadFilter_t *p);

extern void BiquadFilterSetCoef(BiquadFilter_t *p, int nrSections, double c[][5], double biqGain);


#endif // _BIQUADS_H_

