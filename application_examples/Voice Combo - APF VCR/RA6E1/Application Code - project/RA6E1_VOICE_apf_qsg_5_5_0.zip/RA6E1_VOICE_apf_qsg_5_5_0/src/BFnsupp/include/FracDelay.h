/*------------------------------------------------------------------------------
 *                                                                              
 *                   TTTTTTTT                                                   
 *                   TTTTTTTT  T       TTT      TTT   T    TT     TT      T     
 *                       TT    TT      TT TT   TT T   TT   TT    TT       TT    
 *                       T     TT      TT  TT  TT TT  TT    T   TT        TT    
 *              T        T    TTTT    TTT  TT TT  TT  TTT   TT  T    T   TTTT   
 *      TTTT   TTT       T    TT T    TT   TT TT  TT  TTTT  TT TT TTTT   TT T   
 *    TTTTTT  TTTT       T    T  TT   TT  TT  TT  TT  TT TT TT TT    T   T  TT  
 *      TTTTTTTT         T   TTTTTT   TT TT    T  TT  TT  TTTT  TT   T  TTTTTT  
 *      TTTTTTT          T   TT   TT  TTTT     TT T   TT   TTT  TT   T  TT  TTT 
 *      TTTTTTTT         T   TT   TT  TT TT     TTT   TT    TT   TTT T  TT   TT 
 *  TTTTTTTTTTTTT        T   TT   TTT TT  TT    TT    TT     TT    TTT  TT   TTT
 * TTTTTTTTTTTTTT                                                               
 *     TTTTTTTTTT                                                               
 *     TTTTTTT TT                                                               
 *       TTT   T     TTTTTT                                                     
 *        TT         TTTTTT   TT   T  T  T  T  T    T  TT     T     T  TT     TT
 *        TT            T    T    T   T  T  T  T   T T  T    T T   T    TT   TT 
 *        T             T   TTT  T    T  T  TT T  TT T  T   TT T  T      TT TT  
 *                      T   T    T   TTTTT  TTTT  TT T  T   TT T  T TT     TT   
 *                      T   T    T    TT T  T TTT TT T  T   TT T  T  T     T    
 *                      T   TT    T    T T  T  TT  T T  T    T T  TT T     T    
 *                      T    TTT   T   T T  T   T  TT   TTT  TT    TTT     T    
 *                                                                              
 *                                                                              
 *------------------------------------------------------------------------------
 *
 * Copyright (C) 2023 Taronga Technology Inc. Unpublished work.
 * This computer program includes Confidential, Proprietary Information
 * and is a Trade Secret of Taronga Technology Inc. All use, disclosure, 
 * and/or  reproduction is prohibited unless authorized in writing.  
 * All Rights Reserved.
 *------------------------------------------------------------------------------
 */
#ifndef _FRACDELAY_H_
#define _FRACDELAY_H_

#include "common.h"
#include "helpfunc.h"
#include "BaseOp.h"
#include "logger.hxx"


#define FD_FRACTION (0.93294)  // constants for fractional delay interpolation - default value, later updated by the application
#define FD_MAX_DLY_LEN  (5)    // to support max 5 samples


typedef struct FracDelay_s
{
   LT   inp;
   LT   out;
   // Parameters
   CT m_Fraction;                // constants for fractional delay interpolation 
   int m_Integer;                // Integer delay value?
   int m_NrCoef;                 // Number of FIR coefficients

   // States
   LT m_DlyBuf[FD_MAX_DLY_LEN];   // DelayLine with previous values
   CT m_Coef[FD_MAX_DLY_LEN];     // Coefficient array for tunable Integer/Fractional delay

   // Internal Parameter
   BOOL useFracFir;
   
} FracDelay_t;

/**
 * @brief FracDelayInit : Initialize the Fracdelay states
 * 
 */
extern void FracDelayInit(FracDelay_t *p);

/**
 * @brief FracDelaySetDelay : set the integer and fractional delay
 * 
 */
extern void FracDelaySetDelay(FracDelay_t *p, int intDelay, double fracDelay);

/**
 * @brief FracDelayProcess : Fraction Delay Processing
 * This is just a linear interpolation of sample [m_Integer-1] and sample[m_Integer], using interpolation fraction m_Fraction. 
 * 
 * Or:
 * out = inp[m_Int]*(1-mFract) + inp[m_Int+1]*m_Fract;
 */
extern void FracDelayProcess(FracDelay_t *p);

/**
 * @brief FracDelayProcess : Fraction Delay Processing
 * We need to calculate a new sample, that lies between sample [m_Integer-1] and sample[m_Integer],
 * at relative distance m_Fraction.
 * 
 * TODO
 */
extern void FracDelayProcessEnh(FracDelay_t *p);


#endif  // _FRACDELAY_H_

