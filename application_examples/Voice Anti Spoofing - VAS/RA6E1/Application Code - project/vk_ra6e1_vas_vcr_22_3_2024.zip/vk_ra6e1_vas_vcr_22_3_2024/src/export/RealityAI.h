/************************************************************************************
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  Copyright (c) Renesas of America, Inc.  All rights reserved.
 *  Use and distribution are subject to applicable contract restrictions.
 * **********************************************************************************/
#ifndef REALITYAI_H_
#define REALITYAI_H_
#include <stdint.h>
#include "RealityAI_Config.h"

#ifdef __cplusplus
extern "C" {
#endif

struct svm_classifier_struct;
typedef struct svm_classifier_struct svm_classifier_struct;

typedef struct {
    uint8_t  sh, exp;
    int32_t  a,b,c,d,e;
}cal_params_t;

typedef struct {
    float    sf;
    int32_t  si;
    int32_t  z;
}cal_data_t;

typedef struct {
    cal_params_t p;
    cal_data_t   x, y;
}svm_int8_cal_t;

#define RAI_FLAGS_TYPE_MASK       0x1
#define RAI_FLAGS_TYPE_SHIFT      0x0
#define RAI_FLAGS_TYPE_CLASSIFY   (0x0 << RAI_FLAGS_TYPE_SHIFT)
#define RAI_FLAGS_TYPE_REGRESSION (0x1 << RAI_FLAGS_TYPE_SHIFT)

#define RAI_FLAGS_QUANT_MASK      0x2
#define RAI_FLAGS_QUANT_SHIFT     0x1
#define RAI_FLAGS_QUANT_DIS       (0x0 << RAI_FLAGS_QUANT_SHIFT)
#define RAI_FLAGS_QUANT_ENA       (0x1 << RAI_FLAGS_QUANT_SHIFT)

struct svm_classifier_struct {
    const uint32_t*         Conv;
    const svm_int8_cal_t*   Cal;
    const void* Beta;
    const void* Bias;
    const void* Mu;
    const void* Sigma;
    const int8_t* coding_matrix;
    const uint8_t* feature_subset ;
    float* learner_scores;                   
    float* Class_scores;
    int32_t window_size;
    int32_t subwindow_size;
    int32_t windows_per_channel;
    int32_t step_size;
    int32_t feature_length;
    int32_t subset_feature_length;
    int32_t num_classes;
    int32_t num_channels;
    int32_t num_learners;
    const int32_t class_index;
    int32_t samples_per_channel;
    int32_t samples_per_channel_p2c;
    const int32_t flags;
    void (*const feature_extractor)(rai_data_t* input_vector,  rai_data_t* output_feature, svm_classifier_struct* model);
};

float  RealityAI_predict(rai_data_t* input_feature, svm_classifier_struct* model);
int    RealityAI_convert(void* usr, rai_data_t* out, int32_t len, svm_classifier_struct* model);

int    RealityAI_classify(rai_data_t* input_vector, svm_classifier_struct* model);
float  RealityAI_regression(rai_data_t* input_feature, svm_classifier_struct* model);
int    RealityAI_get_class_scores(float* scores, int32_t len, int softMaxFlag, svm_classifier_struct* model);
int    RealityAI_get_learner_scores(float* scores, int32_t len, svm_classifier_struct* model);

#ifdef __cplusplus
}
#endif
#endif /* REALITYAI_H_ */
