/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer *
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

#ifndef VOICE_MAIN_H
#define VOICE_MAIN_H

#include "bsp_api.h"

#ifdef RAI_OLD_CAPTURE
#define CFG_SYNC_WORD       (0x53534E52) // 'RNSS' backwards
#define WINLEN 16000
#define SEND_SIZE 16000

typedef struct st_mc_datalog_buf
{
    uint32_t sync_word;
    short data[SEND_SIZE];
} mc_datalog_buf_t;

typedef struct circ_buf{
    short *tail;
    short *head;
    short buff[WINLEN*2];
    int size;
}circ_buf_t;
#endif

/*******************************************************************************
 Include
*******************************************************************************/

/*******************************************************************************
 Macro definitions
*******************************************************************************/

// enable DCDS or revert back to UARTMgr
#define RENESAS_DCDS  (0)
#define UART_LOG      1

// Definition for support function
//#define SUPPORT_UART_DUMP_RECORD                         // Transfer record data through UART(460800 bps) to PC CybSerialRecorder.

#define NOT_SHOW_MULTI_PRONUNCIATION                     // Don't display the command string that include '^' character.

// Definition for group index
#define GROUP_INDEX_TRIGGER      0                       // The group index of trigger.

#if defined(BOARD_RA4E1_VOICE)
    #define MCU_BOARD_STRING                        "VOICE-RA4E1"

    /** Data flash */
    #define FLASH_DF_SIZE                           (8192)

    /** LED for VOICE-RA4E1 */
    #define LED_R                                   BSP_IO_PORT_05_PIN_00
    #define LED_G                                   BSP_IO_PORT_02_PIN_13
    #define LED_B                                   BSP_IO_PORT_02_PIN_12
    #define LED_Y                                   BSP_IO_PORT_00_PIN_00
    #define OFF                                     (BSP_IO_LEVEL_HIGH)
    #define ON                                      (BSP_IO_LEVEL_LOW)
#elif defined(BOARD_RA6E1_VOICE)
    #define MCU_BOARD_STRING                        "VOICE-RA6E1"

    /** Data flash */
    #define FLASH_DF_SIZE                           (8192)

    /** LED for VOICE-RA6E1 */
    #define LED_R                                   BSP_IO_PORT_05_PIN_00
    #define LED_G                                   BSP_IO_PORT_04_PIN_00
    #define LED_B                                   BSP_IO_PORT_01_PIN_13
    #define LED_Y                                   BSP_IO_PORT_00_PIN_00
    #define OFF                                     (1U)
    #define ON                                      (0U)
#endif

#define FLASH_DF_BLOCK_SIZE                         ((signed) BSP_FEATURE_FLASH_HP_DF_BLOCK_SIZE)
#define FLASH_DF_BLOCK_BASE_ADDRESS                 (BSP_FEATURE_FLASH_DATA_FLASH_START)

#define SAMPLE_CODE_BUILD_BUM                       "210312"

/*******************************************************************************
 Exported global variables
*******************************************************************************/

/*******************************************************************************
 Exported global functions
*******************************************************************************/

void voice_main(void);

#endif /* VOICE_MAIN_H */

/*******************************************************************************
 End Of File
*******************************************************************************/
