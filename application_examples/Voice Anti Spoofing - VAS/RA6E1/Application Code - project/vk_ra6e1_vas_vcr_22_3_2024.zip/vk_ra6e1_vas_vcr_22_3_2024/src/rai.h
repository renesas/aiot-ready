#ifndef RAI_H_
#define RAI_H_
#include <stdint.h>
#include "bsp_api.h"
#include "hal_data.h"
#include "DbgTrace.h"
#include "spoof_c1_f32_f32_model.h"

#define RAI_ENABLE             1
#define RAI_USE_FIR            1
#define RAI_DECIMATION         4

#define RAI_REC_FRAME_LEN      (160)      /* RECORD_FRAME_SAMPLES in voice_main.c */
#define RAI_REC_BUF_LEN        (4000U)    /* 1sec recording length @ 8ksps */
#define RAI_FRAME_BUF_LEN      (4096U)    /* DC frame buffer length and RAI window length */

#define RAI_RECORD_BUF_LEN     (RAI_REC_BUF_LEN + RAI_REC_BUF_LEN/2)
#define RAI_RECORD_BUF_SIZE    (RAI_RECORD_BUF_LEN*2)
#define RAI_FRAME_BUF_SIZE     (RAI_FRAME_BUF_LEN*2)
#define RAI_REC_FRAME_SIZE     (RAI_REC_FRAME_LEN*2)
#define RAI_REC_FRAME_DEC_LEN  (RAI_REC_FRAME_LEN/RAI_DECIMATION)
#define RAI_REC_FRAME_DEC_SIZE (RAI_REC_FRAME_DEC_LEN*2)
#define RAI_WORKING_BUF_SIZE   (RAI_WORKING_BUF_LEN*2)

#define FIR_NUM_TAPS            (64U)
#define FIR_BUF_LEN             (FIR_NUM_TAPS + RAI_REC_FRAME_LEN - 1)
#define FIR_BUF_SIZE            (FIR_BUF_LEN*2)

#ifndef MAX
#define MAX(a,b) ((a) > (b) ? (a) : (b))
#endif

#ifndef MIN
#define MIN(a,b) ((a) < (b) ? (a) : (b))
#endif

enum {
    DCDS_FLAG_SHIP  = 0x1,
    DCDS_FLAG_INFER = 0x2,
};


int    rai_init(void);
int    rai_write(uint8_t* buf);
int    rai_inference(void);

#endif // RAI_H_
