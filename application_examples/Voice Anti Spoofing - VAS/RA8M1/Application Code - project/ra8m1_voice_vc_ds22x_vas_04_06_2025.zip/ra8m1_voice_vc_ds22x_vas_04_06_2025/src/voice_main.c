/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer *
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/*******************************************************************************
 Include
*******************************************************************************/

#include "rai.h"
#include "voice_main.h"
#include "hal_data.h"
#ifdef _FREERTOS_
#include "FreeRTOS.h"
#include "task.h"
#endif

#include "base_types.h"
#include "DSpotterSDKApi_Const.h"
#include "DSpotterSDKApi.h"
#include "DSpotterSDTrainApi.h"
#include "RingBuffer.h"
#include "AGCApi.h"

#include "Convert2TransferBuffer.h"
#include "DbgTrace.h"
#include "UartMgr.h"
#include "FlashMgr.h"
#include "PortFunction.h"
#include "CybModelInfor.h"
#include "Model/CybModel1.h"
#ifdef SUPPORT_RECOG_TWO_MODEL
	#include "Model/CybModel2.h"
#endif

#if defined(SUPPORT_SPEEX_PLAY)
	#include "Speex/PlaySpeex.h"
	#include "Model/SpeexData1.h"
	#ifdef SUPPORT_RECOG_TWO_MODEL
		#include "Model/SpeexData2.h"
	#endif
#endif
static void PlaySpeexByID(int nSpeexData, int nMapID);

#include "AudioRecord.h"

/*******************************************************************************
 Macro definitions
*******************************************************************************/

/** Data flash */
#define FLASH_DF_BLOCK_ADDRESS(nBlockIndex)     (BYTE*)(FLASH_DF_BLOCK_BASE_ADDRESS + nBlockIndex*FLASH_DF_BLOCK_SIZE)
#define FLASH_DF_TOTAL_BLOCKS                   (FLASH_DF_SIZE/FLASH_DF_BLOCK_SIZE)

#define DSPOTTER_LICENSE_MAX_SIZE               256
#define FLASH_DSPOTTER_ADDRESS_OFFSET           0
#define FLASH_DSPOTTER_BLOCK_INDEX              ((FLASH_DSPOTTER_ADDRESS_OFFSET + FLASH_DF_BLOCK_SIZE - 1)/FLASH_DF_BLOCK_SIZE)
#define FLASH_DSPOTTER_BLOCK_COUNT              ((DSPOTTER_LICENSE_MAX_SIZE + FLASH_DF_BLOCK_SIZE - 1)/FLASH_DF_BLOCK_SIZE)

/** DSpotter */
#define DSPOTTER_MEM_SIZE_1      50000               // Please modify this number by the return value of DSpotter_GetMemoryUsage_XXX().


#define DSPOTTER_MEM_SIZE_2      50000                   // Please modify this number by the return value of DSpotter_GetMemoryUsage_XXX().

#ifndef MAX_COMMAND_TIME
#define MAX_COMMAND_TIME         (8000/10)               // Trigger and command must be spoke within 8000 milli-second (800 frames).
#endif
#define DSPOTTER_FRAME_SIZE      960                     // DSpotter compute every 30 milli-second.
#define RECORD_FRAME_SIZE        960                     // Must be multiple times of 4, 320 is equal to 10 milli-second data.
#define RECORD_FRAME_SAMPLES     (RECORD_FRAME_SIZE/2)
#if AUDIO_RECORD == AUDIO_RECORD_AMIC
    #define VOLUME_SCALE_RECONG      1600                // The AGC volume scale percentage for recognition. It depends on original microphone data.
#else
    #define VOLUME_SCALE_RECONG      3200                // The AGC volume scale percentage for recognition. It depends on original microphone data.
#endif
#define VOLUME_SCALE_VOICE_TAG   400                     // The AGC volume scale percentage for record voice tag (near field).
#define COMMAND_STAGE_TIME_MIN   6000                    // When no result at command recognition stage, the minimum recording time in milli-second.
#define COMMAND_STAGE_TIME_MAX   8000                    // When no result at command recognition stage, the maximum recording time in milli-second.
#define VOICE_TAG_MAX_TIME       2200                    // The max speech time of a voice tag in milli-second.
#define VOICE_TAG_VOICE_SIZE     (1024*16*VOICE_TAG_MAX_TIME/3000)  // According SDK document, voice tag length can be 3000*12/16 milli-second.
#define VOICE_TAG_MODEL_SIZE     5120                    // Voice tag model, it has 340B header(H) and 400B for each voice tag(T).
#define AGC_MEM_SIZE             64                      // AGC memory size.
#define RECORD_VOICE_TAG_ID      10000                   // It shall be same as the defined value in DSMT project.
#define DELETE_VOICE_TAG_ID      10001                   // It shall be same as the defined value in DSMT project.
#define DELETE_ALL_VOICE_TAG_ID  10002                   // It shall be same as the defined value in DSMT project.

/*******************************************************************************
 Private global functions
*******************************************************************************/
extern int rai_pred;
//int voice_result_cb(int nCmdID, int nActiveGroupIndex) __attribute__ ((weak, alias("voice_result_cb_weak")));

static bool     voice_loop(void);
static void     voice_init(void);
static void     voice_release(void);
static bool     ds_decode_init(void);
static int      TestByteOrder();
static void     InitDSpotter(HANDLE hCyModel, int nGroupIndex, BYTE *pbyaDSpotterMem, int nMemSize, HANDLE *phDSpotter, BOOL bShowInfo);
static void     ReleaseDSpotter(HANDLE *lphDSpotter);
static void     SelectGroupModel(HANDLE hCyModel, int nGroupIndex, HANDLE hDSpotter, BOOL bShowInfo);
static void     PrintGroupCommandList(HANDLE hCybModel, int nGroupIndex);
static void     OnDataReadCompleteCallback(void);
static BOOL     CheckGroupHasID(HANDLE hDSpotter, HANDLE hCybModel, int nGroupIndex, int nMapID);


/*******************************************************************************
 Private global variables
*******************************************************************************/

// To avoid crash problem when we access data flash with this default secure setting ”Set TrustZone secure/non-secure boundaries = Yes”,
// we declare the following global array and modify script/fsp.ld: ".data_flash :" => ".data_flash (NOLOAD):".
BSP_PLACE_IN_SECTION(".data_flash") const uint8_t CybLicense[FLASH_DF_SIZE];

static HANDLE   g_hDSpotter1 = NULL;
static BYTE     g_byaDSpotterMem1[DSPOTTER_MEM_SIZE_1];     // The memory for DSpotter engine.
static HANDLE   g_hCybModel1 = NULL;
static BYTE     g_byaCybModelMem1[CYBMODEL_GET_MEM_USAGE()];// The memory for g_hCybModel1 engine.
static volatile int g_nActiveGroupIndex;
static HANDLE   g_hAGC = NULL;
static BYTE     g_byaAGCMem[AGC_MEM_SIZE];
static int      g_nRecordFrameCount = 0;
static volatile bool g_bUartCheckAlive = false;
static BYTE     g_byaUartRxBuffer[1];
static volatile bool g_bVoiceTagRecording = false;
static volatile bool g_bVoiceTagDeleting = false;
static int      g_nGroupCount;


#ifdef SUPPORT_UART_DUMP_RECORD
	#define ALIGN(num, size)         (((num) + (size) - 1) / (size) * (size))
	#define CHECKSUM_TYPE  eFourByteDataOneChecksum
	static volatile bool g_bUartSendRecord = false;
	#if (CHECKSUM_TYPE == eTwoByteDataOneChecksum)
		static BYTE     g_byaTxBuffer[ALIGN(RECORD_FRAME_SIZE*3/2, 32)]; //Align the UART TX buffer to be multiple of 32-byte
	#elif (CHECKSUM_TYPE == eFourByteDataOneChecksum)
		static BYTE     g_byaTxBuffer[ALIGN(RECORD_FRAME_SIZE*5/4, 32)]; //Align the UART TX buffer to be multiple of 32-byte
	#endif
#endif

#ifdef SUPPORT_RECOG_TWO_MODEL
static HANDLE   g_hDSpotter2 = NULL;
static BYTE     g_byaDSpotterMem2[DSPOTTER_MEM_SIZE_2];     // The memory for DSpotter engine.
static HANDLE   g_hCybModel2 = NULL;
static BYTE     g_byaCybModelMem2[CYBMODEL_GET_MEM_USAGE()];// The memory for g_hCybModel2 engine.
#endif


/*******************************************************************************
* Function Name   : voice_main
* Description     : Voice application main process
* Arguments       : none
* Return value    : none
*******************************************************************************/
void voice_main(void)
{
    int nRet = true;

    voice_init();

    while (true == nRet)
    {
        nRet = voice_loop();
#ifdef _FREERTOS_
        vTaskDelay(1); // 1 tick
#endif
    }

    //Go to here when DSPOTTER_ERR_Expired (over trial limit).
    voice_release();
}
/*******************************************************************************
 End of function voice_main
*******************************************************************************/

/*******************************************************************************
* Function Name: voice_init
* Description  : Initialize
* Arguments    : none
* Return Value : none
*******************************************************************************/
static void voice_init(void)
{
	int rc = 0;
    fsp_err_t   err = FSP_SUCCESS;

    /** UART for DSpotter */
    err = UartOpen(&g_uart_ds, g_uart_ds.p_cfg->channel, -1);   //baud rate: use configuration.xml setting
    if (FSP_SUCCESS != err)
        DBGTRACE("Failed to open UART %d! error: %d\r\n", g_uart_ds.p_cfg->channel, err);

#if RAI_ENABLE
    rc = rai_init();
    if(rc < 0)
        __asm("BKPT #0\n");
#endif

#ifndef MCU_BOARD
    DBG_UART_TRACE("\r\n[Error] Please define MCU_BOARD first.\r\n");
    __BKPT(0);
#endif

    /** LED */
    TurnOffLED(LED_R);       //Red     = OFF
    TurnOffLED(LED_G);       //Green   = OFF
    TurnOffLED(LED_B);       //Blue    = OFF

    //DBG_UART_TRACE("voice_init() Start\r\n");

    /** Cyberon DSpotter */
    ds_decode_init();

    err = AudioRecordInit();
    if (FSP_SUCCESS != err)
        __BKPT(0);
    err = AudioRecordStart();
    if (FSP_SUCCESS != err)
        __BKPT(0);

    //TurnOnLED(LED_R);     //Red   = ON

    // Process UART read.
    UartAsyncRead(g_byaUartRxBuffer, 1, OnDataReadCompleteCallback);

    //DBG_UART_TRACE("voice_init() End\r\n");
}
/*******************************************************************************
 End of function voice_init
*******************************************************************************/

/*******************************************************************************
* Function Name   : voice_loop
* Description     : Voice application process
* Arguments       : none
* Return value    : none
*******************************************************************************/
static bool voice_loop(void)
{
	int rc;
    short   saRecordSample[RECORD_FRAME_SAMPLES];
    int     nRet1 = DSPOTTER_ERR_NeedMoreSample;
    int     nRet2 = DSPOTTER_ERR_NeedMoreSample;
    static  int s_nRBufLostCount = 0;
    static  int s_nUnderRunCount = 0;
    //static  int s_nLedTurnOnCount = 0;
    static  int s_nCommandRecordSample = 0;
    static  int s_nCommandRecognizeLimit = COMMAND_STAGE_TIME_MIN;

    if (g_bUartCheckAlive)
    {
        const char *lpszAck = "live\r\n";
        g_bUartCheckAlive = false;
        UartWaitWriteReady();
        UartAsyncWrite((const BYTE *)lpszAck, strlen(lpszAck));
    }

    if (AudioRecordGetDataSize() < RECORD_FRAME_SIZE)
        return true;

//    if (g_nRecordFrameCount++ % 100 == 0)
//    {
//        DBG_UART_TRACE(".");
//        //TurnOffLED(LED_B);
//    }

    // If the blue LED keeps flashing, it means that the computing power is insufficient
    // and the recording data is lost, please reduce the command number.
    if (s_nRBufLostCount != AudioRecordGetLostCount())
    {
        s_nRBufLostCount = AudioRecordGetLostCount();
        //ToggleLED(LED_B);
        //DBG_UART_TRACE("\r\nLost = %d.\r\n", s_nRBufLostCount);
    }

    if (s_nUnderRunCount != AudioRecordGetUnderRunCount())
    {
        s_nUnderRunCount = AudioRecordGetUnderRunCount();
        //ToggleLED(LED_B);
        //DBG_UART_TRACE("\r\nUnderRun = %d.\r\n", s_nUnderRunCount);
    }

//    if (--s_nLedTurnOnCount == 0)
//        TurnOnLED(LED_R);

    // Get recognize data from recognize ring buffer.
    if (AudioRecordGetData((void*)saRecordSample, RECORD_FRAME_SIZE) != 0)
        DBG_UART_TRACE("\r\nAudioRecordGetData() problem \r\n");

#if VOLUME_SCALE_RECONG != 100
    AGC_Do(g_hAGC, saRecordSample, RECORD_FRAME_SAMPLES, saRecordSample);
#endif

#if RAI_ENABLE
    // write to record buffer
    rc = rai_write((uint8_t*)saRecordSample);
    if(rc < 0)
        DBG_UART_TRACE("Failed to open DC/DS\r\n");
#endif

#ifdef SUPPORT_UART_DUMP_RECORD
    if (g_bUartSendRecord)
    {
        int nTransferSize;
        nTransferSize = Convert2TransferBuffer((BYTE *)saRecordSample, RECORD_FRAME_SIZE, g_byaTxBuffer, sizeof(g_byaTxBuffer), CHECKSUM_TYPE);
        UartWaitWriteReady();
        UartAsyncWrite(g_byaTxBuffer, (uint32_t)nTransferSize);
    }
#endif

#if RECOG_FLOW == RECOG_FLOW_NONE
    return true;
#endif

    // DSpotter AddSample
    nRet1 = DSpotter_AddSample(g_hDSpotter1, saRecordSample, RECORD_FRAME_SAMPLES);
#ifdef SUPPORT_RECOG_TWO_MODEL
    nRet2 = DSpotter_AddSample(g_hDSpotter2, saRecordSample, RECORD_FRAME_SAMPLES);
#endif
    if (nRet1 == DSPOTTER_SUCCESS || nRet2 == DSPOTTER_SUCCESS)
    {
        int  nCmdIndex, nCmdScore, nCmdSGDiff, nCmdEnergy, nMapID;
        char szCommand[64];
        bool bVoiceTag = false;
        int nTriggerWordCount = 0;
        int nCommandWordCount = 0;

        DBG_UART_TRACE("\r\n");
        szCommand[0] = 0;
        nMapID = -100;
        if (nRet1 == DSPOTTER_SUCCESS)
        {
            nTriggerWordCount = CybModelGetCommandCount(g_hCybModel1, 0);
            nCommandWordCount = CybModelGetCommandCount(g_hCybModel1, 1);

            if (nCommandWordCount < 0)
                nCommandWordCount = 0;
            DSpotter_GetResultScore(g_hDSpotter1, &nCmdScore, &nCmdSGDiff, NULL);
            nCmdIndex = DSpotter_GetResult(g_hDSpotter1);
            nCmdEnergy = DSpotter_GetCmdEnergy(g_hDSpotter1);
            DSpotter_Continue(g_hDSpotter1);
        #ifdef SUPPORT_RECOG_TWO_MODEL
            DSpotter_Continue(g_hDSpotter2);
        #endif

            //Change the multi-model command index to active group model command index.
            if (nCmdIndex < nTriggerWordCount)
            {
                CybModelGetCommandInfo(g_hCybModel1, 0, nCmdIndex, szCommand, sizeof(szCommand), &nMapID, NULL);
            }
            else if (nCmdIndex >= nTriggerWordCount && nCmdIndex < nTriggerWordCount + nCommandWordCount)
            {
                CybModelGetCommandInfo(g_hCybModel1, 1, nCmdIndex - nTriggerWordCount, szCommand, sizeof(szCommand), &nMapID, NULL);
            }
            else
            {
                return true;
            }

            #ifdef NOT_SHOW_MULTI_PRONUNCIATION
            if (strchr(szCommand, '^') != NULL)
                strchr(szCommand, '^')[0] = '\0';
            #endif
            voice_result_cb(nCmdIndex, g_nActiveGroupIndex);
            int nNextGroup = voice_result_cb(nMapID, g_nActiveGroupIndex);
            if (nNextGroup != g_nActiveGroupIndex)
                    {
                        if (nNextGroup >= g_nGroupCount)
                        {
                            nNextGroup = 0;
                        }

                        s_nCommandRecordSample = 0;
                        s_nCommandRecognizeLimit = COMMAND_STAGE_TIME_MIN;

                        //SetDSpotter(g_hCybModel1, nNextGroup, g_byaDSpotterMem1, sizeof(g_byaDSpotterMem1), &g_hDSpotter1);
                    }
            if (CheckGroupHasID(g_hDSpotter1, g_hCybModel1, g_nActiveGroupIndex, nMapID) || g_bVoiceTagRecording || g_bVoiceTagDeleting)
            {
                if (!bVoiceTag)
                {
                	if (rai_pred !=1) //if not dropped

                	{
                    DBG_UART_TRACE("Get %s word %s: Index=%d, Score=%d, SG_Diff=%d, Energy=%d, MapID=%d\r\n",
                        (g_nActiveGroupIndex == 0) ? "trigger" : "command", szCommand, nCmdIndex, nCmdScore, nCmdSGDiff, nCmdEnergy, nMapID);
                	}
#if RAI_ENABLE
                	else if (rai_pred ==1 && g_nActiveGroupIndex == 1)
                	{
                		DBG_UART_TRACE("Command is not accepted, machine generated voice detected\r\n",
                		                        (g_nActiveGroupIndex == 0) ? "Trigger" : "Command", szCommand);
                	}
#else
                	DBG_UART_TRACE("Get %s word %s: Index=%d, Score=%d, SG_Diff=%d, Energy=%d, MapID=%d\r\n",
                	                        (g_nActiveGroupIndex == 0) ? "trigger" : "command", szCommand, nCmdIndex, nCmdScore, nCmdSGDiff, nCmdEnergy, nMapID);

#endif
                }
                else
                {
#if RAI_ENABLE
                	if (rai_pred !=1) //if not dropped
                	{
                		DBG_UART_TRACE("Get voice tag on %s: SD Index=%d, Score=%d, SG_Diff=%d, Energy=%d, MapID=%d\r\n",
                        szCommand, nCmdIndex - nTriggerWordCount - nCommandWordCount, nCmdScore, nCmdSGDiff, nCmdEnergy, nMapID);
                	}
#else
                	DBG_UART_TRACE("Get voice tag on %s: SD Index=%d, Score=%d, SG_Diff=%d, Energy=%d, MapID=%d\r\n",
                	                        szCommand, nCmdIndex - nTriggerWordCount - nCommandWordCount, nCmdScore, nCmdSGDiff, nCmdEnergy, nMapID);
#endif
                }
            }
            else
            {
                // Recognition at wrong stage.
                return true;
            }
        }
        
        s_nCommandRecordSample = 0;
        s_nCommandRecognizeLimit = COMMAND_STAGE_TIME_MIN;


//        // Flicker red LED to indicate the success of recognition.
//        TurnOffLED(LED_R); //Red    = OFF
//        s_nLedTurnOnCount = 10;
        DBG_UART_TRACE("\r\n");

        switch (nMapID)
        {
        case 0:
        case 1:
            //user's application
            break;
        default:
            //invalid argument
            break;
        }

        s_nCommandRecordSample = 0;
        s_nCommandRecognizeLimit = COMMAND_STAGE_TIME_MIN;

        if (g_nActiveGroupIndex == GROUP_INDEX_TRIGGER && CybModelGetGroupCount(g_hCybModel1) >= 2)
        {
            // After trigger word recognized, switch to command recognition mode
            SelectGroupModel(g_hCybModel1, GROUP_INDEX_COMMAND, g_hDSpotter1, TRUE);
        #ifdef SUPPORT_RECOG_TWO_MODEL
            SelectGroupModel(g_hCybModel2, GROUP_INDEX_COMMAND, g_hDSpotter2, TRUE);
        #endif
        }
    }
    else if (nRet1 == DSPOTTER_ERR_Expired || nRet2 == DSPOTTER_ERR_Expired)
    {
        DBG_UART_TRACE("\r\nThe trial version DSpotter reach the max trial usage count, please reset system.\r\n");
        TurnOffLED(LED_R);       //Red     = OFF
        TurnOffLED(LED_G);       //Green   = OFF
        TurnOffLED(LED_B);       //Blue    = OFF

        return false;
    }
    else if (nRet1 == DSPOTTER_ERR_NeedMoreSample || nRet2 == DSPOTTER_ERR_NeedMoreSample)
    {
        if (g_bVoiceTagRecording || g_bVoiceTagDeleting)
        {
            s_nCommandRecordSample += RECORD_FRAME_SAMPLES;
            if (s_nCommandRecordSample > 16000 * 8)
            {
                DBG_UART_TRACE("\r\nTimeout for recognizing the command name!\r\n");

                s_nCommandRecordSample = 0;
                s_nCommandRecognizeLimit = COMMAND_STAGE_TIME_MIN;
                g_bVoiceTagRecording = FALSE;
                g_bVoiceTagDeleting = FALSE;
                SelectGroupModel(g_hCybModel1, GROUP_INDEX_TRIGGER, g_hDSpotter1, TRUE);
            #ifdef SUPPORT_RECOG_TWO_MODEL
                InitDSpotter(g_hCybModel2, GROUP_INDEX_TRIGGER, g_byaDSpotterMem2, sizeof(g_byaDSpotterMem2), &g_hDSpotter2, TRUE);
            #endif
            }
        }
        else if (g_nActiveGroupIndex == GROUP_INDEX_COMMAND)
        {
            // Check timeout for command recognition mode
            s_nCommandRecordSample += RECORD_FRAME_SAMPLES;
            if (s_nCommandRecordSample > 16000 / 1000 * s_nCommandRecognizeLimit)
            {
            #ifdef SUPPORT_RECOG_TWO_MODEL
                if (DSpotter_IsKeywordAlive(g_hDSpotter1) || DSpotter_IsKeywordAlive(g_hDSpotter2))
            #else
                if (DSpotter_IsKeywordAlive(g_hDSpotter1))
            #endif
                {
                    if (s_nCommandRecognizeLimit < COMMAND_STAGE_TIME_MAX)
                    {
                        s_nCommandRecognizeLimit += 500;
                        return true;
                    }
                }
                DBG_UART_TRACE("\r\nTimeout for command stage, switch to trigger stage.\r\n");
                s_nCommandRecognizeLimit = COMMAND_STAGE_TIME_MIN;

                SelectGroupModel(g_hCybModel1, GROUP_INDEX_TRIGGER, g_hDSpotter1, TRUE);
            #ifdef SUPPORT_RECOG_TWO_MODEL
                SelectGroupModel(g_hCybModel2, GROUP_INDEX_TRIGGER, g_hDSpotter2, TRUE);
            #endif
            }
        }
    }

    return true;
}
/*******************************************************************************
 End of function voice_loop
*******************************************************************************/

/*******************************************************************************
* Function Name: voice_release
* Description  : Release resource
* Arguments    : none
* Return Value : none
*******************************************************************************/
static void voice_release(void)
{

    AudioRecordRelease();

    ReleaseDSpotter(&g_hDSpotter1);
    CybModelRelease(g_hCybModel1);
    g_hCybModel1 = NULL;
#ifdef SUPPORT_RECOG_TWO_MODEL
    ReleaseDSpotter(&g_hDSpotter2);
    CybModelRelease(g_hCybModel2);
    g_hCybModel2 = NULL;
#endif

    AGC_Release(g_hAGC);
    g_hAGC = NULL;

    UartClose();
}
/*******************************************************************************
 End of function voice_release
*******************************************************************************/

static int TestByteOrder()
{
    short nTestWord = 0x0001;      //Little endian memory is 0x01 0x00, big endian memory is 0x00 0x01.
    char *b = (char *)&nTestWord;  //Little endian b[0] is 0x01, big endian memory b[0] is 0x00.
    return (int)b[0];              //Return 1/0 for little/big endian.
}

static void InitDSpotter(HANDLE hCybModel, int nGroupIndex, BYTE *pbyaDSpotterMem, int nMemSize, HANDLE *phDSpotter, BOOL bShowInfo)
{
    int nRet = DSPOTTER_ERR_IllegalParam;
    BYTE *lppbyModel[2 + 1]; // Two group model and one voice tag model.
    int n;
    int nGroupCount = CybModelGetGroupCount(hCybModel);

    // In this sample code, we only use one or two group model and treat the first group
    // as trigger word, the second group as command word.
    if (nGroupCount > 2)
        nGroupCount = 2;

    if (nGroupIndex >= nGroupCount)
    {
        DBG_UART_TRACE("Invalid nGroupIndex parameter!\r\n");
        return;
    }

    /*
     * For official version of DSpotter, DSpotter_Init_Multi() will use the data flash API and
     * its instance to check license. In configuration.xml, please:
     *   1. Add r_flash_hp component.
     *   2. Add Flash Driver stack, named "g_flash0" and set callback as "flash0_bgo_callback".
     * For RA6M1, The data flash address start at 0x40100000U, total 128 blocks, each block has
     * 64 bytes, total 8K bytes. DSpotter need 256 bytes(4 blocks) to save license information.
     * So, the valid flash address is FLASH_DF_BLOCK_ADDRESS(0) ~ FLASH_DF_BLOCK_ADDRESS(123).
    */
    if (FLASH_DSPOTTER_BLOCK_INDEX + FLASH_DSPOTTER_BLOCK_COUNT > FLASH_DF_TOTAL_BLOCKS)
    {
        DBG_UART_TRACE("FLASH_DSPOTTER_BLOCK_INDEX error!\r\n");
        __BKPT(0);
    }

    ReleaseDSpotter(phDSpotter);

    for (n = 0; n < nGroupCount; n++)
        lppbyModel[n] = (BYTE*)CybModelGetGroup(hCybModel, n);


    *phDSpotter = DSpotter_Init_Multi((BYTE *)CybModelGetBase(hCybModel), lppbyModel, n, MAX_COMMAND_TIME,
                                      pbyaDSpotterMem, nMemSize, FLASH_DF_BLOCK_ADDRESS(FLASH_DSPOTTER_BLOCK_INDEX), FLASH_DF_BLOCK_SIZE, &nRet);
    if (*phDSpotter == NULL)
    {
        DBG_UART_TRACE("DSpotter_Init_XXX() fail, error = %d!\r\n", nRet);
        __BKPT(0);
    }

    if (!DSpotter_ModelHasMapIDList(*phDSpotter))
    {
        for (n = 0; n < nGroupCount; n++)
        {
            SHORT *lpsMapID;
            int nCommandCount;
            int nCommandIndex;
            int nMapID;

            // This old model data which doesn't include map ID.
            // For use with new API DSpotter_GetCmdMapIDList(), we use DSpotter_SetCmdMapIDList() for old model.
            nCommandCount = CybModelGetCommandCount(hCybModel, n);
            lpsMapID = (SHORT *)PortMalloc((size_t)nCommandCount * 2);
            if (lpsMapID != NULL)
            {
                for (nCommandIndex = 0; nCommandIndex < nCommandCount; nCommandIndex++)
                {
                    CybModelGetCommandInfo(hCybModel, n, nCommandIndex, NULL, 0, &nMapID, NULL);
                    lpsMapID[nCommandIndex] = (SHORT)nMapID;
                }
                DSpotter_SetCmdMapIDList(*phDSpotter, n, lpsMapID, nCommandCount);
                PortFree(lpsMapID);
            }
            else
            {
                DBG_UART_TRACE("Heap too small!\r\n");
                __BKPT(0);
            }
        }
    }

    SelectGroupModel(hCybModel, nGroupIndex, *phDSpotter, bShowInfo);

    AGC_SetMaxGain(g_hAGC, VOLUME_SCALE_RECONG/100);
}

static void ReleaseDSpotter(HANDLE *lphDSpotter)
{
    if (lphDSpotter != NULL)
    {
        DSpotter_Release(*lphDSpotter);
        *lphDSpotter = NULL;
    }
}

static void SelectGroupModel(HANDLE hCybModel, int nGroupIndex, HANDLE hDSpotter, BOOL bShowInfo)
{
    int nGroupCount = CybModelGetGroupCount(hCybModel);
    g_nGroupCount = CybModelGetGroupCount(hCybModel);
    // In this sample code, we only use one or two group model and treat the first group
    // as trigger word, the second group as command word.
    if (nGroupCount > 2)
        nGroupCount = 2;

    if (nGroupIndex >= nGroupCount)
        return;

    for (int i = 0; i < nGroupCount; i++)
        DSpotter_EnableModel(hDSpotter, i, i == nGroupIndex);

    g_nActiveGroupIndex = nGroupIndex;
    if (bShowInfo)
    {
#if RAI_ENABLE
    	if ( rai_pred !=1){
        DBG_UART_TRACE("\r\n");
        DBG_UART_TRACE("%s group active.\r\n", nGroupIndex == 0 ? "Wake-up" : "Command");

        PrintGroupCommandList(hCybModel, nGroupIndex);
    	}
//    	else if (rai_pred ==2 && nGroupIndex==1)
//    	{
//    		//DBG_UART_TRACE("\r\n");
//    		DBG_UART_TRACE("%s group not active.\r\n", nGroupIndex == 0 ? "Wake-up" : "Command");
//    	}
    	else if(nGroupIndex==0 && rai_pred ==1)
    	{
    		DBG_UART_TRACE("\r\n");
    		DBG_UART_TRACE("%s group active.\r\n", nGroupIndex == 0 ? "Wake-up" : "Command");
    		PrintGroupCommandList(hCybModel, nGroupIndex);
    	}

#else
        DBG_UART_TRACE("\r\n");
                DBG_UART_TRACE("%s group active.\r\n", nGroupIndex == 0 ? "Wake-up" : "Command");

                PrintGroupCommandList(hCybModel, nGroupIndex);
#endif
    }
}

static bool ds_decode_init(void)
{
    const bsp_unique_id_t   *devi_uniq_id;
    BYTE *lppbyModel[2];
    int  nGroupCount;
    int  nMemSize;

    //DBG_UART_TRACE("ds_decode_init() Begin\r\n");
    /** Memory size check, device authentication and ring buffer initialization */
    // Get unique ID
    devi_uniq_id = R_BSP_UniqueIdGet();

    int nByteOrder = TestByteOrder();
    DBG_UART_TRACE("%s\r\n", nByteOrder == 1 ? "Little Endian" : "Big Endian");
    DBG_UART_TRACE("MCU board: %s\r\n", MCU_BOARD_STRING);
    DBG_UART_TRACE("FSP version: %d.%d\r\n", FSP_VERSION_MAJOR, FSP_VERSION_MINOR);
    DBG_UART_TRACE("DSpotter version: %s", DSpotter_VerInfo());
    DBG_UART_TRACE("Sample code build at %s, %s\r\n", __DATE__, __TIME__);
    DBG_UART_TRACE("Unique ID: %X %X %X %X\r\n", devi_uniq_id->unique_id_words[0],
            devi_uniq_id->unique_id_words[1], devi_uniq_id->unique_id_words[2], devi_uniq_id->unique_id_words[3]);

    if (nByteOrder == 0)
    {
        DBG_UART_TRACE("The DSpotter use Renesas RA default compile setting: CM4/HardFPU/little endian, not big endian!\r\n");
        return FSP_ERR_ASSERTION;
    }

    g_hCybModel1 = CybModelInit((const BYTE*)&uCYModel1Begin, g_byaCybModelMem1, sizeof(g_byaCybModelMem1), NULL);
#ifdef SUPPORT_RECOG_TWO_MODEL
    g_hCybModel2 = CybModelInit((const BYTE*)&uCYModel2Begin, g_byaCybModelMem2, sizeof(g_byaCybModelMem2), NULL);
#endif

    // Check memory for every group and show their commands.
    for (int nModel = 0; nModel < 2; nModel++)
    {
        HANDLE hCybModel;
        int nDSpotterMem;

        if (nModel == 0)
        {
            hCybModel = g_hCybModel1;
            nDSpotterMem = (int)sizeof(g_byaDSpotterMem1);
        }
        else
        {
        #ifdef SUPPORT_RECOG_TWO_MODEL
            hCybModel = g_hCybModel2;
            nDSpotterMem = (int)sizeof(g_byaDSpotterMem2);
        #else
            break;
        #endif
        }

        DBG_UART_TRACE("\r\n");
        DBG_UART_TRACE("The DSpotter model %d declare memory buffer size = %d\r\n", nModel, nDSpotterMem);
        nGroupCount = CybModelGetGroupCount(hCybModel);
        if (nGroupCount > 2)
            nGroupCount = 2;
        for (int nGroup = 0; nGroup < nGroupCount; nGroup++)
        {
            lppbyModel[nGroup] = (BYTE*)CybModelGetGroup(hCybModel, nGroup);

            DBG_UART_TRACE("The model %d, command list of group index %d: \r\n", nModel, nGroup);
            PrintGroupCommandList(hCybModel, nGroup);
        }
        nMemSize = DSpotter_GetMemoryUsage_Multi((BYTE *)CybModelGetBase(hCybModel), lppbyModel, nGroupCount, MAX_COMMAND_TIME);
        DBG_UART_TRACE("The DSpotter model %d has %d groups needed working memory size = %d\r\n", nModel, nGroupCount, nMemSize);
        if (nDSpotterMem < nMemSize)
        {
            DBG_UART_TRACE("The DSpotter model %d declare memory buffer size is tool small!\r\n", nModel);
            __BKPT(0);
        }
    }

    g_hAGC = AGC_Init(g_byaAGCMem, sizeof(g_byaAGCMem), NULL);
    if (g_hAGC == NULL)
    {
        DBG_UART_TRACE("AGC initial fail!\r\n");
        __BKPT(0);
    }

    InitDSpotter(g_hCybModel1, GROUP_INDEX_TRIGGER, g_byaDSpotterMem1, sizeof(g_byaDSpotterMem1), &g_hDSpotter1, TRUE);
#ifdef SUPPORT_RECOG_TWO_MODEL
    InitDSpotter(g_hCybModel2, GROUP_INDEX_TRIGGER, g_byaDSpotterMem2, sizeof(g_byaDSpotterMem2), &g_hDSpotter2, TRUE);
#endif

    //DBG_UART_TRACE("ds_decode_init() End\r\n");

    return true;
}

void OnDataReadCompleteCallback(void)
{
    static char s_szCmd[4] = { 0 };
    static int8_t s_nIndex = 0;
    char ch = (char)g_byaUartRxBuffer[0];

    if (s_nIndex < 4)
    {
        s_szCmd[s_nIndex++] = ch;
    }
    else
    {
        memmove(s_szCmd, s_szCmd + 1, 3);
        s_szCmd[3] = ch;
        if (strncmp(s_szCmd, "CYB", 3) == 0)
        {
        #ifdef SUPPORT_UART_DUMP_RECORD
            if (ch == 0x31)
                g_bUartSendRecord = true;
            else if (ch == 0x32)
                g_bUartSendRecord = false;
        #endif
            if (ch == 0x33)
                g_bUartCheckAlive = true;
        }
    }

    //Continue to read next byte.
    UartAsyncRead(g_byaUartRxBuffer, 1, OnDataReadCompleteCallback);
}


static void PrintGroupCommandList(HANDLE hCybModel, int nGroupIndex)
{
    char szCommand[64];
    int  nMapID;

    for (int i = 0; i < CybModelGetCommandCount(hCybModel, nGroupIndex); i++)
    {
        CybModelGetCommandInfo(hCybModel, nGroupIndex, i, szCommand, sizeof(szCommand), &nMapID, NULL);
        if (strlen(szCommand) > 0)
        {
        #ifdef NOT_SHOW_MULTI_PRONUNCIATION
            if (strchr(szCommand, '^') != NULL)
                continue;
        #endif
            DBG_UART_TRACE("    %s, Map ID = %d\r\n", szCommand, nMapID);
        }
    }
    DBG_UART_TRACE("\r\n");
}

static BOOL CheckGroupHasID(HANDLE hDSpotter, HANDLE hCybModel, int nGroupIndex, int nMapID)
{
    int nCommandIndex;
    int nCommandCount;
    SHORT *lpsMapID;

    lpsMapID = DSpotter_GetCmdMapIDList(hDSpotter, nGroupIndex, NULL);
    if (lpsMapID != NULL)
    {
        nCommandCount = CybModelGetCommandCount(hCybModel, nGroupIndex);
        for (nCommandIndex = 0; nCommandIndex < nCommandCount; nCommandIndex++)
        {
            if (lpsMapID[nCommandIndex] == nMapID)
                return TRUE;
        }
    }

    return FALSE;
}

void ToggleLED(bsp_io_port_pin_t oLED)
{
    bsp_io_level_t level;

    R_IOPORT_PinRead(&g_ioport_ctrl, oLED, &level);
    if (level == ON)
        R_IOPORT_PinWrite(&g_ioport_ctrl, oLED, OFF);
    else
        R_IOPORT_PinWrite(&g_ioport_ctrl, oLED, ON);
}

void TurnOnLED(bsp_io_port_pin_t oLED)
{
    R_IOPORT_PinWrite(&g_ioport_ctrl, oLED, ON);
}

void TurnOffLED(bsp_io_port_pin_t oLED)
{
    R_IOPORT_PinWrite(&g_ioport_ctrl, oLED, OFF);
}

int voice_result_cb_weak(int nCmdID, int nActiveGroupIndex);
int voice_result_cb_weak(int nCmdID, int nActiveGroupIndex)
{
    FSP_PARAMETER_NOT_USED(nCmdID);
    FSP_PARAMETER_NOT_USED(nActiveGroupIndex);

    return 0;
}
/*******************************************************************************
 End Of File
*******************************************************************************/
