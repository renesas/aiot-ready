#include <rai.h>
#include "hal_data.h"
#include "RingBuffer.h"
#include "AudioRecord.h"
#include "voice_antispoof_model.h"

#if RAI_USE_FIR
#include "dsp/filtering_functions.h"

#if RAI_DECIMATION == 2
static const q15_t fir_coeff[FIR_NUM_TAPS] = {
76, 194, -98, -98, 43, 156, -27, -199, -11, 245, 66, -287, -144, 320, 246, -339,
-375, 335, 535, -298, -732, 213, 978, -56, -1302, -224, 1777, 762, -2657, -2129, 5571, 14004,
14004, 5571, -2129, -2657, 762, 1777, -224, -1302, -56, 978, 213, -732, -298, 535, 335, -375,
-339, 246, 320, -144, -287, 66, 245, -11, -199, -27, 156, 43, -98, -98, 194, 76,
};
#elif RAI_DECIMATION == 4
static const q15_t fir_coeff[FIR_NUM_TAPS] = {
-56, 193, 134, 89, 9, -93, -170, -178, -94, 59, 219, 302, 249, 55, -211, -428,
-475, -288, 91, 514, 775, 701, 240, -482, -1177, -1482, -1091, 111, 1973, 4097, 5949, 7026,
7026, 5949, 4097, 1973, 111, -1091, -1482, -1177, -482, 240, 701, 775, 514, 91, -288, -475,
-428, -211, 55, 249, 302, 219, 59, -94, -178, -170, -93, 9, 89, 134, 193, -56,
};
#endif

static q15_t cmsis_state[FIR_BUF_LEN];
static arm_fir_decimate_instance_q15 S = {
   .M       = RAI_DECIMATION,
   .numTaps = FIR_NUM_TAPS,
   .pCoeffs = fir_coeff,
   .pState  = cmsis_state
};
#endif

static HANDLE h_ring_buffer = NULL;
static BYTE    g_working_mem[RING_BUFFER_GET_MEM_USAGE(RAI_RECORD_BUF_SIZE)];
static int16_t g_frame_wbuffer[RAI_FRAME_BUF_LEN];

// recoverable assertion
static void dbg_assert(int16_t exp){
    volatile size_t dummy = 1;
    if( exp == 0 ){
        __disable_irq();
        while(dummy == 1);
        __enable_irq();
    }
}

int rai_init(void){
    fsp_err_t rc;

    rc = RingBufferInit(g_working_mem, sizeof(g_working_mem), RAI_RECORD_BUF_SIZE, &h_ring_buffer);
    if( rc != FSP_SUCCESS ){
        DBG_UART_TRACE("Failed to init DC/DS circular buffer\r\n");
        dbg_assert(rc == FSP_SUCCESS);
        return -1;
    }

#if RAI_DECIMATION > 1 && RAI_USE_FIR
    memset(&cmsis_state, 0, FIR_BUF_SIZE);
#endif

    DBG_UART_TRACE("Successfully initialize DC/DS\r\n");
    return 0;
}

// decimate raw audio (16ksps) samples and write to 1.5sec recording buffer
int rai_write(uint8_t* buf){
    int rc;
    int16_t dummy[RAI_REC_FRAME_LEN];
    int bytes_to_read = RAI_REC_FRAME_SIZE - RingBufferGetFreeSize(h_ring_buffer);
    if( bytes_to_read > 0 ){
        rc = RingBufferGetData(h_ring_buffer, (int8_t*)dummy, bytes_to_read);
        if( rc != RING_BUFFER_SUCCESS ){
            DBG_UART_TRACE("Failed to read samples from DC/DS circular buffer\r\n");
            dbg_assert(0);
            return -1;
        }
    }

    // decimation (+ FIR filter)
#if RAI_DECIMATION > 1
    #if RAI_USE_FIR
    arm_fir_decimate_q15(&S, (q15_t*)buf, (q15_t*)dummy, RAI_REC_FRAME_LEN);
    #else
    int m = 0;
    int16_t* ptr = (int16_t*)buf;
    for(uint32_t k = 0; k < RAI_REC_FRAME_LEN; k += RAI_DECIMATION)
        dummy[m++] = ptr[k];
    #endif
#endif

    rc = RingBufferPutData(h_ring_buffer, (int8_t*)dummy, RAI_REC_FRAME_DEC_SIZE);
    if( rc != RING_BUFFER_SUCCESS ){
        DBG_UART_TRACE("Failed to write samples to DC/DS circular buffer\r\n");
        dbg_assert(0);
        return -1;
    }
    return 0;
}

// implement inference using DC/DS frame buffer
static int inference(int16_t* buffer){
    int pred = -1;

    if( (buffer != NULL) )
        pred = (int)voice_antispoof_predict(buffer);

    switch(pred){
    case voice_antispoof_no_results:
        DBG_UART_TRACE("Detected Class: Undefined\r\n");
        break;
    case voice_antispoof_real:
        DBG_UART_TRACE("Detected Class: Accepted\r\n");
        break;
    case voice_antispoof_fake:
        DBG_UART_TRACE("Detected Class: Dropped\r\n");
        break;
    default:
        DBG_UART_TRACE("Detected Class: Error\n");
    };
    return pred;
}

// dump circular buffer into DS frame buffer on DSpotter detection
int rai_inference(void){
    int rc;
    rc = RingBufferGetDataSize(h_ring_buffer);
    if( rc < (int)RAI_FRAME_BUF_SIZE ){
        DBG_UART_TRACE("unexpected DC/DS circular buffer fill size\r\n");
        dbg_assert(0);
        return -1;
    }

    rc = RingBufferGetData(h_ring_buffer, g_frame_wbuffer, RAI_FRAME_BUF_SIZE);
    if( rc != RING_BUFFER_SUCCESS ){
        DBG_UART_TRACE("Failed to read samples from DC/DS circular buffer\r\n");
        dbg_assert(0);
        return -1;
    }

    // discard remaining samples
    rc = RingBufferReset(h_ring_buffer);
    if( rc != RING_BUFFER_SUCCESS ){
        DBG_UART_TRACE("Failed to reset DC/DS circular buffer\r\n");
        dbg_assert(0);
        return -1;
    }

    // call inference here
    return (int)inference(g_frame_wbuffer);
}
