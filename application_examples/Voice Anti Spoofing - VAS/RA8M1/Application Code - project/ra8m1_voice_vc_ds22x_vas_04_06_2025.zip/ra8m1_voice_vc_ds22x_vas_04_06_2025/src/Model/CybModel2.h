#ifndef __CYB_MODEL2_H
#define __CYB_MODEL2_H

extern unsigned int uCYModel2Begin;
extern unsigned int uCYModel2End;

#endif
