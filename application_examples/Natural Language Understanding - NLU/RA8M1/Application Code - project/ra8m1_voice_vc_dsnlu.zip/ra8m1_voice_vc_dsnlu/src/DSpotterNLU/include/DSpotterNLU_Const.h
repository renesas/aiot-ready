#ifndef __DSPOTTERNLU_CONST_H__
#define __DSPOTTERNLU_CONST_H__


#define DSPOTTERNLU_SUCCESS						(     0 )
#define DSPOTTERNLU_ERR_SDKError	    		( -1000 )

/************************************************************************/
// Error code
/************************************************************************/

#define DSPOTTERNLU_ERR_IllegalHandle               ( DSPOTTERNLU_ERR_SDKError -   1 )
#define DSPOTTERNLU_ERR_IllegalParam                ( DSPOTTERNLU_ERR_SDKError -   2 )
#define DSPOTTERNLU_ERR_LeaveNoMemory               ( DSPOTTERNLU_ERR_SDKError -   3 )
#define DSPOTTERNLU_ERR_Timeout                     ( DSPOTTERNLU_ERR_SDKError -   4 )
#define DSPOTTERNLU_ERR_Expired                     ( DSPOTTERNLU_ERR_SDKError -   5 )
#define DSPOTTERNLU_ERR_LoadModelFailed             ( DSPOTTERNLU_ERR_SDKError -   6 )
#define DSPOTTERNLU_ERR_EngineError                 ( DSPOTTERNLU_ERR_SDKError -   7 )
#define DSPOTTERNLU_ERR_NeedMoreSample              ( DSPOTTERNLU_ERR_SDKError -   8 )
#define DSPOTTERNLU_ERR_AGCError                    ( DSPOTTERNLU_ERR_SDKError -   9 )
#define DSPOTTERNLU_ERR_NotAllowed                  ( DSPOTTERNLU_ERR_SDKError -  10 )
#define DSPOTTERNLU_ERR_LicenseFailed               ( DSPOTTERNLU_ERR_SDKError - 200 )


#endif //__DSPOTTERNLU_CONST_H__

