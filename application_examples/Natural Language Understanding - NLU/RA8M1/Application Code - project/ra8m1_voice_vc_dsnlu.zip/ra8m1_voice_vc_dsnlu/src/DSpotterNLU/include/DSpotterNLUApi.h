
#ifndef __DSPOTTERNLU_API_H
#define __DSPOTTERNLU_API_H

#if defined(_WIN32)
	#ifdef DSpotterDll_EXPORTS
		#define DSPDLL_API __declspec(dllexport)
	#endif
#endif

#ifndef DSPDLL_API
#define DSPDLL_API
#endif

#include "base_types.h"

#ifdef __cplusplus
extern "C"{
#endif



// Purpose: Get the total size of memory needed by DSpotterNLU
// lpbyPackBin(IN): DSMT pack bin with txt.
// nGroupIdx(IN): Group index of the DSpotterNLU model in DSMT file.
// nMaxTime(IN): The maximum buffer length in number of frames for keeping the status of commands.
// lpbyNLP(IN): Binary files for CGASR.
// Return: The memory required to init DSpotterNLU.
DSPDLL_API INT DSpotterNLU_GetMemoryUsage(BYTE *lpbyPackBin, INT nGroupIdx, INT nMaxTime, BYTE *lpbyNLP);

// Purpose: Create a recognizer handle of DSpotterNLU
// lpbyPackBin(IN): DSMT pack bin with txt.
// nGroupIdx(IN): Group index of the DSpotterNLU model in DSMT file.
// nMaxTime(IN): The maximum buffer length in number of frames for keeping the status of commands.
// lpbyNLP(IN): Binary files for CGASR.
// lpbyMemPool(IN/OUT): Memory buffer for the recognizer.
// nMemSize(IN): Size in bytes of the memory buffer lpbyMemPool.
// lpbyPreserve(IN/OUT): Preserve param.
// nPreserve(IN): Preserve param.
// pnErr(OUT): DSPOTTERNLU_SUCCESS indicates success, else error code. It can be NULL.
// Return: a recognizer handle or NULL
DSPDLL_API HANDLE DSpotterNLU_Init(BYTE *lpbyPackBin, INT nGroupIdx, INT nMaxTime, BYTE *lpbyNLP, BYTE *lpbyMemPool, INT nMemSize, BYTE *lpbyPreserve, INT nPreserve, INT *pnErr);

// Purpose: Destroy a recognizer (free resources)
// hDSpotterNLU(IN): a handle of the recognizer
// Return: DSPOTTERNLU_SUCCESS or error code
DSPDLL_API INT DSpotterNLU_Release(HANDLE hDSpotterNLU);

// Purpose: Transfer voice samples to the recognizer for recognizing.
// hDSpotterNLU(IN): a handle of the recognizer
// lpsSample(IN): the pointer of voice data buffer
// nNumSample(IN): the number of voice data (a unit is a short, we prefer to add 480 samples per call)
// Return: DSPOTTERNLU_SUCCESS or error code
DSPDLL_API INT DSpotterNLU_AddSample(HANDLE hDSpotterNLU, SHORT *lpsSample, INT nNumSample);

// Purpose: Tell the recognizer to start NLU mode recognition.
// hDSpotterNLU(IN): a handle of the recognizer.
// Return: DSPOTTERNLU_SUCCESS or error code.
DSPDLL_API INT DSpotterNLU_StartNLU(HANDLE hDSpotterNLU);

// Purpose: Tell the recognizer to stop NLU mode recognition and generate CGASR result.
// hDSpotterNLU(IN): a handle of the recognizer.
// Return: DSPOTTERNLU_SUCCESS or error code.
DSPDLL_API INT DSpotterNLU_StopNLU(HANDLE hDSpotterNLU);

// Pupose: Tell the recognizer to stop NLU mode and discard the result.
// hDSpotterNLU(IN): a handle of the recognizer.
// Return: DSpotterNLU_SUCCESS or error code.
DSPDLL_API INT DSpotterNLU_AbortNLU(HANDLE hDSpotterNLU);

// Purpose: Prepare for next recognition. Call this after DSpotterNLU_GetTriggerResult, DSpotterNLU_GetVRNBest, or DSpotterNLU_GetNLUNBestResult
// hDSpotterNLU(IN): a handle of the recognizer.
// Return: DSpotterNLU_SUCCESS or error code.
DSPDLL_API INT DSpotterNLU_Continue(HANDLE hDSpotterNLU);

// Pupose: Reset the current recognition and discard the result(s) if any.
// hDSpotterNLU(IN): a handle of the recognizer.
// Return: DSpotterNLU_SUCCESS or error code.
DSPDLL_API INT DSpotterNLU_Reset(HANDLE hDSpotterNLU);

// Purpose: Get the total number of NLU results
// hDSpotterNLU(IN): a handle of the recognizer
// Return: the number of NLU results
DSPDLL_API INT DSpotterNLU_GetNLUNBestCnt(HANDLE hDSpotterNLU);

// Purpose: Get the i-th NLU result
// hDSpotterNLU(IN): a handle of the recognizer
// nNBest(IN): the index of result, should be in range of [0,DSpotterNLU_GetNLUNBestCnt)
// lpszJson(IN/OUT): char buffer to store the NLU result
// Return: the length of char array required to store the i-th NLU result
DSPDLL_API INT DSpotterNLU_GetNLUNBestResult_UTF8(HANDLE hDSpotterNLU, INT nNBest, char* lpszJson);

// Purpose: Get the i-th NLU result
// hDSpotterNLU(IN): a handle of the recognizer
// nNBest(IN): the index of result, should be in range of [0,DSpotterNLU_GetNLUNBestCnt)
// lpwcJson(IN/OUT): UNICODE buffer to store the NLU result
// Return: the length of UNICODE array required to store the i-th NLU result
DSPDLL_API INT DSpotterNLU_GetNLUNBestResult_UTF16(HANDLE hDSpotterNLU, INT nNBest, UNICODE* lpwcJson);

// Purpose: Get the total number of recognition results.
// hDSpotterNLU(IN): a handle of the recognizer
// Return: number of recognition results
DSPDLL_API INT DSpotterNLU_GetVRNBestCnt(HANDLE hDSpotterNLU);

// Purpose: Get the word ids of i-th recognition result.
// hDSpotterNLU(IN): a handle of the recognizer
// nNBest(IN): index of recognition result, should be in range of [0,DSpotterNLU_GetVRNBestCnt)
// lpnCmdIdx(IN/OUT): integer array to store the word ids
// pnPathScore(IN/OUT): integer array to store the path score of each word
// Return: the length of integer array required to store the i-th recognition result
DSPDLL_API INT DSpotterNLU_GetVRNBestResult_WordId(HANDLE hDSpotterNLU, INT nNBest, INT lpnCmdIdx[], INT *pnPathScore);

// Purpose: Get words of i-th recognition result.
// hDSpotterNLU(IN): a handle of the recognizer
// nNBest(IN): index of recognition result, should be in range of [0,DSpotterNLU_GetVRNBestCnt)
// lpszVRResult(IN/OUT): char array to store words in the i-th recognition result, each word is split by a slash '/'
// pnPathScore(IN/OUT): integer array to store the path score of each word
// Return: the length of char array required to store the result
DSPDLL_API INT DSpotterNLU_GetVRNBestResult_UTF8(HANDLE hDSpotterNLU, INT nNBest, char* lpszVRResult, INT* pnPathScore);

// Purpose: Get words of i-th recognition result.
// hDSpotterNLU(IN): a handle of the recognizer
// nNBest(IN): index of recognition result, should be in range of [0,DSpotterNLU_GetVRNBestCnt)
// lpszVRResult(IN/OUT): UNICODE array to store words in the i-th recognition result, each word is split by a slash L'/'
// pnPathScore(IN/OUT): integer array to store the path score of each word
// Return: the length of UNICODE array required to store the result
DSPDLL_API INT DSpotterNLU_GetVRNBestResult_UTF16(HANDLE hDSpotterNLU, INT nNBest, UNICODE* lpwcVRResult, INT* pnPathScore);

// Purpose: Get the version of the DSpotterNLU engine
// Return: string that states the version
DSPDLL_API const char* DSpotterNLU_Ver(void);


DSPDLL_API INT DSpotterNLU_GetTriggerResult(HANDLE hDSpotterNLU, INT* pnConfi, INT* pnSGDiff, INT* pnMapId);
DSPDLL_API INT DSpotterNLU_GetTriggerResultEPD(HANDLE hDSpotterNLU, INT* pnWordDura, INT* pnEndSil, INT* pnNetworkLatency);
DSPDLL_API INT DSpotterNLU_GetNumWord(BYTE *lpbyModel);
DSPDLL_API INT DSpotterNLU_GetCmdEnergy(HANDLE hDSpotterNLU);

// Purpose: Enable AGC(Auto gain control). AGC is defaultly closed. Must call this after DSpotterNLU_Init() to activate.
// hDSpotterNLU(IN): a handle of the recognizer
// Return: Success or error code
DSPDLL_API INT DSpotterNLU_AGC_Enable(HANDLE hDSpotterNLU);

// Purpose: Disable AGC(Auto gain control).
// hDSpotterNLU(IN): a handle of the recognizer
// Return: Success or error code
DSPDLL_API INT DSpotterNLU_AGC_Disable(HANDLE hDSpotterNLU);

// Purpose: Set the upper bound of AGC Gain (and also the current AGC Gain)
// hDSpotterNLU(IN): a handle of the recognizer
// nMaxGain(IN): The upper bound of AGC gain; Default is set to 32
// Return: Success or error code
// Note: 1 <= nMaxGain <= 128
DSPDLL_API INT DSpotterNLU_AGC_SetMaxGain(HANDLE hDSpotterNLU, INT nMaxGain);

// Purpose: Set thresholds to trigger AGC Gain increasing.
// hDSpotterNLU(IN): a handle of the recognizer
// nLowerTh(IN): AGC Gain will increasing if (current peak of frame)*(AGC Gain) < nLowerTh; Default is set to 5000
// Return: Success or error code
// Note: 0 <= nLowerTh <= 10000
DSPDLL_API INT DSpotterNLU_AGC_SetIncGainTh(HANDLE hDSpotterNLU, INT nLowerTh);

// Purpose: Callback to get data after AGC.
// lpsOutputSample: Samples after AGC.
// nSampleNum: Number of samples
// lpParam: Parameters.
#if defined(_WIN32)
typedef INT(__stdcall* DSpotterAGC_GetAGCData_Callback)(SHORT* lpsOutputSample, INT nSampleNum, VOID* lpParam);
#else	// _WIN32
typedef INT(*DSpotterAGC_GetAGCData_Callback)(SHORT* lpsOutputSample, INT nSampleNum, VOID* lpParam);
#endif	// _WIN32

// Purpose: Set Callback to get data after AGC.
// hDSpotterNLU(IN): a handle of the recognizer
// lpfnCallback(IN): callback
// lpParam(IN): Parameters
DSPDLL_API INT DSpotterNLU_AGC_SetCallback(HANDLE hDSpotterNLU, DSpotterAGC_GetAGCData_Callback lpfnCallback, VOID* lpParam);

//VAD
// Purpose: Set the active frame length of VAD.
// hDSpotterNLU(IN): The handle of the recognizer.
// nActiveFrameNum(IN): The VAD detects as start point if there are nActiveLength frames detected continuously as voice frames.
//                      Each frame is 10 ms(160 samples).
//                      The reasonable value range is 1 ~ 15. The default value is 1.
// Return: Success or error code.
DSPDLL_API INT DSpotterNLU_VAD_SetActiveLength(HANDLE hDSpotterNLU, INT nActiveFrameNum);

// Purpose: Set the active reward of VAD.
// hDSpotterNLU(IN): The handle of the recognizer.
// nActiveReward(IN): The larger value means more easy to detect VAD start point.
//                    The reasonable value range is 0 ~ 3. The default value is 3.
// Return: Success or error code.
DSPDLL_API INT DSpotterNLU_VAD_SetActiveReward(HANDLE hDSpotterNLU, INT nActiveReward);

// Purpose: Get the active reward value of VAD.
// hDSpotterNLU(IN): The handle of the recognizer.
// Return: The active reward value.
DSPDLL_API INT DSpotterNLU_VAD_GetActiveReward(HANDLE hDSpotterNLU);

// Purpose: Set the ending silence length of VAD.
// hDSpotterNLU(IN): The handle of the recognizer.
// nSilenceFrameNum(IN): The frame number of ending silence, each frame is 10 ms(160 samples).
// Return: Success or error code.
DSPDLL_API INT DSpotterNLU_VAD_SetEndSilenceLength(HANDLE hDSpotterNLU, INT nSilenceFrameNum);

// Purpose: Set the energy thrshold of VAD active frame.
// hDSpotterNLU(IN): The handle of the recognizer.
// nEnergyThreshold(IN): The minimum value of energy for VAD to detect as start point.
// Return: Success or error code.
DSPDLL_API INT DSpotterNLU_VAD_SetEnergyThreshold(HANDLE hDSpotterNLU, INT nEnergyThreshold);

#ifdef __cplusplus
}
#endif

#endif // __DSPOTTERNLU_API_H
