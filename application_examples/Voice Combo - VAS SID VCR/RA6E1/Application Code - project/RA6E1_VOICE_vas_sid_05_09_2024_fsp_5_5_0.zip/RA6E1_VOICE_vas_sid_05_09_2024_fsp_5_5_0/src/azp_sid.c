#include <azp_sid.h>
#include "azpSID.h"
#include "hal_data.h"
#include "RingBuffer.h"
#include "AudioRecord.h"

int8_t  g_sid_top;
int16_t g_sid_prob;
extern volatile int g_sid_hack_det;
extern int rai_pred;
int count = 0;

//MAX VALUE IT CAN TAKE IS 2==3Users
int max_registered_users = 1;

int registration_start = 1;
static int     g_registered = 0;
static HANDLE  h_ring_buffer = NULL;
static BYTE    g_working_mem[RING_BUFFER_GET_MEM_USAGE(SID_RECORD_BUF_SIZE)];
static int8_t  g_sid_buffer[7500] __attribute__((aligned (4)));
//static int8_t  g_sid_buffer[16384] __attribute__((aligned (4)));

int16_t userid =0 ; //user 0 will be registered used for testing

// recoverable assertion
static void dbg_assert(int16_t exp){
    volatile size_t dummy = 1;
    if( exp == 0 ){
        __disable_irq();
        while(dummy == 1);
        __enable_irq();
    }
}



static st_irq_pins_t s_irq_pins[] =
{
    { &g_external_irq1ds }
};
/**********************************************************************************************************************
 End of function st_irq_pins_t
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * Function Name: icu_initialize
 * Description  : initialises irq pins to allow for button presses
 * Return Value : fsp_err
 *********************************************************************************************************************/
static fsp_err_t icu_initialize(void)
{
    uint8_t g_irq_switch = ((sizeof(s_irq_pins)) / (sizeof(s_irq_pins[0]))); /*  */

    fsp_err_t fsp_err = FSP_SUCCESS;

    for (uint32_t i = 0; i < g_irq_switch; i++ )
    {
        fsp_err = R_ICU_ExternalIrqOpen (s_irq_pins[i].p_irq->p_ctrl, s_irq_pins[i].p_irq->p_cfg);

        if (FSP_SUCCESS != fsp_err)
        {
            return fsp_err;
        }

        fsp_err = R_ICU_ExternalIrqEnable (s_irq_pins[i].p_irq->p_ctrl);

        if (FSP_SUCCESS != fsp_err)
        {
            return fsp_err;
        }
    }
    return fsp_err;
}
/**********************************************************************************************************************
 End of function icu_initialize
 *********************************************************************************************************************/



int azp_sid_init(void){
    fsp_err_t rc;
    volatile SID_STATUS sts;

    icu_initialize();

    rc = RingBufferInit(g_working_mem, sizeof(g_working_mem), SID_RECORD_BUF_SIZE, &h_ring_buffer);
    if( rc != FSP_SUCCESS ){
        DBG_UART_TRACE("Failed to init SID circular buffer\r\n");
        dbg_assert(rc == FSP_SUCCESS);
        return -1;
    }

    sts = sid_init(g_sid_buffer, sizeof(g_sid_buffer), NULL, 0);
    dbg_assert( sts == errKWS_NoError );
    //DBG_UART_TRACE("Successfully initialize SID\r\n");
    return 0;
}

int azp_sid_write(uint8_t* buf){
    int rc;
    int16_t wbuffer[SID_INPUT_LEN];
    SID_STATUS sts;

    // write new chunk
    rc = RingBufferPutData(h_ring_buffer, buf, SID_REC_FRAME_SIZE);  // SID_RECORD_BUF_SIZE ->
    if( rc != RING_BUFFER_SUCCESS ){
        DBG_UART_TRACE("Failed to write samples to SID circular buffer\r\n");
        dbg_assert(0);
        return -1;
    }

    // get available size
    rc = RingBufferGetDataSize(h_ring_buffer);
    if( rc < (int)SID_INPUT_SIZE ){
        return 0;
    }

    // read data
    rc = RingBufferGetData(h_ring_buffer, wbuffer, SID_INPUT_SIZE);
    if( rc != RING_BUFFER_SUCCESS ){
        DBG_UART_TRACE("Failed to read samples from SID circular buffer\r\n");
        dbg_assert(0);
        return -1;
    }

    sts = sid_load_input(wbuffer, SID_INPUT_LEN);
    if( sts != errKWS_NoError ){
        DBG_UART_TRACE("LOAD DATA ERROR [%d] \r\n", sts);
    }

    sts = sid_run_model();
    if( sts != errKWS_NoError ){
        DBG_UART_TRACE("RUN MODEL ERROR [%d] \r\n", sts);
    }

    return 0;
}

int azp_sid_inference(void){
    int rc = 0;

    rc = sid_identify();
    if( rc == -1 && count <=max_registered_users && registration_start ==1 && rai_pred==1){

    //if( !g_registered ){
        register_user((int16_t)count);

        //g_registered = 1;
        registration_start = 0;
        DBG_UART_TRACE("\r\nUser [%d] registered!\r\n", count);
        count++;
        return count; // user registered
    }

    rc = sid_identify();
    if( rc != -1 )
        DBG_UART_TRACE("IDENTIFY RETURN [%d] \r\n", rc);

    return rc;//(rc == -1) ? 0 : 1; // detection
}

/** External IRQ for SW 1 on ICU Instance. */
/**********************************************************************************************************************
 * Function Name: callback_irq1ds_button
 * Description  : .
 * Argument     : p_args
 * Return Value : .
 *********************************************************************************************************************/
void callback_irq1ds_button(external_irq_callback_args_t *p_args)
{
    /* Cast unused params to void */
    FSP_PARAMETER_NOT_USED(p_args);

    registration_start = 1;
    if (count  <= max_registered_users){
        DBG_UART_TRACE("Button pressed registration for new user %d started.\r\n", count);
        DBG_UART_TRACE("For registration to be completed say <Hi Renesas>.\r\n");
    }
        else{
            DBG_UART_TRACE("Button pressed maximum registered users reached %d, registration canceled.\r\n", count);
        }
    return;

}
