#ifndef AZP_SID_H_
#define AZP_SID_H_
#include <stdint.h>
#include "bsp_api.h"
#include "hal_data.h"
#include "DbgTrace.h"
#include "azpSID.h"

#define SID_ENABLE             1
#define SID_NUM_BUFS           2
#define SID_SAMPLE_RATE        (16000)
#define SID_REC_FRAME_LEN      (160)
#define SID_INPUT_LEN          (512U)//(2560U)                           /* RECORD_FRAME_SAMPLES in voice_main.c */
#define SID_FRAME_BUF_LEN      (SID_INPUT_LEN * SID_NUM_BUFS)    /* SID frame buffer length and RAI window length */

//#define SID_RECORD_BUF_LEN     (SID_SAMPLE_RATE/8 + SID_FRAME_BUF_LEN)
#define SID_RECORD_BUF_LEN     (SID_FRAME_BUF_LEN)
#define SID_RECORD_BUF_SIZE    (SID_RECORD_BUF_LEN*2)
#define SID_INPUT_SIZE         (SID_INPUT_LEN*2)
#define SID_FRAME_BUF_SIZE     (SID_FRAME_BUF_LEN*2)
#define SID_REC_FRAME_SIZE     (SID_REC_FRAME_LEN*2)
#define SID_WORKING_BUF_SIZE   (SID_WORKING_BUF_LEN*2)

int    azp_sid_init(void);
int    azp_sid_write(uint8_t* buf);
int    azp_sid_inference(void);

typedef struct irq_pins
{
    const external_irq_instance_t * const p_irq;
} st_irq_pins_t;

#endif // AZP_SID_H_
