#include "voice_main.h"
#include "hal_data.h"
#include "base_types.h"
#include "AudioRecord.h"
#include "DbgTrace.h"
#include "RingBuffer.h"

//#define USE_R48Kto16K   // Note: If enable the definition of R48Kto16K, the period of g_i2s_clock should be changed from 1024KHz to 3072KHz.
//#define SPH0645     // Knowles DMIC

#define RBUF_SIZE_RECORD         (320*9)                 // Record ring buffer size, 90 ms.

static volatile bool   g_bRecording = false;
static volatile bool   g_bSkipRecordData = false;
static HANDLE g_hRingBuffer = NULL;
static BYTE   g_byaRingBuffer[RING_BUFFER_GET_MEM_USAGE(RBUF_SIZE_RECORD)];
static int    g_nRecordCount = 0;
static int    g_nRBufLostCount = 0;

#define         I2SRBUF_SAMPLES        (80)
int             g_i2s_buffer[I2SRBUF_SAMPLES];
BYTE            g_i2s_audio_buffer[I2SRBUF_SAMPLES * sizeof(short)];
int             g_nUnderRunCount = 0;

static void ToggleYellowLED();
int AudioRecordInit();

int AudioRecordInit()
{
    fsp_err_t  err = FSP_SUCCESS;
    int nRet;

    nRet = RingBufferInit(g_byaRingBuffer, sizeof(g_byaRingBuffer), RBUF_SIZE_RECORD, &g_hRingBuffer);
    if (nRet != RING_BUFFER_SUCCESS)
    {
        DBG_UART_TRACE("Record RingBufferInit() fail %d!\r\n", nRet);
        return FSP_ERR_OUT_OF_MEMORY;
    }

	err = R_ELC_Open(&g_elc_ctrl, &g_elc_cfg);
	if (FSP_SUCCESS != err)
	{
		__BKPT(0);
	}

	err = R_ELC_Enable(&g_elc_ctrl);
	if (FSP_SUCCESS != err)
	{
		__BKPT(0);
	}

	/** SW I2S */
	err = R_GPT_Open(&g_timer_sck_ctrl, &g_timer_sck_cfg);
	if(FSP_SUCCESS != err)
	{
		DBG_UART_TRACE("\r\n[Error] R_GPT_Open: SCK\r\n");
		__asm("BKPT #0\n");
	}

	err = R_GPT_Open(&g_timer_ws_ctrl, &g_timer_ws_cfg);
	/* Set initial counter value to supplement the missing clock of 32 times count-up in first cycle */
	err = R_GPT_CounterSet(&g_timer_ws_ctrl, g_timer_ws_cfg.period_counts - 1);
	if(FSP_SUCCESS != err)
	{
		DBG_UART_TRACE("\r\n[Error] R_GPT_Open: WS\r\n");
		__asm("BKPT #0\n");
	}

	err = R_GPT_Start(&g_timer_ws_ctrl);
	if(FSP_SUCCESS != err)
	{
		DBG_UART_TRACE("\r\n[Error] R_GPT_Start: WS\r\n");
		__asm("BKPT #0\n");
	}

	err = R_SPI_Open(&g_spi_i2s_ctrl, &g_spi_i2s_cfg);
	if(FSP_SUCCESS != err)
	{
		DBG_UART_TRACE("\r\n[Error] R_SPI_Open: I2S\r\n");
		__asm("BKPT #0\n");
	}

	err = R_GPT_Start(&g_timer_sck_ctrl);
	if(FSP_SUCCESS != err)
	{
		DBG_UART_TRACE("\r\n[Error] R_GPT_Start: SCK\r\n");
		__asm("BKPT #0\n");
	}

    g_bRecording = false;
    g_bSkipRecordData = false;
    g_nRecordCount = 0;
    g_nRBufLostCount = 0;

    return err;
}

int AudioRecordRelease()
{
    AudioRecordStop();
    R_SPI_Close(&g_spi_i2s_ctrl);
    R_ELC_Disable(&g_elc_ctrl);
    R_ELC_Close(&g_elc_ctrl);
	R_GPT_Reset(&g_timer_ws_ctrl);
    R_GPT_Stop(&g_timer_ws_ctrl);
    R_GPT_Close(&g_timer_ws_ctrl);
    R_GPT_Stop(&g_timer_sck_ctrl);
    R_GPT_Close(&g_timer_sck_ctrl);

    RingBufferRelease(g_hRingBuffer);
    g_hRingBuffer = NULL;

    return FSP_SUCCESS;
}

int AudioRecordStart()
{
    fsp_err_t  err;

    g_bRecording = true;
    err = R_SPI_Read(&g_spi_i2s_ctrl, g_i2s_buffer, I2SRBUF_SAMPLES, SPI_BIT_WIDTH_32_BITS);
    if (FSP_SUCCESS != err){
        DBG_UART_TRACE("\r\n[Error] R_SPI_Read\r\n");
        g_bRecording = false;
    }

    return err;
}

int AudioRecordStop()
{
    g_bRecording = false;

    return FSP_SUCCESS;
}

void AudioRecordPause()
{
    g_bSkipRecordData = true;
}

void AudioRecordResume()
{
    g_bSkipRecordData = false;
}

int AudioRecordGetDataSize(void)
{
    return RingBufferGetDataSize(g_hRingBuffer);
}

int AudioRecordGetData(void *lpBuffer, int nBufferSize)
{
    if (RingBufferGetData(g_hRingBuffer, lpBuffer, nBufferSize) != RING_BUFFER_SUCCESS)
        return -FSP_ERR_INVALID_SIZE;

    return FSP_SUCCESS;
}

int AudioRecordClearData()
{
    if (RingBufferDequeueData(g_hRingBuffer, RingBufferGetDataSize(g_hRingBuffer)) != RING_BUFFER_SUCCESS)
        return FSP_ERR_INVALID_SIZE;

    return FSP_SUCCESS;
}

int AudioRecordGetLostCount(void)
{
    return g_nRBufLostCount;
}

static void ToggleYellowLED()
{
    static int nLevel = ON;

    R_IOPORT_PinWrite(&g_ioport_ctrl, LED_Y, nLevel);
    if (nLevel == ON)
        nLevel = OFF;
    else
        nLevel = ON;
}


void g_spi_cb(spi_callback_args_t *p_args)
{
    uint32_t i2s_temp_data;
    if( NULL != p_args)
    {
        /* capture callback event for validating the i2s transfer event*/
        if (p_args->event == SPI_EVENT_TRANSFER_COMPLETE)
        {
            for (int i = 0; i < I2SRBUF_SAMPLES; i++)
            {
                i2s_temp_data = (uint32_t)(g_i2s_buffer[i] << 1);
                g_i2s_audio_buffer[i*2]     = (uint8_t)(i2s_temp_data >> 16);
                g_i2s_audio_buffer[i*2 + 1] = (uint8_t)(i2s_temp_data >> 24);
                //output_buf[i] = (dmic_buf[dmic_idx^1][i] >> 16) & 0xFFFF;
            }

            g_nRecordCount++;
            int nFreeSize = RingBufferGetFreeSize(g_hRingBuffer);
            if (nFreeSize < (int)(I2SRBUF_SAMPLES*sizeof(short)))
            {
                g_nRBufLostCount++;
                ToggleYellowLED();
            }
            else
            {
                if (!g_bSkipRecordData)
                    RingBufferPutData(g_hRingBuffer, g_i2s_audio_buffer, I2SRBUF_SAMPLES*sizeof(short));
            }

            if (g_bRecording)
                while(FSP_SUCCESS != R_SPI_Read(&g_spi_i2s_ctrl, g_i2s_buffer, I2SRBUF_SAMPLES, SPI_BIT_WIDTH_32_BITS));
        }
        else if (p_args->event == SPI_EVENT_ERR_MODE_UNDERRUN)
        {
            if (g_bRecording)
            {
                g_nUnderRunCount++;
                ToggleYellowLED();
                R_SPI_Close(&g_spi_i2s_ctrl);
                R_SPI_Open(&g_spi_i2s_ctrl, &g_spi_i2s_cfg);
                while(FSP_SUCCESS != R_SPI_Read(&g_spi_i2s_ctrl, g_i2s_buffer, I2SRBUF_SAMPLES, SPI_BIT_WIDTH_32_BITS));
            }
        }
    }
    return;
}
