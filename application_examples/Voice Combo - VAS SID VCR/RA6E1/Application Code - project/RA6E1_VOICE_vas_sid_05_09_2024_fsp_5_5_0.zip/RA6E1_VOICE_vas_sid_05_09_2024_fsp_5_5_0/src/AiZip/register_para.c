#include <stdio.h>
#include <stdint.h>

int8_t flash_arr[737 * 5];
void RegistrationInformationRead(int index, int8_t *data, int len)
{
    memcpy(data, flash_arr + index * len, len);
}
void RegistrationInformationWrite(int index, int8_t *data, int len)
{
    memcpy(flash_arr + index * len, data, len);
}

void register_para_save()
{
}
