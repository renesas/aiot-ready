/**********************************************************
* API for KWS model library
* Copyright (C) 2022 AiZip Inc. All rights reserved.
**********************************************************/

#ifndef __AZPKWS_H__
#define __AZPKWS_H__


#include <stdint.h>


#ifdef __cplusplus
extern "C" {
#endif

typedef enum __SID_STATUS
{
	errKWS_NoError = 0,
	errKWS_NotReady,
	errKWS_InvalidParam,
	errKWS_InvalidLicense,
	errKWS_BufferOverflow
}
SID_STATUS;


/**********************************************************
 * Initialize SID model
 * cpuID: the buffer of the CPUID of MCU chip
 * len: the number of elements (32-bit) of CPUID buffer
 **********************************************************/
SID_STATUS sid_init(int8_t *buffer1, int32_t size1, int8_t *buffer2, int32_t size2);

/**********************************************************
* Get the SID model version number
**********************************************************/
uint32_t sid_get_version(void);

/**********************************************************
* Get the audio signal sampling specs
* rate: pointer to receive the audio sampling rate
* buffsize: pointer to receive the number of element in audio buffer
**********************************************************/
SID_STATUS sid_get_specs(int * rate, int * buffsize);

/**********************************************************
* Load audio input data into SID model
* audio: audio data buffer
* size: number of elements (16-bit) in the audio buffer
**********************************************************/
SID_STATUS sid_load_input(int16_t * audio, int size);

/**********************************************************
 * Run SID model
 **********************************************************/
SID_STATUS sid_run_model();
/**********************************************************
 * Decode the SID model result to get the speaker's ID
 * return: the speaker's ID
 **********************************************************/
int sid_identify();
/**********************************************************
 * Register the user's voice
 * user_id: the user's ID
 **********************************************************/
void register_user(int16_t user_id);
/**********************************************************
 * Release KWS model memory
 **********************************************************/

void sid_free(void);

uint32_t check_memory();

#ifdef __cplusplus
}
#endif

#endif	// __AZPKWS_H__
