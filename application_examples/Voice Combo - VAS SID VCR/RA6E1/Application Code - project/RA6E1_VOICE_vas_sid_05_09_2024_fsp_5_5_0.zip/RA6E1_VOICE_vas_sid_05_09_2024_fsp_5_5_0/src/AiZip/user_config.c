#ifndef USER_CONFIG_C_
#define USER_CONFIG_C_
#include "stdint.h"
int16_t KWS_SIM_THRE=700;
int16_t SID_SIM_THRE=400;
#endif // !USER_CONFIG_C_
