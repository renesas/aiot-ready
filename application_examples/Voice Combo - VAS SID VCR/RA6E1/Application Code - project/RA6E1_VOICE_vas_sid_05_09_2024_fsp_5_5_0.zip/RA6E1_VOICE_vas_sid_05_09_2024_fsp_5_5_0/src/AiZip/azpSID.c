#include <stdint.h>
#include <stddef.h>
#include "azpSID.h"
#include "RingBuffer.h"
#include "DbgTrace.h"

#define SID_RECORD_BUF_SIZE  24000

static HANDLE h_ring_buffer = NULL;
static BYTE   g_working_mem[RING_BUFFER_GET_MEM_USAGE(SID_RECORD_BUF_SIZE)];
static int8_t g_sid_buffer[7500] __attribute__((aligned (4)));

#define DMIC_BUF_SIZE (2560)

int azp_sid_init(void)
{
    fsp_err_t rc;
    rc = RingBufferInit(g_working_mem, sizeof(g_working_mem), SID_RECORD_BUF_SIZE, &h_ring_buffer);
    if( rc != FSP_SUCCESS ){
        DBG_UART_TRACE("Failed to init SID ring buffer\r\n");
        return -1;
    }
    sid_init(g_sid_buffer, sizeof(g_sid_buffer), NULL, 0);
    return 0;
}

// write data to circular buffer
static int azp_sid_write(int16_t* buffer, int len, int8_t* top, int16_t* prob)
{
#if  0
    int rc;
    int16_t dummy[SID_REC_FRAME_LEN];
    int bytes_avail = RingBufferGetFreeSize(h_ring_buffer);
    if( bytes_avail < len ){
        rc = RingBufferGetData(h_ring_buffer, (int8_t*)dummy, bytes_to_read);
        if( rc != RING_BUFFER_SUCCESS ){
            DBG_UART_TRACE("Failed to read samples from DC/DS circular buffer\r\n");
            dbg_assert(0);
            return -1;
        }
    }
    return (*top >= 0) ? 1 : 0;
#endif
    return 0;
}

static int azp_sid_predict(int16_t* buffer, int len, int8_t* top, int16_t* prob)
{
    sid_load_input(buffer, len);
    sid_classify(top, prob);

    /*
    if ((top >= 0)){
        DBG_UART_TRACE("Word %d detected! SID Sim %d\n", top, prob);
    }
    */

    return (*top >= 0) ? 1 : 0;
}

